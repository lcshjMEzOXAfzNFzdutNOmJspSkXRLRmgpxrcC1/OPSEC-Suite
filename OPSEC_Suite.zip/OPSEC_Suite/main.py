#!/usr/bin/env python3
"""
OPSEC Suite — Operational Security & Privacy Toolkit
A complete, educational security toolkit for privacy and OPSEC.

Usage:
    python main.py

Requirements:
    pip install -r requirements.txt
"""

import os
import sys
from pathlib import Path

# Add parent directory to path so utils/ and modules/ are importable
sys.path.insert(0, str(Path(__file__).parent))

from utils.colors import Colors, supports_color
from utils.logger import setup_logger, log_info
from utils.config_manager import ConfigManager

# Initialize logger and config
logger = setup_logger("opsec", "opsec.log")
config = ConfigManager(str(Path(__file__).parent / "config.json"))

BANNER = r"""
  ██████╗ ██████╗ ███████╗███████╗ ██████╗
 ██╔═══██╗██╔══██╗██╔════╝██╔════╝██╔════╝
 ██║   ██║██████╔╝███████╗█████╗  ██║
 ██║   ██║██╔═══╝ ╚════██║██╔══╝  ██║
 ╚██████╔╝██║     ███████║███████╗╚██████╗
  ╚═════╝ ╚═╝     ╚══════╝╚══════╝ ╚═════╝
         SUITE — Operational Security Toolkit
"""

MAIN_MENU = [
    ("OPSEC", [
        ("What is OPSEC?", "modules.opsec.what_opsec"),
        ("OPSEC Checklist", "modules.opsec.opsec_checklist"),
        ("Privacy Tips", "modules.opsec.privacy"),
        ("Dark Web Info", "modules.opsec.darkweb"),
        ("Persona Generator", "modules.opsec.persona_creation"),
        ("Privacy Browser Config", "modules.opsec.privacy_browser"),
        ("Search Engine Guide", "modules.opsec.search_engines"),
    ]),
    ("Metadata", [
        ("Metadata Overview", "modules.metadata.metadata"),
        ("EXIF Viewer/Remover", "modules.metadata.exif_tool"),
        ("Batch Metadata Cleaner", "modules.metadata.clean_metadata"),
    ]),
    ("Security Tools", [
        ("Security Guide", "modules.security.security"),
        ("Password Manager", "modules.security.password_manager"),
        ("Encryption/Decryption", "modules.security.decryption"),
        ("Threat Intelligence", "modules.security.reverse_security"),
        ("Signal Messenger Guide", "modules.security.signal"),
        ("VeraCrypt Guide", "modules.security.veracrypt"),
    ]),
    ("Identity & Anonymity", [
        ("Kleopatra / GPG Guide", "modules.identity.kleopatra"),
        ("Phone Number Analyzer", "modules.identity.phone_number"),
        ("Secure Email Guide", "modules.identity.secure_email"),
        ("Temp Email Inbox", "modules.identity.temp_email"),
    ]),
    ("Networking", [
        ("Network Settings & OPSEC", "modules.networking.network_setting"),
        ("Tails OS Guide", "modules.networking.tails_os"),
        ("Virtual Machine Guide", "modules.networking.virtual_machine"),
    ]),
    ("Defensive Tools", [
        ("Breach Check (HIBP)", "modules.defensive.breach_check"),
        ("Antivirus Status", "modules.defensive.antivirus"),
        ("Browser Fingerprint Guide", "modules.defensive.fingerprint"),
        ("Ad Nauseam / Obfuscation", "modules.defensive.ad_nauseam"),
        ("Anti-Tracking Guide", "modules.defensive.track_me_not"),
        ("Security Learning Resources", "modules.defensive.tryhackme"),
    ]),
    ("VPN & Proxy", [
        ("IP Lookup & VPN Detection", "modules.vpn.ip_lookup"),
        ("VPN Status Checker", "modules.vpn.vpn_checker"),
        ("Extended VPN Detection", "modules.vpn.vpn_checker2"),
        ("Proxy Checker", "modules.vpn.proxy_checker"),
        ("Proxy Verifier", "modules.vpn.proxy_verifier"),
        ("Fetch Free Proxies", "modules.vpn.proxy_generator"),
        ("Free Proxy Sources", "modules.vpn.free_proxy_menu"),
        ("Free VPN List", "modules.vpn.free_vpn_list"),
        ("Paid VPN Guide", "modules.vpn.paid_vpn"),
        ("Paid Proxy Services", "modules.vpn.paid_proxy"),
        ("VPN Browser Extensions", "modules.vpn.vpn_extension"),
    ]),
]


def print_banner() -> None:
    """Display the OPSEC Suite banner."""
    if supports_color():
        print(Colors.PURPLE + BANNER + Colors.RESET)
    else:
        print(BANNER)

    version = config.get("version", "1.0.0")
    print(f"  {Colors.DIM}Version {version}  |  For educational and defensive security use only{Colors.RESET}")
    print(f"  {Colors.DIM}Logs: opsec.log{Colors.RESET}\n")


def display_main_menu() -> None:
    """Display the categorized main menu."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*52}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}              MAIN MENU{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*52}{Colors.RESET}\n")

    item_num = 1
    for cat_name, modules in MAIN_MENU:
        print(f"  {Colors.BOLD}{Colors.PURPLE}[ {cat_name} ]{Colors.RESET}")
        for module_name, _ in modules:
            print(f"    {Colors.CYAN}{item_num:>2}.{Colors.RESET} {module_name}")
            item_num += 1
        print()

    print(f"  {Colors.CYAN} 0.{Colors.RESET} Exit\n")


def run_module(module_path: str) -> None:
    """
    Dynamically import and run a module's run() function.

    Args:
        module_path: Dot-separated module path (e.g. 'modules.vpn.ip_lookup')
    """
    try:
        import importlib
        module = importlib.import_module(module_path)
        if hasattr(module, "run"):
            module.run()
        else:
            print(f"  {Colors.YELLOW}Module '{module_path}' has no run() function.{Colors.RESET}")
    except ImportError as e:
        print(f"  {Colors.RED}Import error: {e}{Colors.RESET}")
        print(f"  {Colors.YELLOW}Ensure all requirements are installed: pip install -r requirements.txt{Colors.RESET}")
    except Exception as e:
        print(f"  {Colors.RED}Error running module: {e}{Colors.RESET}")
        log_info(f"Module error {module_path}: {e}")


def get_all_modules() -> list:
    """Flatten all modules into an ordered list for menu indexing."""
    all_modules = []
    for _, modules in MAIN_MENU:
        all_modules.extend(modules)
    return all_modules


def display_status() -> None:
    """Display a quick system status check."""
    from utils.network import get_public_ip
    from modules.vpn.vpn_checker import check_vpn_active
    from modules.defensive.breach_check import check_password_pwned

    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Quick Status ==={Colors.RESET}")
    print(f"  {Colors.YELLOW}Checking public IP...{Colors.RESET}", end="", flush=True)
    ip = get_public_ip()
    print(f"\r  Public IP:  {Colors.CYAN}{ip}{Colors.RESET}             ")

    print(f"  {Colors.YELLOW}Checking VPN...{Colors.RESET}", end="", flush=True)
    vpn_data = check_vpn_active()
    vpn_status = vpn_data.get("vpn_detected", False)
    vpn_color = Colors.GREEN if vpn_status else Colors.RED
    vpn_text = f"Active ({vpn_data.get('country', '?')})" if vpn_status else "NOT detected"
    print(f"\r  VPN Status: {vpn_color}{vpn_text}{Colors.RESET}                    ")


def main() -> None:
    """Main application entry point."""
    os.chdir(Path(__file__).parent)

    print_banner()
    log_info("OPSEC Suite started")

    all_modules = get_all_modules()

    while True:
        display_main_menu()

        try:
            choice = input(f"  {Colors.BOLD}Select option:{Colors.RESET} ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n\n  {Colors.YELLOW}Exiting OPSEC Suite. Stay secure.{Colors.RESET}\n")
            log_info("OPSEC Suite exited by user")
            sys.exit(0)

        if choice == "0":
            print(f"\n  {Colors.YELLOW}Exiting OPSEC Suite. Stay secure.{Colors.RESET}\n")
            log_info("OPSEC Suite exited")
            break

        elif choice.lower() == "s":
            display_status()
            continue

        try:
            idx = int(choice) - 1
            if 0 <= idx < len(all_modules):
                module_name, module_path = all_modules[idx]
                print(f"\n  {Colors.BOLD}{Colors.PURPLE}[ {module_name} ]{Colors.RESET}")
                log_info(f"Running module: {module_name}")
                run_module(module_path)
                input(f"\n  {Colors.DIM}Press Enter to return to menu...{Colors.RESET}")
            else:
                print(f"  {Colors.RED}Invalid option. Choose 0-{len(all_modules)}.{Colors.RESET}")
        except ValueError:
            if choice.lower() == "help":
                print(f"\n  {Colors.CYAN}Type a number to select a module.{Colors.RESET}")
                print(f"  {Colors.CYAN}Type 's' for quick status check.{Colors.RESET}")
                print(f"  {Colors.CYAN}Type '0' to exit.{Colors.RESET}")
            else:
                print(f"  {Colors.RED}Please enter a valid number.{Colors.RESET}")


if __name__ == "__main__":
    main()
