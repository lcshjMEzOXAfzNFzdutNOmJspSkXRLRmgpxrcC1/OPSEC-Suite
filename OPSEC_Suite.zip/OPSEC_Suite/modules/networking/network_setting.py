"""
Network settings and configuration information module.
Covers DNS hardening, firewall basics, and network OPSEC.
"""

import platform
import socket
import subprocess
from typing import Dict, List

from utils.colors import Colors
from utils.network import dns_lookup, get_public_ip
from utils.logger import log_info


def test_dns_leak() -> Dict[str, List[str]]:
    """
    Perform a basic DNS leak test by resolving known test domains.

    Returns:
        Dictionary with resolved IPs from multiple DNS test endpoints
    """
    test_domains = [
        "whoami.akamai.net",
        "resolver1.opendns.com",
    ]
    results = {}
    for domain in test_domains:
        resolved = dns_lookup(domain, "A")
        results[domain] = resolved
    return results


def get_network_interfaces() -> List[Dict[str, str]]:
    """
    List network interfaces and their IP addresses.

    Returns:
        List of interface info dictionaries
    """
    interfaces = []
    try:
        import netifaces
        for iface in netifaces.interfaces():
            addrs = netifaces.ifaddresses(iface)
            ipv4 = addrs.get(netifaces.AF_INET, [{}])[0].get("addr", "")
            ipv6 = addrs.get(netifaces.AF_INET6, [{}])[0].get("addr", "")
            if ipv4 or ipv6:
                interfaces.append({
                    "name": iface,
                    "ipv4": ipv4 or "N/A",
                    "ipv6": ipv6 or "N/A",
                })
    except ImportError:
        try:
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            interfaces.append({"name": "primary", "ipv4": local_ip, "ipv6": "N/A"})
        except Exception:
            pass
    return interfaces


def display_dns_config_guide() -> None:
    """Display a guide to configuring private DNS."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Private DNS Configuration Guide ==={Colors.RESET}\n")

    providers = [
        ("Cloudflare (1.1.1.1)", "1.1.1.1 / 1.0.0.1", "Fastest, no-logging DNS"),
        ("Quad9 (9.9.9.9)", "9.9.9.9 / 149.112.112.112", "Malware-blocking, privacy-respecting"),
        ("NextDNS", "Custom address", "Fully configurable, blocks ads/trackers"),
        ("AdGuard DNS", "94.140.14.14 / 94.140.15.15", "Ad and tracker blocking"),
        ("DNS.Watch", "84.200.69.80 / 84.200.70.40", "Uncensored, privacy-focused"),
    ]

    print(f"  {Colors.BOLD}Privacy DNS Providers:{Colors.RESET}")
    for name, servers, desc in providers:
        print(f"  {Colors.CYAN}→{Colors.RESET} {Colors.BOLD}{name}{Colors.RESET}: {servers}")
        print(f"    {desc}\n")

    system = platform.system()
    print(f"  {Colors.BOLD}DNS over HTTPS (DoH) Setup:{Colors.RESET}")
    if system == "Windows":
        print(f"  Settings → Network → DNS → Enable DNS over HTTPS")
        print(f"  {Colors.DIM}netsh dns add encryption server=1.1.1.1 dohTemplate=https://cloudflare-dns.com/dns-query{Colors.RESET}")
    elif system == "Darwin":
        print(f"  System Preferences → Network → Advanced → DNS")
        print(f"  Or use Cloudflare's 1.1.1.1 app for macOS")
    else:
        print(f"  /etc/systemd/resolved.conf → set DNS=1.1.1.1 and DNSOverTLS=yes")
        print(f"  Or use dnscrypt-proxy for full DoH support")

    print(f"\n  {Colors.BOLD}Firefox DoH:{Colors.RESET}")
    print(f"  Settings → Privacy & Security → DNS over HTTPS → Max Protection")


def display_mac_randomization_guide() -> None:
    """Display MAC address randomization guide."""
    system = platform.system()
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== MAC Address Randomization ==={Colors.RESET}\n")
    print(f"  {Colors.YELLOW}Your MAC address can identify your device on every network.{Colors.RESET}\n")

    if system == "Windows":
        steps = [
            "Settings → Network & Internet → Wi-Fi → Hardware Properties",
            "Enable 'Random hardware addresses'",
            "Or via PowerShell: Set-NetAdapter -Name 'Wi-Fi' -MacAddress 'XX-XX-XX-XX-XX-XX'",
        ]
    elif system == "Darwin":
        steps = [
            "macOS randomizes MAC automatically per-network since Ventura",
            "Wi-Fi → Details → Private Wi-Fi Address → Rotating",
            "Or terminal: sudo ifconfig en0 ether $(openssl rand -hex 6 | sed 's/\(..\)/\1:/g;s/://' )",
        ]
    else:
        steps = [
            "NetworkManager: Edit connection → Cloned MAC Address → Random",
            "Or macchanger: sudo macchanger -r eth0",
            "Or ip command: sudo ip link set dev eth0 address XX:XX:XX:XX:XX:XX",
        ]

    for step in steps:
        print(f"  {Colors.CYAN}→{Colors.RESET} {step}")

    print(f"\n  {Colors.YELLOW}[!] MAC randomization is local-network only — not visible on the internet.{Colors.RESET}")


def run() -> None:
    """Main entry point for the network settings module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}       NETWORK SETTINGS & OPSEC{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")

    print(f"\n  {Colors.CYAN}1.{Colors.RESET} DNS leak test")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Network interfaces")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Private DNS configuration guide")
    print(f"  {Colors.CYAN}4.{Colors.RESET} MAC address randomization guide")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "1":
        pub_ip = get_public_ip()
        print(f"\n  Public IP: {Colors.CYAN}{pub_ip}{Colors.RESET}")
        print(f"  {Colors.YELLOW}Testing DNS resolution...{Colors.RESET}")
        results = test_dns_leak()
        for domain, ips in results.items():
            print(f"\n  {Colors.CYAN}{domain}:{Colors.RESET}")
            for ip in ips:
                print(f"    → {ip}")
        print(f"\n  {Colors.YELLOW}For full DNS leak test: https://dnsleaktest.com{Colors.RESET}")
        log_info("DNS leak test performed")

    elif choice == "2":
        ifaces = get_network_interfaces()
        print(f"\n  {Colors.BOLD}Network Interfaces:{Colors.RESET}")
        for i in ifaces:
            print(f"\n  {Colors.CYAN}{i['name']}{Colors.RESET}")
            print(f"    IPv4: {i['ipv4']}")
            print(f"    IPv6: {i['ipv6']}")

    elif choice == "3":
        display_dns_config_guide()

    elif choice == "4":
        display_mac_randomization_guide()
