"""
Virtual machine usage for OPSEC guide.
Explains how to use VMs for compartmentalization and security.
"""

import platform
import subprocess
from utils.colors import Colors
from utils.logger import log_info


def check_virtualization() -> bool:
    """
    Detect if CPU virtualization is enabled on the host.

    Returns:
        True if virtualization is likely enabled
    """
    system = platform.system()
    try:
        if system == "Linux":
            with open("/proc/cpuinfo") as f:
                content = f.read()
            return "vmx" in content or "svm" in content
        elif system == "Windows":
            result = subprocess.run(
                ["systeminfo"], capture_output=True, text=True, timeout=15
            )
            return "Virtualization Enabled In Firmware: Yes" in result.stdout
        elif system == "Darwin":
            result = subprocess.run(
                ["sysctl", "-n", "kern.hv_support"],
                capture_output=True, text=True, timeout=5
            )
            return result.stdout.strip() == "1"
    except Exception:
        pass
    return False


def display_vm_guide() -> None:
    """Display a guide to using virtual machines for OPSEC compartmentalization."""
    virt_enabled = check_virtualization()

    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*62}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}    VIRTUAL MACHINES FOR OPSEC COMPARTMENTALIZATION{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*62}{Colors.RESET}\n")

    virt_color = Colors.GREEN if virt_enabled else Colors.YELLOW
    print(f"  CPU Virtualization: {virt_color}{'ENABLED' if virt_enabled else 'UNKNOWN (check BIOS)'}{Colors.RESET}\n")

    sections = [
        (
            "Why Use VMs for OPSEC?",
            Colors.BLUE,
            [
                "Compartmentalization: Separate activities into isolated environments",
                "Snapshot & restore: Revert to clean state after any activity",
                "Network isolation: VMs can have their own network stack / VPN",
                "Testing malware: Analyze suspicious files without risking host",
                "Multiple identities: Each VM can have a distinct identity",
                "Disposability: Delete and recreate VMs after sensitive work",
            ],
        ),
        (
            "VM Software Options",
            Colors.CYAN,
            [
                "VirtualBox (Free) — Oracle VirtualBox: https://www.virtualbox.org",
                "  Cross-platform (Windows/Mac/Linux). Best for beginners.",
                "",
                "VMware Workstation Player (Free) — https://www.vmware.com",
                "  Better performance than VirtualBox for many workloads.",
                "",
                "QEMU + KVM (Linux) — Built into Linux kernel",
                "  Best performance on Linux. Requires setup but very powerful.",
                "  sudo apt install qemu-kvm libvirt-daemon virt-manager",
                "",
                "Parallels (Mac) — https://www.parallels.com",
                "  Best macOS performance. Commercial product.",
                "",
                "Qubes OS — https://www.qubes-os.org",
                "  Host OS built around VM compartmentalization. Most secure.",
                "  Separate VMs for: banking, browsing, work, OPSEC tasks",
            ],
        ),
        (
            "Recommended OPSEC VM Setup",
            Colors.GREEN,
            [
                "Create these VMs for different threat levels:",
                "",
                "  [VM 1 — Open]     Regular browsing, non-sensitive work",
                "  [VM 2 — Private]  Privacy browsing, tor exit, aliases",
                "  [VM 3 — Secure]   Password manager, PGP, banking",
                "  [VM 4 — Offline]  Air-gapped work, document creation",
                "  [VM 5 — Disposable] One-time tasks, delete after",
                "",
                "Rules:",
                "  • Never copy/paste between VM compartments",
                "  • Each VM has different accounts / browser profiles",
                "  • VPN/Tor per-VM network configuration",
                "  • Snapshot BEFORE risky work, revert AFTER",
            ],
        ),
        (
            "VirtualBox CLI Quick Reference",
            Colors.YELLOW,
            [
                "List VMs:       VBoxManage list vms",
                "Start VM:       VBoxManage startvm 'VM Name' --type headless",
                "Pause VM:       VBoxManage controlvm 'VM Name' pause",
                "Take snapshot:  VBoxManage snapshot 'VM Name' take 'clean'",
                "Restore snap:   VBoxManage snapshot 'VM Name' restore 'clean'",
                "Delete VM:      VBoxManage unregistervm 'VM Name' --delete",
                "Clone VM:       VBoxManage clonevm 'Source' --name 'Clone' --register",
            ],
        ),
        (
            "Network Modes for Privacy",
            Colors.RED,
            [
                "NAT (default): VM shares host IP. Some privacy but not isolated.",
                "Host-Only:     VM cannot reach internet. Use for offline work.",
                "Internal:      VMs communicate with each other, not host/internet.",
                "Bridged:       VM gets its own IP on network. Exposes MAC address.",
                "NAT Network:   Multiple VMs behind one NAT. Recommended for groups.",
                "",
                "For VPN-per-VM: Set VM network to internal, route traffic through",
                "a pfSense/OPNsense gateway VM with VPN enabled.",
            ],
        ),
    ]

    for title, color, items in sections:
        print(f"{color}{Colors.BOLD}[ {title} ]{Colors.RESET}")
        for item in items:
            print(f"  {item}")
        print()

    log_info("Displayed VM OPSEC guide")


def run() -> None:
    """Main entry point for the virtual machine module."""
    display_vm_guide()
