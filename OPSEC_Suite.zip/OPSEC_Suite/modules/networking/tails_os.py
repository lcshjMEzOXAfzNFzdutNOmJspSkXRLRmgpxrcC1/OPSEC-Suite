"""
Tails OS information and setup guide.
Tails is an amnesic live OS designed for maximum privacy.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_tails_guide() -> None:
    """Display a comprehensive Tails OS installation and usage guide."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}       TAILS OS — AMNESIC LIVE OPERATING SYSTEM{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}\n")

    sections = [
        (
            "What is Tails?",
            Colors.BLUE,
            [
                "Tails (The Amnesic Incognito Live System) is a live OS you boot from USB.",
                "Everything runs in RAM — no trace is left on the host computer.",
                "All internet traffic is routed through Tor automatically.",
                "Used by journalists, activists, and whistleblowers worldwide.",
                "Trusted by Edward Snowden, Glenn Greenwald, and the EFF.",
                "Download: https://tails.boum.org",
            ],
        ),
        (
            "Installation Steps",
            Colors.GREEN,
            [
                "1. Download Tails ISO from https://tails.boum.org/install/",
                "2. Verify the signature:",
                "   gpg --verify tails-amd64-*.img.sig tails-amd64-*.img",
                "3. Flash to USB (8GB+ recommended):",
                "   Linux:   dd if=tails.img of=/dev/sdX bs=16M status=progress",
                "   Windows: Use balenaEtcher (https://www.balena.io/etcher/)",
                "   Mac:     Use balenaEtcher",
                "4. Boot from USB (hold F12/F2/DEL during startup to select boot device)",
                "5. On first run, configure Persistent Storage (optional, encrypted)",
            ],
        ),
        (
            "Key Features",
            Colors.CYAN,
            [
                "Amnesic: Forgets everything after shutdown",
                "Tor-only: All traffic routes through Tor network",
                "Includes: Tor Browser, Thunderbird+Enigmail, KeePassXC",
                "Includes: LibreOffice, GIMP, Audacity, Inkscape",
                "Includes: MAT2 (metadata remover), GnuPG, OnionShare",
                "Persistent Storage: Encrypted partition for saved data",
                "Works on most x86-64 computers",
            ],
        ),
        (
            "Persistent Storage",
            Colors.YELLOW,
            [
                "Encrypted persistent storage lives on the USB beside the Tails OS.",
                "Can store: Tor Browser bookmarks, email settings, files, SSH keys.",
                "Protected by a passphrase using LUKS encryption.",
                "Enable at: Applications → Tails → Configure Persistent Volume",
                "Note: Persistence is optional — not enabling it gives maximum amnesia.",
            ],
        ),
        (
            "Security Tips",
            Colors.RED,
            [
                "Never install software that isn't in Tails' package repos",
                "Use Persistent Storage only for data that must survive reboots",
                "Do NOT maximize Tor Browser window (fingerprinting risk)",
                "Do NOT plug in USB drives unless you know what they contain",
                "Disable networking if doing offline sensitive work",
                "Use the Unsafe Browser only to log in to captive portals",
                "Never use Tails on a compromised machine",
                "Physically verify the Tails signature before installing",
            ],
        ),
        (
            "When to Use Tails",
            Colors.PURPLE,
            [
                "Communicating with journalists or sources",
                "Researching sensitive topics without leaving traces",
                "Using public computers without trusting the OS",
                "Accessing accounts you don't want linked to your main device",
                "Bypassing censorship in authoritarian environments",
                "Working with sensitive documents in hostile environments",
            ],
        ),
    ]

    for title, color, items in sections:
        print(f"{color}{Colors.BOLD}[ {title} ]{Colors.RESET}")
        for item in items:
            print(f"  {item}")
        print()

    log_info("Displayed Tails OS guide")


def run() -> None:
    """Main entry point for the Tails OS module."""
    display_tails_guide()
