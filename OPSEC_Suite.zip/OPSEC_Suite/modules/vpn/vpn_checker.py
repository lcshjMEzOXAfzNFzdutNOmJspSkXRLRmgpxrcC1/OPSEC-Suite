"""
VPN connection checker module.
Detects VPN status, DNS leak, WebRTC leak, and provider identification.
"""

import socket
import time
from typing import Dict, Any, List

import requests

from utils.colors import Colors
from utils.network import get_public_ip, get_ip_info
from utils.logger import log_info, log_warning


def check_vpn_active() -> Dict[str, Any]:
    """
    Check whether a VPN appears to be active by comparing IP characteristics.

    Returns:
        Dictionary with VPN detection result and metadata
    """
    try:
        resp = requests.get(
            "http://ip-api.com/json/?fields=status,proxy,hosting,isp,org,as,country,query",
            timeout=8
        )
        data = resp.json()
        if data.get("status") != "success":
            return {"error": "Could not retrieve IP info"}

        is_proxy = data.get("proxy", False)
        is_hosting = data.get("hosting", False)
        isp = data.get("isp", "").lower()
        org = data.get("org", "").lower()

        vpn_indicators = [
            "vpn", "nordvpn", "expressvpn", "mullvad", "protonvpn", "cyberghost",
            "surfshark", "private internet access", "tunnelbear", "hotspot shield",
            "ipvanish", "hma", "hide my ass", "windscribe", "privateinternetaccess",
            "torguard", "astrill",
        ]

        detected_vpn = is_proxy or is_hosting
        vpn_provider = None

        for indicator in vpn_indicators:
            if indicator in isp or indicator in org:
                detected_vpn = True
                vpn_provider = data.get("org", "Unknown VPN")
                break

        return {
            "ip": data.get("query"),
            "country": data.get("country"),
            "isp": data.get("isp"),
            "org": data.get("org"),
            "asn": data.get("as"),
            "vpn_detected": detected_vpn,
            "vpn_provider": vpn_provider,
            "is_proxy": is_proxy,
            "is_hosting": is_hosting,
        }
    except Exception as e:
        return {"error": str(e)}


def test_dns_leak() -> List[str]:
    """
    Test for DNS leaks by checking what DNS servers are resolving requests.

    Returns:
        List of detected DNS resolver IP addresses
    """
    test_domains = [
        "dns-leak.com",
        "bash.ws",
        "ipleak.net",
    ]
    resolvers = []

    for domain in test_domains:
        try:
            ips = socket.getaddrinfo(domain, None, socket.AF_INET)
            for ip_info in ips:
                ip = ip_info[4][0]
                if ip not in resolvers:
                    resolvers.append(ip)
        except Exception:
            pass

    try:
        resp = requests.get("https://1.1.1.1/cdn-cgi/trace", timeout=5)
        for line in resp.text.splitlines():
            if line.startswith("ip="):
                ip = line.split("=")[1].strip()
                if ip not in resolvers:
                    resolvers.append(ip)
                break
    except Exception:
        pass

    return resolvers


def full_vpn_test() -> None:
    """Run a comprehensive VPN and leak test and display results."""
    print(f"\n  {Colors.YELLOW}Running comprehensive VPN test...{Colors.RESET}\n")

    print(f"  {Colors.BOLD}[1/3] Checking VPN status...{Colors.RESET}")
    vpn_data = check_vpn_active()

    if "error" in vpn_data:
        print(f"  {Colors.RED}Error: {vpn_data['error']}{Colors.RESET}")
    else:
        vpn_detected = vpn_data.get("vpn_detected", False)
        status_color = Colors.GREEN if vpn_detected else Colors.RED
        status_text = "ACTIVE" if vpn_detected else "NOT DETECTED"

        print(f"\n  VPN Status:   {status_color}{Colors.BOLD}{status_text}{Colors.RESET}")
        print(f"  Your IP:      {vpn_data.get('ip')}")
        print(f"  Country:      {vpn_data.get('country')}")
        print(f"  ISP:          {vpn_data.get('isp')}")
        print(f"  Organization: {vpn_data.get('org')}")
        if vpn_data.get("vpn_provider"):
            print(f"  VPN Provider: {Colors.GREEN}{vpn_data['vpn_provider']}{Colors.RESET}")

    print(f"\n  {Colors.BOLD}[2/3] Testing for DNS leaks...{Colors.RESET}")
    resolvers = test_dns_leak()
    if resolvers:
        print(f"\n  DNS resolvers detected:")
        for r in resolvers:
            info = get_ip_info(r)
            country = info.get("country", "?")
            isp = info.get("isp", "?")[:40]
            print(f"  {Colors.CYAN}→{Colors.RESET} {r:<18} {country} — {isp}")
    else:
        print(f"  {Colors.YELLOW}Could not determine DNS resolvers.{Colors.RESET}")

    print(f"\n  {Colors.BOLD}[3/3] IPv6 leak check...{Colors.RESET}")
    try:
        resp = requests.get("https://api6.ipify.org", timeout=5)
        ipv6 = resp.text.strip()
        print(f"\n  {Colors.RED}[!] IPv6 LEAK detected: {ipv6}{Colors.RESET}")
        print(f"  {Colors.YELLOW}Disable IPv6 in OS or use a VPN with IPv6 support.{Colors.RESET}")
    except Exception:
        print(f"  {Colors.GREEN}✓ No IPv6 detected (good){Colors.RESET}")

    print(f"\n  {Colors.YELLOW}For comprehensive test: https://ipleak.net{Colors.RESET}")
    log_info("VPN and leak test completed")


def run() -> None:
    """Main entry point for the VPN checker module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}        VPN STATUS CHECKER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Quick VPN status check")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Full VPN + DNS + IPv6 leak test")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    elif choice == "1":
        print(f"\n  {Colors.YELLOW}Checking VPN status...{Colors.RESET}")
        data = check_vpn_active()
        if "error" not in data:
            vpn_color = Colors.GREEN if data["vpn_detected"] else Colors.RED
            status = "VPN ACTIVE" if data["vpn_detected"] else "NO VPN DETECTED"
            print(f"\n  Status: {vpn_color}{Colors.BOLD}{status}{Colors.RESET}")
            print(f"  IP: {data.get('ip')} ({data.get('country')})")
            print(f"  ISP: {data.get('isp')}")
        else:
            print(f"  {Colors.RED}Error: {data['error']}{Colors.RESET}")

    elif choice == "2":
        full_vpn_test()
