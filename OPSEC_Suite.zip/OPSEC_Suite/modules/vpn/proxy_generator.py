"""
Proxy list fetcher module.
Retrieves free proxy lists from public sources.
"""

import requests
from typing import List, Dict

from utils.colors import Colors
from utils.logger import log_info, log_warning

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False


def fetch_proxies_from_proxylist() -> List[str]:
    """
    Fetch free proxy list from ProxyScrape API.

    Returns:
        List of proxy strings in ip:port format
    """
    try:
        resp = requests.get(
            "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http"
            "&timeout=10000&country=all&ssl=all&anonymity=all",
            timeout=15,
        )
        if resp.status_code == 200:
            proxies = [line.strip() for line in resp.text.splitlines() if line.strip()]
            log_info(f"Fetched {len(proxies)} proxies from ProxyScrape")
            return proxies
    except Exception as e:
        log_warning(f"ProxyScrape fetch error: {e}")
    return []


def fetch_proxies_free_proxy_list() -> List[Dict[str, str]]:
    """
    Fetch from free-proxy-list.net (HTML scrape fallback).

    Returns:
        List of proxy dictionaries with ip, port, country, anonymity
    """
    try:
        resp = requests.get(
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
            timeout=15,
        )
        if resp.status_code == 200:
            lines = [l.strip() for l in resp.text.splitlines() if l.strip()]
            return [{"proxy": line, "protocol": "http"} for line in lines]
    except Exception as e:
        log_warning(f"GitHub proxy list fetch error: {e}")
    return []


def fetch_socks5_proxies() -> List[str]:
    """
    Fetch SOCKS5 proxy list from public sources.

    Returns:
        List of proxy strings
    """
    try:
        resp = requests.get(
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
            timeout=15,
        )
        if resp.status_code == 200:
            return [line.strip() for line in resp.text.splitlines() if line.strip()]
    except Exception as e:
        log_warning(f"SOCKS5 list fetch error: {e}")
    return []


def save_proxy_list(proxies: List[str], filename: str = "proxies.txt") -> None:
    """
    Save a proxy list to a file.

    Args:
        proxies: List of proxy strings
        filename: Output file path
    """
    try:
        with open(filename, "w") as f:
            f.write("\n".join(proxies))
        log_info(f"Saved {len(proxies)} proxies to {filename}")
    except Exception as e:
        log_warning(f"Could not save proxies: {e}")


def run() -> None:
    """Main entry point for the proxy generator/fetcher module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}      FREE PROXY LIST FETCHER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")
    print(f"\n  {Colors.YELLOW}[!] Free proxies are unreliable. Use paid proxies for actual OPSEC.{Colors.RESET}\n")
    print(f"  {Colors.CYAN}1.{Colors.RESET} Fetch HTTP proxies (ProxyScrape)")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Fetch HTTP proxies (GitHub list)")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Fetch SOCKS5 proxies (GitHub list)")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    proxies = []
    if choice == "1":
        print(f"\n  {Colors.YELLOW}Fetching from ProxyScrape...{Colors.RESET}")
        proxies = fetch_proxies_from_proxylist()
    elif choice == "2":
        print(f"\n  {Colors.YELLOW}Fetching from GitHub HTTP list...{Colors.RESET}")
        data = fetch_proxies_free_proxy_list()
        proxies = [d["proxy"] for d in data]
    elif choice == "3":
        print(f"\n  {Colors.YELLOW}Fetching SOCKS5 proxies...{Colors.RESET}")
        proxies = fetch_socks5_proxies()

    if proxies:
        print(f"\n  {Colors.GREEN}✓ Fetched {len(proxies)} proxies{Colors.RESET}")
        print(f"\n  First 10:")
        for p in proxies[:10]:
            print(f"    {Colors.CYAN}{p}{Colors.RESET}")

        save_choice = input(f"\n  Save to file? [Y/n]: ").strip().lower()
        if save_choice != "n":
            filename = input("  Filename [proxies.txt]: ").strip() or "proxies.txt"
            save_proxy_list(proxies, filename)
            print(f"  {Colors.GREEN}✓ Saved to {filename}{Colors.RESET}")
    else:
        print(f"\n  {Colors.RED}Failed to fetch proxies. Check your internet connection.{Colors.RESET}")
