"""
Paid VPN detailed comparison and setup guide.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_wireguard_setup() -> None:
    """Display WireGuard VPN setup guide."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== WireGuard VPN Setup Guide ==={Colors.RESET}\n")

    steps = [
        ("Install WireGuard",
         "Linux: sudo apt install wireguard\nMac: brew install wireguard-tools\nWindows: Download from wireguard.com"),
        ("Get config from VPN provider",
         "Mullvad/ProtonVPN provide .conf files from their dashboard"),
        ("Install config",
         "Linux: sudo cp mullvad-us.conf /etc/wireguard/wg0.conf\nWindows/Mac: Import via app"),
        ("Connect",
         "Linux: sudo wg-quick up wg0\nOr: sudo systemctl start wg-quick@wg0"),
        ("Auto-start on boot",
         "sudo systemctl enable wg-quick@wg0"),
        ("Check status",
         "sudo wg show"),
        ("Disconnect",
         "sudo wg-quick down wg0"),
    ]

    for step, cmd in steps:
        print(f"  {Colors.CYAN}→{Colors.RESET} {Colors.BOLD}{step}{Colors.RESET}")
        for line in cmd.split("\n"):
            print(f"    {Colors.DIM}{line}{Colors.RESET}")
        print()

    print(f"  {Colors.BOLD}Kill Switch (Linux with UFW):{Colors.RESET}")
    kill_switch = [
        "sudo ufw default deny incoming",
        "sudo ufw default deny outgoing",
        "sudo ufw allow out on wg0 from any to any  # Allow VPN traffic",
        "sudo ufw allow out 51820/udp  # WireGuard port",
        "sudo ufw enable",
    ]
    for cmd in kill_switch:
        print(f"  {Colors.DIM}{cmd}{Colors.RESET}")


def display_vpn_comparison() -> None:
    """Display a detailed comparison of top paid VPNs for OPSEC."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Top VPNs for Privacy/OPSEC (Detailed) ==={Colors.RESET}\n")

    print(f"  {Colors.BOLD}{'VPN':<16} {'Price':<12} {'Anon':<5} {'Protocol':<12} {'Jurisdiction'}{Colors.RESET}")
    print(f"  {'─'*60}")

    vpns = [
        ("Mullvad", "€5/flat", "Full", "WG/OVPN", "Sweden"),
        ("ProtonVPN", "$4-10/mo", "Email", "WG/OVPN", "Switzerland"),
        ("IVPN", "$6/mo", "Full", "WG/OVPN", "Gibraltar"),
        ("NordVPN", "$3-12/mo", "Email", "NordLynx", "Panama"),
        ("ExpressVPN", "$8-13/mo", "Email", "Lightway", "BVI"),
        ("Surfshark", "$2-13/mo", "Email", "WG/OVPN", "Netherlands"),
        ("AirVPN", "€7/mo", "Email", "OpenVPN", "Italy"),
    ]

    for name, price, anon_req, protocol, jurisdiction in vpns:
        anon_color = Colors.GREEN if anon_req == "Full" else Colors.YELLOW
        print(f"  {Colors.CYAN}{name:<16}{Colors.RESET} {price:<12} {anon_color}{anon_req:<5}{Colors.RESET} {protocol:<12} {jurisdiction}")

    print(f"\n  {Colors.BOLD}Anon = 'Full' means no email or personal info required for signup.{Colors.RESET}")
    print(f"\n  {Colors.BOLD}Key factors for OPSEC VPN selection:{Colors.RESET}")
    factors = [
        "No logs policy — independently audited",
        "Anonymous signup (no email/name required)",
        "Accepts cryptocurrency or cash",
        "WireGuard protocol for best security/speed",
        "Kill switch feature (blocks traffic if VPN drops)",
        "DNS leak protection built-in",
        "Open-source apps preferred",
        "Based outside 14-Eyes surveillance alliance",
    ]
    for f in factors:
        print(f"    {Colors.CYAN}→{Colors.RESET} {f}")

    log_info("Displayed paid VPN comparison")


def run() -> None:
    """Main entry point for the paid VPN module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}      PAID VPN GUIDE & COMPARISON{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} VPN comparison table")
    print(f"  {Colors.CYAN}2.{Colors.RESET} WireGuard setup guide")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        display_vpn_comparison()
    elif choice == "2":
        display_wireguard_setup()
