"""
Proxy verifier module.
Verifies proxy anonymity and country of origin.
"""

import requests
from typing import Dict, Any

from utils.colors import Colors
from utils.network import get_ip_info
from utils.logger import log_info


def verify_proxy_anonymity(proxy: str) -> Dict[str, Any]:
    """
    Verify proxy anonymity level by inspecting HTTP headers seen by remote server.

    Args:
        proxy: Proxy string (ip:port or http://ip:port)

    Returns:
        Detailed anonymity report dictionary
    """
    if not proxy.startswith("http"):
        proxy = f"http://{proxy}"

    proxies = {"http": proxy, "https": proxy}

    try:
        resp = requests.get("http://httpbin.org/headers", proxies=proxies, timeout=10)
        headers = resp.json().get("headers", {})

        revealing_headers = {
            "X-Forwarded-For": headers.get("X-Forwarded-For"),
            "X-Real-Ip": headers.get("X-Real-Ip"),
            "Via": headers.get("Via"),
            "X-ProxyUser-Ip": headers.get("X-ProxyUser-Ip"),
            "Proxy-Connection": headers.get("Proxy-Connection"),
        }
        revealing_headers = {k: v for k, v in revealing_headers.items() if v}

        if "X-Forwarded-For" in revealing_headers or "X-Real-Ip" in revealing_headers:
            anonymity = "Transparent"
        elif "Via" in revealing_headers:
            anonymity = "Anonymous"
        else:
            anonymity = "Elite"

        ip_resp = requests.get("http://httpbin.org/ip", proxies=proxies, timeout=10)
        seen_ip = ip_resp.json().get("origin", "Unknown")

        geo = get_ip_info(seen_ip.split(",")[0].strip())

        return {
            "proxy": proxy,
            "anonymity": anonymity,
            "seen_ip": seen_ip,
            "country": geo.get("country", "Unknown"),
            "isp": geo.get("isp", "Unknown"),
            "revealing_headers": revealing_headers,
            "all_headers": headers,
        }
    except Exception as e:
        return {"proxy": proxy, "error": str(e)}


def run() -> None:
    """Main entry point for the proxy verifier module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         PROXY VERIFIER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")

    proxy = input(f"\n  Proxy to verify (ip:port): ").strip()
    if not proxy:
        return

    print(f"\n  {Colors.YELLOW}Verifying proxy anonymity...{Colors.RESET}")
    result = verify_proxy_anonymity(proxy)

    if "error" in result:
        print(f"\n  {Colors.RED}Error: {result['error']}{Colors.RESET}")
        return

    anon = result.get("anonymity", "Unknown")
    anon_colors = {"Elite": Colors.GREEN, "Anonymous": Colors.YELLOW, "Transparent": Colors.RED}
    anon_color = anon_colors.get(anon, Colors.WHITE)

    print(f"\n  {Colors.BOLD}Verification Report:{Colors.RESET}")
    print(f"  Proxy:      {result['proxy']}")
    print(f"  Anonymity:  {anon_color}{Colors.BOLD}{anon}{Colors.RESET}")
    print(f"  Seen IP:    {result.get('seen_ip')}")
    print(f"  Country:    {result.get('country')}")
    print(f"  ISP:        {result.get('isp')}")

    if result.get("revealing_headers"):
        print(f"\n  {Colors.RED}Revealing Headers (exposing you):{Colors.RESET}")
        for h, v in result["revealing_headers"].items():
            print(f"  {Colors.CYAN}{h}:{Colors.RESET} {v}")
    else:
        print(f"\n  {Colors.GREEN}✓ No revealing proxy headers detected{Colors.RESET}")

    log_info(f"Verified proxy: {proxy} — {anon}")
