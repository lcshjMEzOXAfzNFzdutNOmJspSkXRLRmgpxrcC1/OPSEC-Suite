"""
Proxy checker module.
Tests a list of proxies for connectivity, anonymity level, and speed.
"""

import concurrent.futures
import time
from typing import Dict, List, Tuple, Any, Optional

import requests

from utils.colors import Colors
from utils.logger import log_info, log_warning

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False


def test_proxy(proxy: str, timeout: int = 10) -> Dict[str, Any]:
    """
    Test a single proxy for connectivity and determine its anonymity level.

    Anonymity levels:
      Transparent: Your IP is visible (X-Forwarded-For header present)
      Anonymous:   Proxy detected but real IP hidden
      Elite:       No proxy headers sent — highest anonymity

    Args:
        proxy: Proxy string in format 'ip:port' or 'http://ip:port'
        timeout: Connection timeout in seconds

    Returns:
        Dictionary with proxy status, speed, and anonymity level
    """
    if not proxy.startswith("http"):
        proxy = f"http://{proxy}"

    proxies = {"http": proxy, "https": proxy}
    start = time.time()

    try:
        resp = requests.get(
            "http://httpbin.org/get",
            proxies=proxies,
            timeout=timeout,
        )
        elapsed = round((time.time() - start) * 1000)

        if resp.status_code == 200:
            data = resp.json()
            origin = data.get("origin", "")
            headers = data.get("headers", {})

            forwarded_for = headers.get("X-Forwarded-For", "")
            via = headers.get("Via", "")

            if forwarded_for:
                anonymity = "Transparent"
            elif via:
                anonymity = "Anonymous"
            else:
                anonymity = "Elite"

            return {
                "proxy": proxy,
                "status": "alive",
                "speed_ms": elapsed,
                "anonymity": anonymity,
                "country": "",
                "ip": origin,
            }
        else:
            return {"proxy": proxy, "status": "dead", "error": f"HTTP {resp.status_code}"}

    except requests.exceptions.ProxyError:
        return {"proxy": proxy, "status": "dead", "error": "Proxy refused connection"}
    except requests.exceptions.ConnectTimeout:
        return {"proxy": proxy, "status": "dead", "error": "Timeout"}
    except Exception as e:
        return {"proxy": proxy, "status": "dead", "error": str(e)[:60]}


def check_proxy_list(proxies: List[str], workers: int = 20, timeout: int = 10) -> Tuple[List, List]:
    """
    Test a list of proxies concurrently.

    Args:
        proxies: List of proxy strings
        workers: Number of concurrent threads
        timeout: Per-proxy timeout in seconds

    Returns:
        Tuple of (alive_proxies, dead_proxies)
    """
    alive = []
    dead = []

    iterator = proxies
    if TQDM_AVAILABLE:
        iterator = tqdm(proxies, desc="Testing proxies")

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(test_proxy, p, timeout): p for p in proxies}
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result.get("status") == "alive":
                alive.append(result)
            else:
                dead.append(result)

    alive.sort(key=lambda x: x.get("speed_ms", 99999))
    return alive, dead


def load_proxies_from_file(filepath: str) -> List[str]:
    """
    Load proxy list from a text file (one proxy per line).

    Args:
        filepath: Path to the proxy list file

    Returns:
        List of proxy strings
    """
    try:
        with open(filepath, "r") as f:
            lines = [line.strip() for line in f if line.strip() and not line.startswith("#")]
        return lines
    except FileNotFoundError:
        return []
    except Exception as e:
        log_warning(f"Error loading proxy list: {e}")
        return []


def display_results(alive: List[Dict], dead: List[Dict]) -> None:
    """Display proxy check results."""
    total = len(alive) + len(dead)
    print(f"\n  {Colors.BOLD}Results: {len(alive)}/{total} proxies alive{Colors.RESET}\n")

    if alive:
        print(f"  {Colors.GREEN}{Colors.BOLD}{'Proxy':<30} {'Speed':>8}  {'Anonymity'}{Colors.RESET}")
        print(f"  {'─'*58}")
        for p in alive[:30]:
            proxy_display = p["proxy"].replace("http://", "")[:28]
            speed = f"{p.get('speed_ms', '?')}ms"
            anon = p.get("anonymity", "?")
            anon_color = Colors.GREEN if anon == "Elite" else Colors.YELLOW if anon == "Anonymous" else Colors.RED
            print(f"  {Colors.GREEN}{proxy_display:<30}{Colors.RESET} {speed:>8}  {anon_color}{anon}{Colors.RESET}")

    if alive and len(alive) > 30:
        print(f"  ... and {len(alive) - 30} more alive proxies")


def run() -> None:
    """Main entry point for the proxy checker module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         PROXY CHECKER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Test single proxy")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Test proxy list from file")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Enter proxies manually")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    elif choice == "1":
        proxy = input("  Proxy (ip:port or http://ip:port): ").strip()
        if not proxy:
            return
        print(f"\n  {Colors.YELLOW}Testing {proxy}...{Colors.RESET}")
        result = test_proxy(proxy)
        status_color = Colors.GREEN if result["status"] == "alive" else Colors.RED
        print(f"\n  Status:    {status_color}{result['status'].upper()}{Colors.RESET}")
        if result["status"] == "alive":
            print(f"  Speed:     {result.get('speed_ms')}ms")
            print(f"  Anonymity: {result.get('anonymity')}")
            print(f"  Seen IP:   {result.get('ip')}")
        else:
            print(f"  Error:     {result.get('error')}")
        log_info(f"Tested proxy: {proxy}")

    elif choice == "2":
        filepath = input("  Proxy list file path: ").strip()
        proxies = load_proxies_from_file(filepath)
        if not proxies:
            print(f"  {Colors.RED}No proxies loaded from {filepath}{Colors.RESET}")
            return
        print(f"\n  {Colors.YELLOW}Testing {len(proxies)} proxies...{Colors.RESET}")
        alive, dead = check_proxy_list(proxies)
        display_results(alive, dead)
        log_info(f"Checked {len(proxies)} proxies: {len(alive)} alive")

    elif choice == "3":
        print(f"  Enter proxies (one per line, empty line to finish):")
        proxies = []
        while True:
            line = input("  ").strip()
            if not line:
                break
            proxies.append(line)

        if not proxies:
            return
        print(f"\n  {Colors.YELLOW}Testing {len(proxies)} proxies...{Colors.RESET}")
        alive, dead = check_proxy_list(proxies)
        display_results(alive, dead)
