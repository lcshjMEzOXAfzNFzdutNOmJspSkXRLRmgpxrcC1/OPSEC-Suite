"""
IP lookup and geolocation module.
Shows current IP, location, ISP, and VPN detection info.
"""

from typing import Dict, Any

import requests

from utils.colors import Colors
from utils.network import get_public_ip, get_ip_info
from utils.logger import log_info


def detect_vpn(ip: str = "") -> Dict[str, Any]:
    """
    Attempt to detect if an IP is a VPN, proxy, or hosting IP using ip-api.com.

    Args:
        ip: IP address to check. Defaults to public IP.

    Returns:
        Dictionary with VPN/proxy detection data
    """
    target = ip if ip else ""
    try:
        resp = requests.get(
            f"http://ip-api.com/json/{target}?fields=status,message,country,regionName,city,"
            f"zip,lat,lon,timezone,isp,org,as,proxy,hosting,mobile,query",
            timeout=8
        )
        data = resp.json()
        if data.get("status") == "success":
            return data
    except Exception as e:
        return {"error": str(e)}
    return {"error": "Failed to retrieve data"}


def display_ip_info(data: Dict[str, Any]) -> None:
    """
    Display IP geolocation and VPN detection results.

    Args:
        data: Result from get_ip_info() or detect_vpn()
    """
    if data.get("status") == "fail" or "error" in data:
        print(f"\n  {Colors.RED}Error: {data.get('message') or data.get('error')}{Colors.RESET}")
        return

    print(f"\n  {Colors.BOLD}{'─'*46}{Colors.RESET}")
    fields = [
        ("IP Address", "query"),
        ("Country", "country"),
        ("Region", "regionName"),
        ("City", "city"),
        ("ZIP/Post", "zip"),
        ("Latitude", "lat"),
        ("Longitude", "lon"),
        ("Timezone", "timezone"),
        ("ISP", "isp"),
        ("Organization", "org"),
        ("ASN", "as"),
    ]

    for label, key in fields:
        val = data.get(key, "N/A")
        if val and str(val) != "N/A":
            print(f"  {Colors.CYAN}{label:<18}{Colors.RESET}: {Colors.WHITE}{val}{Colors.RESET}")

    is_proxy = data.get("proxy", False)
    is_hosting = data.get("hosting", False)
    is_mobile = data.get("mobile", False)

    proxy_color = Colors.GREEN if is_proxy else Colors.DIM
    hosting_color = Colors.YELLOW if is_hosting else Colors.DIM
    mobile_color = Colors.CYAN if is_mobile else Colors.DIM

    print(f"\n  {Colors.BOLD}Detection:{Colors.RESET}")
    print(f"  {Colors.CYAN}{'VPN/Proxy':<18}{Colors.RESET}: {proxy_color}{'Yes' if is_proxy else 'No'}{Colors.RESET}")
    print(f"  {Colors.CYAN}{'Hosting/DC':<18}{Colors.RESET}: {hosting_color}{'Yes' if is_hosting else 'No'}{Colors.RESET}")
    print(f"  {Colors.CYAN}{'Mobile':<18}{Colors.RESET}: {mobile_color}{'Yes' if is_mobile else 'No'}{Colors.RESET}")

    if is_hosting:
        print(f"\n  {Colors.YELLOW}[!] This IP is from a datacenter/hosting provider (typical for VPN exit nodes){Colors.RESET}")
    if is_proxy:
        print(f"  {Colors.GREEN}[✓] VPN or proxy detected{Colors.RESET}")
    else:
        print(f"\n  {Colors.RED}[!] No VPN/proxy detected — your real IP may be exposed{Colors.RESET}")


def get_ipv6_address() -> str:
    """
    Retrieve the public IPv6 address.

    Returns:
        IPv6 address string or 'Not available'
    """
    services = [
        "https://api6.ipify.org",
        "https://ipv6.icanhazip.com",
        "https://v6.ident.me",
    ]
    for url in services:
        try:
            resp = requests.get(url, timeout=5)
            if resp.status_code == 200:
                return resp.text.strip()
        except Exception:
            continue
    return "Not available (no IPv6 or disabled)"


def run() -> None:
    """Main entry point for the IP lookup module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}       IP LOOKUP & VPN DETECTION{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Check current IP and location")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Check specific IP")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Check for IPv6 exposure")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    elif choice == "1":
        print(f"\n  {Colors.YELLOW}Retrieving your IP information...{Colors.RESET}")
        data = detect_vpn()
        display_ip_info(data)
        log_info(f"IP lookup performed for public IP")

    elif choice == "2":
        ip = input("  IP address to look up: ").strip()
        if not ip:
            return
        print(f"\n  {Colors.YELLOW}Looking up {ip}...{Colors.RESET}")
        data = detect_vpn(ip)
        display_ip_info(data)
        log_info(f"IP lookup for: {ip}")

    elif choice == "3":
        print(f"\n  {Colors.YELLOW}Checking IPv6 exposure...{Colors.RESET}")
        ipv4 = get_public_ip()
        ipv6 = get_ipv6_address()
        print(f"\n  {Colors.CYAN}IPv4:{Colors.RESET} {ipv4}")
        print(f"  {Colors.CYAN}IPv6:{Colors.RESET} {ipv6}")
        if "Not available" not in ipv6:
            print(f"\n  {Colors.RED}[!] IPv6 is active — VPNs that don't handle IPv6 may leak your real IP!{Colors.RESET}")
            print(f"  {Colors.YELLOW}Mitigation: Disable IPv6 in OS settings or use a VPN with IPv6 support.{Colors.RESET}")
        else:
            print(f"\n  {Colors.GREEN}✓ No IPv6 address detected.{Colors.RESET}")
