"""
Free proxy sources menu module.
Curates and displays sources for free public proxies.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_free_proxy_sources() -> None:
    """Display curated sources for free public proxy lists."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}          FREE PROXY SOURCES{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}")
    print(f"\n  {Colors.RED}[!] WARNING: Free proxies are unreliable, slow, and may log your traffic.{Colors.RESET}")
    print(f"  {Colors.YELLOW}    Use paid proxies or VPNs for actual OPSEC tasks.{Colors.RESET}\n")

    sources = [
        {
            "name": "ProxyScrape",
            "url": "https://proxyscrape.com/free-proxy-list",
            "api": "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http",
            "types": "HTTP, HTTPS, SOCKS4, SOCKS5",
            "update": "Every few minutes",
        },
        {
            "name": "GitHub: TheSpeedX PROXY-List",
            "url": "https://github.com/TheSpeedX/PROXY-List",
            "api": "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
            "types": "HTTP, SOCKS4, SOCKS5",
            "update": "Hourly",
        },
        {
            "name": "GitHub: clarketm proxy-list",
            "url": "https://github.com/clarketm/proxy-list",
            "api": "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-status.txt",
            "types": "HTTP, HTTPS",
            "update": "Weekly",
        },
        {
            "name": "SpysOne",
            "url": "https://spys.one/en/free-proxy-list/",
            "api": "Manual download only",
            "types": "HTTP, HTTPS, SOCKS",
            "update": "Continuously",
        },
        {
            "name": "HideMyName",
            "url": "https://hidemy.name/en/proxy-list/",
            "api": "Manual download only",
            "types": "HTTP, HTTPS, SOCKS4, SOCKS5",
            "update": "Continuously",
        },
        {
            "name": "Free Proxy List (.net)",
            "url": "https://free-proxy-list.net",
            "api": "API: https://www.proxyscan.io/api/proxy?format=txt&type=http",
            "types": "HTTP, HTTPS",
            "update": "Every 10 min",
        },
    ]

    for s in sources:
        print(f"  {Colors.BOLD}{Colors.CYAN}{s['name']}{Colors.RESET}")
        print(f"  Website: {s['url']}")
        print(f"  API:     {Colors.DIM}{s['api']}{Colors.RESET}")
        print(f"  Types:   {s['types']}")
        print(f"  Updates: {s['update']}\n")

    print(f"\n{Colors.BOLD}{Colors.YELLOW}[ Tips for Free Proxies ]{Colors.RESET}")
    tips = [
        "Always verify the proxy before using it with the proxy checker",
        "Elite proxies are most anonymous but rare in free lists",
        "SOCKS5 proxies support more protocols and are more versatile",
        "Use Tor instead of free proxies for anonymity — it's more reliable",
        "Free proxies can inject ads, steal credentials, or log traffic",
        "Test the same proxy multiple times — many have intermittent availability",
        "For automation: use rotating proxy services (Webshare, Bright Data, etc.)",
    ]
    for tip in tips:
        print(f"  {Colors.CYAN}→{Colors.RESET} {tip}")

    log_info("Displayed free proxy sources")


def run() -> None:
    """Main entry point for the free proxy menu module."""
    display_free_proxy_sources()
