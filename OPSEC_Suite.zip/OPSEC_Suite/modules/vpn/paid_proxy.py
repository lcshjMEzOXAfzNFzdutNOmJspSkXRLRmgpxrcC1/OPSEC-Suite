"""
Paid proxy providers information module.
Compares commercial proxy services for OPSEC use.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_paid_proxies() -> None:
    """Display information about reputable paid proxy services."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*58}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}        PAID PROXY SERVICES OVERVIEW{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*58}{Colors.RESET}\n")
    print(f"  {Colors.YELLOW}[!] For true OPSEC, use a VPN + proxy chain rather than proxy alone.{Colors.RESET}\n")

    services = [
        {
            "name": "Oxylabs",
            "url": "https://oxylabs.io",
            "types": "Residential, Datacenter, SOCKS5",
            "price": "$15+/GB residential",
            "ips": "100M+ IPs",
            "use_case": "Web scraping, geo-unlocking",
        },
        {
            "name": "Bright Data (ex-Luminati)",
            "url": "https://brightdata.com",
            "types": "Residential, Mobile, ISP",
            "price": "$8.4+/GB",
            "ips": "72M+ IPs",
            "use_case": "Scraping, research, ad verification",
        },
        {
            "name": "Webshare",
            "url": "https://www.webshare.io",
            "types": "Datacenter, Residential",
            "price": "Free tier / $5+/mo",
            "ips": "30M+ IPs",
            "use_case": "Automation, affordable entry-level",
        },
        {
            "name": "Smartproxy",
            "url": "https://smartproxy.com",
            "types": "Residential, Datacenter, SOCKS5",
            "price": "$14+/GB",
            "ips": "55M+ IPs",
            "use_case": "Scraping, social media automation",
        },
        {
            "name": "IPRoyal",
            "url": "https://iproyal.com",
            "types": "Residential, Static ISP, SOCKS5",
            "price": "$1.75/GB residential",
            "ips": "32M+ IPs",
            "use_case": "Affordable residential proxies",
        },
        {
            "name": "ProxyRack",
            "url": "https://www.proxyrack.com",
            "types": "Residential, Rotating",
            "price": "$49/mo starter",
            "ips": "5M+ IPs",
            "use_case": "Rotating residential proxies",
        },
    ]

    for s in services:
        print(f"  {Colors.BOLD}{Colors.CYAN}{s['name']}{Colors.RESET}")
        print(f"  URL:       {s['url']}")
        print(f"  Types:     {s['types']}")
        print(f"  Price:     {Colors.YELLOW}{s['price']}{Colors.RESET}")
        print(f"  IPs:       {s['ips']}")
        print(f"  Best for:  {s['use_case']}\n")

    print(f"{Colors.BOLD}{Colors.BLUE}[ Proxy Types Explained ]{Colors.RESET}")
    explanations = [
        ("Datacenter", "Cheap, fast, but easily detected as proxy/VPN by sites"),
        ("Residential", "Real ISP IPs, harder to detect, more expensive"),
        ("Mobile", "Mobile carrier IPs, hardest to detect, most expensive"),
        ("ISP/Static", "Real ISP IPs but static — good balance"),
        ("Rotating", "IP changes per request — hard to track/block"),
        ("SOCKS5", "Protocol that supports UDP and more — better for privacy"),
    ]
    for ptype, desc in explanations:
        print(f"  {Colors.CYAN}{ptype:<15}{Colors.RESET}: {desc}")

    log_info("Displayed paid proxy services")


def run() -> None:
    """Main entry point for the paid proxy module."""
    display_paid_proxies()
