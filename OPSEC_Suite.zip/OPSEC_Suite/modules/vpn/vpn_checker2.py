"""
Extended VPN checker — tests multiple APIs for comprehensive VPN detection.
"""

import requests
from typing import Dict, Any, List

from utils.colors import Colors
from utils.logger import log_info


def check_multiple_apis(ip: str = "") -> List[Dict[str, Any]]:
    """
    Check an IP against multiple detection APIs for comprehensive analysis.

    Args:
        ip: IP to check, defaults to current public IP

    Returns:
        List of results from each API
    """
    results = []

    # ip-api.com
    try:
        resp = requests.get(
            f"http://ip-api.com/json/{ip}?fields=status,proxy,hosting,mobile,isp,org,country,query",
            timeout=8
        )
        data = resp.json()
        if data.get("status") == "success":
            results.append({
                "source": "ip-api.com",
                "ip": data.get("query"),
                "vpn": data.get("proxy", False),
                "hosting": data.get("hosting", False),
                "mobile": data.get("mobile", False),
                "country": data.get("country"),
                "isp": data.get("isp"),
                "org": data.get("org"),
            })
    except Exception:
        pass

    # ipinfo.io (no key needed for basic info)
    try:
        resp = requests.get(
            f"https://ipinfo.io/{ip}/json" if ip else "https://ipinfo.io/json",
            timeout=8,
            headers={"Accept": "application/json"}
        )
        if resp.status_code == 200:
            data = resp.json()
            results.append({
                "source": "ipinfo.io",
                "ip": data.get("ip"),
                "country": data.get("country"),
                "org": data.get("org"),
                "city": data.get("city"),
                "region": data.get("region"),
                "timezone": data.get("timezone"),
                "vpn": None,
            })
    except Exception:
        pass

    # Cloudflare trace
    try:
        resp = requests.get("https://1.1.1.1/cdn-cgi/trace", timeout=5)
        info = {}
        for line in resp.text.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                info[k] = v
        results.append({
            "source": "Cloudflare",
            "ip": info.get("ip"),
            "country": info.get("loc"),
            "warp": info.get("warp", "off"),
            "gateway": info.get("gateway", "off"),
            "vpn": info.get("warp") == "on",
        })
    except Exception:
        pass

    return results


def display_multi_api_results(results: List[Dict[str, Any]]) -> None:
    """Display multi-API VPN detection results."""
    print(f"\n  {Colors.BOLD}Multi-API Analysis Results:{Colors.RESET}\n")
    for r in results:
        print(f"  {Colors.BOLD}{Colors.BLUE}[ {r['source']} ]{Colors.RESET}")
        for k, v in r.items():
            if k == "source":
                continue
            if k == "vpn" and v is not None:
                color = Colors.GREEN if v else Colors.RED
                print(f"    {Colors.CYAN}{k:<12}{Colors.RESET}: {color}{v}{Colors.RESET}")
            else:
                print(f"    {Colors.CYAN}{k:<12}{Colors.RESET}: {v}")
        print()


def run() -> None:
    """Main entry point for the extended VPN checker module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}     EXTENDED VPN DETECTION (MULTI-API){Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Check current IP across multiple APIs")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Check specific IP")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "0":
        return

    ip = ""
    if choice == "2":
        ip = input("  IP address: ").strip()

    print(f"\n  {Colors.YELLOW}Querying multiple APIs...{Colors.RESET}")
    results = check_multiple_apis(ip)
    if results:
        display_multi_api_results(results)
    else:
        print(f"  {Colors.RED}No results obtained. Check your internet connection.{Colors.RESET}")

    log_info(f"Extended VPN check performed for: {ip or 'current IP'}")
