"""
VPN browser extension recommendations module.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_vpn_extensions() -> None:
    """Display recommended VPN and privacy browser extensions."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*58}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}     VPN & PRIVACY BROWSER EXTENSIONS{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*58}{Colors.RESET}\n")

    print(f"  {Colors.RED}[!] Browser-based VPN extensions provide limited protection.{Colors.RESET}")
    print(f"  {Colors.YELLOW}    They only protect browser traffic, not other apps.{Colors.RESET}")
    print(f"  {Colors.GREEN}    Use a full system VPN (WireGuard/OpenVPN) for complete coverage.{Colors.RESET}\n")

    extensions = [
        {
            "name": "ProtonVPN Extension",
            "browser": "Chrome, Firefox, Edge",
            "url": "https://protonvpn.com/browser-extension",
            "free": True,
            "type": "VPN",
            "notes": "Legit ProtonVPN in browser form. Routes only browser traffic.",
            "rating": 4,
        },
        {
            "name": "Mullvad Browser",
            "browser": "Desktop app (Firefox-based)",
            "url": "https://mullvad.net/browser",
            "free": True,
            "type": "Browser + Privacy",
            "notes": "Better than extension — full browser hardened for privacy, works with Mullvad VPN.",
            "rating": 5,
        },
        {
            "name": "uBlock Origin",
            "browser": "Firefox, Chrome",
            "url": "https://ublockorigin.com",
            "free": True,
            "type": "Ad/Tracker Blocker",
            "notes": "Must-have. Blocks ads, trackers, malware domains. Not a VPN but essential.",
            "rating": 5,
        },
        {
            "name": "Privacy Badger",
            "browser": "Firefox, Chrome",
            "url": "https://privacybadger.org",
            "free": True,
            "type": "Tracker Blocker",
            "notes": "Learns to block trackers. Complements uBlock Origin.",
            "rating": 4,
        },
        {
            "name": "ClearURLs",
            "browser": "Firefox, Chrome",
            "url": "https://clearurls.xyz",
            "free": True,
            "type": "URL Cleaner",
            "notes": "Strips tracking parameters (utm_*, fbclid, etc.) from URLs automatically.",
            "rating": 5,
        },
        {
            "name": "Windscribe Extension",
            "browser": "Chrome, Firefox",
            "url": "https://windscribe.com/extension",
            "free": True,
            "type": "VPN",
            "notes": "10GB/month free. Blocks ads and trackers too.",
            "rating": 3,
        },
        {
            "name": "Hola Free VPN",
            "browser": "Chrome, Firefox",
            "url": "https://hola.org",
            "free": True,
            "type": "VPN (AVOID)",
            "notes": "AVOID: Sells your bandwidth as an exit node. Dangerous.",
            "rating": 0,
        },
    ]

    for ext in extensions:
        stars = "★" * ext["rating"] + "☆" * (5 - ext["rating"])
        color = Colors.GREEN if ext["rating"] >= 4 else Colors.YELLOW if ext["rating"] >= 2 else Colors.RED
        print(f"  {Colors.BOLD}{Colors.CYAN}{ext['name']}{Colors.RESET}  {color}{stars}{Colors.RESET}")
        print(f"  Type:    {ext['type']}")
        print(f"  Browser: {ext['browser']}")
        print(f"  URL:     {ext['url']}")
        print(f"  Free:    {'✓' if ext['free'] else '✗'}")
        print(f"  Note:    {Colors.YELLOW}{ext['notes']}{Colors.RESET}\n")

    print(f"{Colors.BOLD}{Colors.BLUE}[ Extension Limitations ]{Colors.RESET}")
    limitations = [
        "Browser VPNs only protect browser traffic — not apps, email clients, etc.",
        "Many 'free VPN' extensions are actually proxies with no real encryption",
        "Extension can see all your browser traffic — trust the developer",
        "Some inject ads or sell your data (Hola is the most notorious case)",
        "True VPN requires a system-level connection (WireGuard, OpenVPN)",
    ]
    for l in limitations:
        print(f"  {Colors.RED}→{Colors.RESET} {l}")

    log_info("Displayed VPN browser extensions")


def run() -> None:
    """Main entry point for the VPN extension module."""
    display_vpn_extensions()
