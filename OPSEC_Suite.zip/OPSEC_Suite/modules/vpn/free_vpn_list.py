"""
Free and trusted VPN information module.
Lists and compares free and paid VPN providers.
"""

from utils.colors import Colors
from utils.logger import log_info


FREE_VPNS = [
    {
        "name": "ProtonVPN Free",
        "url": "https://protonvpn.com",
        "limit": "Unlimited data",
        "servers": "3 countries",
        "logs": "No logs",
        "open_source": True,
        "trusted": True,
        "notes": "Best free VPN. Unlimited data. Slower speeds on free tier.",
    },
    {
        "name": "Windscribe Free",
        "url": "https://windscribe.com",
        "limit": "10 GB/month (15 with tweet)",
        "servers": "10 countries",
        "logs": "No logs",
        "open_source": False,
        "trusted": True,
        "notes": "Generous free tier. Good for general use.",
    },
    {
        "name": "Tunnelbear Free",
        "url": "https://www.tunnelbear.com",
        "limit": "500MB/month",
        "servers": "45+ countries",
        "logs": "No logs (audited)",
        "open_source": False,
        "trusted": True,
        "notes": "Very limited data. Audited by security firms.",
    },
    {
        "name": "Hide.me Free",
        "url": "https://hide.me",
        "limit": "10 GB/month",
        "servers": "5 servers",
        "logs": "No logs",
        "open_source": False,
        "trusted": True,
        "notes": "Good speeds. No ads. Straightforward.",
    },
    {
        "name": "Hotspot Shield Free",
        "url": "https://www.hotspotshield.com",
        "limit": "500MB/day",
        "servers": "US only",
        "logs": "Questionable",
        "open_source": False,
        "trusted": False,
        "notes": "AVOID: has had privacy policy issues. Listed for completeness.",
    },
]

PAID_VPNS = [
    {
        "name": "Mullvad",
        "url": "https://mullvad.net",
        "price": "€5/month flat",
        "accepts_crypto": True,
        "logs": "No logs (audited)",
        "jurisdiction": "Sweden",
        "protocols": "WireGuard, OpenVPN",
        "account": "Anonymous (no email required)",
        "notes": "Top pick for privacy. No account needed. Cash and crypto accepted.",
        "rating": 5,
    },
    {
        "name": "ProtonVPN Plus",
        "url": "https://protonvpn.com",
        "price": "$4-10/month",
        "accepts_crypto": True,
        "logs": "No logs (audited)",
        "jurisdiction": "Switzerland",
        "protocols": "WireGuard, OpenVPN, Stealth",
        "account": "Email required",
        "notes": "Swiss law, strong privacy protections, Stealth protocol for censorship bypass.",
        "rating": 5,
    },
    {
        "name": "IVPN",
        "url": "https://ivpn.net",
        "price": "$6/month",
        "accepts_crypto": True,
        "logs": "No logs (audited)",
        "jurisdiction": "Gibraltar",
        "protocols": "WireGuard, OpenVPN",
        "account": "Account ID only (no email)",
        "notes": "Very privacy-focused, no email required, fast WireGuard.",
        "rating": 5,
    },
    {
        "name": "NordVPN",
        "url": "https://nordvpn.com",
        "price": "$3-12/month",
        "accepts_crypto": True,
        "logs": "No logs (audited)",
        "jurisdiction": "Panama",
        "protocols": "NordLynx (WireGuard), OpenVPN",
        "account": "Email required",
        "notes": "Popular, large server network, good speeds. Had a server breach in 2018.",
        "rating": 4,
    },
    {
        "name": "ExpressVPN",
        "url": "https://expressvpn.com",
        "price": "$8-13/month",
        "accepts_crypto": True,
        "logs": "No logs",
        "jurisdiction": "BVI (now owned by Kape)",
        "protocols": "Lightway, OpenVPN",
        "account": "Email required",
        "notes": "Fast speeds. Acquired by Kape Technologies — some trust concerns.",
        "rating": 3,
    },
]


def display_free_vpns() -> None:
    """Display free VPN options with ratings."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Free VPN Options ==={Colors.RESET}\n")
    print(f"  {Colors.YELLOW}[!] Free VPNs are limited. ProtonVPN Free is the only one truly recommended.{Colors.RESET}\n")

    for vpn in FREE_VPNS:
        trusted_color = Colors.GREEN if vpn["trusted"] else Colors.RED
        print(f"  {Colors.BOLD}{Colors.CYAN}{vpn['name']}{Colors.RESET}  {trusted_color}{'✓ Trusted' if vpn['trusted'] else '✗ Avoid'}{Colors.RESET}")
        print(f"  URL:     {vpn['url']}")
        print(f"  Limit:   {vpn['limit']}")
        print(f"  Servers: {vpn['servers']}")
        print(f"  Logs:    {vpn['logs']}")
        print(f"  Note:    {Colors.YELLOW}{vpn['notes']}{Colors.RESET}\n")


def display_paid_vpns() -> None:
    """Display recommended paid VPN options."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Recommended Paid VPN Providers ==={Colors.RESET}\n")

    for vpn in PAID_VPNS:
        stars = "★" * vpn["rating"] + "☆" * (5 - vpn["rating"])
        color = Colors.GREEN if vpn["rating"] >= 5 else Colors.YELLOW if vpn["rating"] >= 4 else Colors.RED
        print(f"  {Colors.BOLD}{Colors.CYAN}{vpn['name']}{Colors.RESET}  {color}{stars}{Colors.RESET}")
        print(f"  URL:        {vpn['url']}")
        print(f"  Price:      {vpn['price']}")
        print(f"  Crypto:     {'✓' if vpn['accepts_crypto'] else '✗'}")
        print(f"  Logs:       {vpn['logs']}")
        print(f"  Protocols:  {vpn['protocols']}")
        print(f"  Account:    {vpn['account']}")
        print(f"  Note:       {Colors.YELLOW}{vpn['notes']}{Colors.RESET}\n")


def run() -> None:
    """Main entry point for the VPN list module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         VPN PROVIDER DIRECTORY{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Free VPN options")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Recommended paid VPNs")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        display_free_vpns()
    elif choice == "2":
        display_paid_vpns()
    log_info("Displayed VPN list")
