"""
Secure email providers and anonymity guide.
Compares privacy email providers and explains email aliasing.
"""

from utils.colors import Colors
from utils.logger import log_info


EMAIL_PROVIDERS = [
    {
        "name": "ProtonMail",
        "url": "https://proton.me",
        "jurisdiction": "Switzerland",
        "e2e": True,
        "free_tier": True,
        "signup_anon": True,
        "open_source": True,
        "notes": "Industry standard for secure email. No IP logs. Free tier available.",
        "rating": 5,
    },
    {
        "name": "Tutanota",
        "url": "https://tutanota.com",
        "jurisdiction": "Germany",
        "e2e": True,
        "free_tier": True,
        "signup_anon": True,
        "open_source": True,
        "notes": "Zero-knowledge E2E. Free tier. Encrypts subject lines too.",
        "rating": 5,
    },
    {
        "name": "Mailfence",
        "url": "https://mailfence.com",
        "jurisdiction": "Belgium",
        "e2e": True,
        "free_tier": True,
        "signup_anon": False,
        "open_source": False,
        "notes": "Supports PGP. Free tier. May require phone for signup.",
        "rating": 4,
    },
    {
        "name": "StartMail",
        "url": "https://startmail.com",
        "jurisdiction": "Netherlands",
        "e2e": True,
        "free_tier": False,
        "signup_anon": True,
        "open_source": False,
        "notes": "PGP-enabled, paid only, 7-day trial.",
        "rating": 4,
    },
    {
        "name": "SimpleLogin (Alias)",
        "url": "https://simplelogin.io",
        "jurisdiction": "France",
        "e2e": False,
        "free_tier": True,
        "signup_anon": True,
        "open_source": True,
        "notes": "Email aliasing — forward to your real email without exposing it.",
        "rating": 5,
    },
    {
        "name": "AnonAddy (Alias)",
        "url": "https://anonaddy.com",
        "jurisdiction": "UK",
        "e2e": False,
        "free_tier": True,
        "signup_anon": True,
        "open_source": True,
        "notes": "Open-source email aliasing, self-hostable.",
        "rating": 4,
    },
    {
        "name": "Gmail",
        "url": "https://gmail.com",
        "jurisdiction": "USA",
        "e2e": False,
        "free_tier": True,
        "signup_anon": False,
        "open_source": False,
        "notes": "AVOID for privacy — Google scans all content for ad targeting.",
        "rating": 1,
    },
]


def display_email_providers() -> None:
    """Display and compare privacy-focused email providers."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*62}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         SECURE EMAIL PROVIDER COMPARISON{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*62}{Colors.RESET}\n")

    for provider in EMAIL_PROVIDERS:
        stars = "★" * provider["rating"] + "☆" * (5 - provider["rating"])
        rating_color = Colors.GREEN if provider["rating"] >= 4 else Colors.YELLOW if provider["rating"] >= 3 else Colors.RED
        print(f"  {Colors.BOLD}{Colors.CYAN}{provider['name']}{Colors.RESET}  {rating_color}{stars}{Colors.RESET}")
        print(f"  URL:          {provider['url']}")
        print(f"  Jurisdiction: {provider['jurisdiction']}")
        print(f"  E2E:          {'✓' if provider['e2e'] else '✗'}")
        print(f"  Free Tier:    {'✓' if provider['free_tier'] else '✗ (paid)'}")
        print(f"  Anon Signup:  {'✓' if provider['signup_anon'] else '✗ (needs phone)'}")
        print(f"  Open Source:  {'✓' if provider['open_source'] else '✗'}")
        print(f"  {Colors.YELLOW}Note:{Colors.RESET} {provider['notes']}\n")

    log_info("Displayed secure email providers")


def display_pgp_guide() -> None:
    """Display a guide to PGP email encryption."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== PGP Email Encryption Guide ==={Colors.RESET}\n")

    steps = [
        ("Install GPG", "Linux: sudo apt install gnupg | Mac: brew install gpg | Windows: Gpg4win"),
        ("Generate key pair", "gpg --full-generate-key  (choose RSA 4096 or Ed25519)"),
        ("List your keys", "gpg --list-secret-keys --keyid-format=long"),
        ("Export public key", "gpg --armor --export your@email.com > publickey.asc"),
        ("Import recipient's key", "gpg --import their_publickey.asc"),
        ("Encrypt a message", "gpg --encrypt --armor --recipient their@email.com message.txt"),
        ("Sign a message", "gpg --sign --armor message.txt"),
        ("Decrypt a message", "gpg --decrypt message.asc"),
        ("Publish to keyserver", "gpg --keyserver keys.openpgp.org --send-keys YOUR_KEY_ID"),
    ]

    for step, cmd in steps:
        print(f"  {Colors.CYAN}→{Colors.RESET} {Colors.BOLD}{step}{Colors.RESET}")
        print(f"    {Colors.DIM}{cmd}{Colors.RESET}\n")

    print(f"  {Colors.YELLOW}Email clients with PGP support:{Colors.RESET}")
    clients = [
        ("Thunderbird", "Built-in OpenPGP (v78+)"),
        ("K-9 Mail (Android)", "PGP via OpenKeychain"),
        ("Mutt (CLI)", "Native GPG integration"),
        ("ProtonMail", "PGP built into webmail"),
    ]
    for name, note in clients:
        print(f"    {Colors.CYAN}•{Colors.RESET} {Colors.BOLD}{name}{Colors.RESET}: {note}")


def run() -> None:
    """Main entry point for the secure email module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}      SECURE EMAIL GUIDE{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Compare secure email providers")
    print(f"  {Colors.CYAN}2.{Colors.RESET} PGP encryption guide")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        display_email_providers()
    elif choice == "2":
        display_pgp_guide()
