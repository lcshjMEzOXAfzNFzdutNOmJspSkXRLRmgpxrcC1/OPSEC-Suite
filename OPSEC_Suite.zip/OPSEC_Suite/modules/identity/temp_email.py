"""
Temporary/disposable email module.
Uses Guerrilla Mail API to generate a temp inbox and read messages.
"""

import time
from typing import Dict, Any, List

import requests

from utils.colors import Colors
from utils.logger import log_info, log_error


GUERRILLA_BASE = "https://api.guerrillamail.com/ajax.php"


def get_temp_email() -> Dict[str, Any]:
    """
    Create a new temporary email address using Guerrilla Mail.

    Returns:
        Dictionary with email_addr, sid_token, alias, and expiry info
    """
    try:
        resp = requests.get(
            GUERRILLA_BASE,
            params={"f": "get_email_address"},
            timeout=10,
        )
        data = resp.json()
        return {
            "email": data.get("email_addr", ""),
            "sid_token": data.get("sid_token", ""),
            "email_timestamp": data.get("email_timestamp", ""),
            "alias": data.get("alias", ""),
            "success": True,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_email_list(sid_token: str, seq: int = 0) -> List[Dict]:
    """
    Retrieve messages from a temporary inbox.

    Args:
        sid_token: Session token from get_temp_email()
        seq: Sequence number for pagination

    Returns:
        List of email summary dictionaries
    """
    try:
        resp = requests.get(
            GUERRILLA_BASE,
            params={"f": "get_email_list", "sid_token": sid_token, "seq": seq},
            timeout=10,
        )
        data = resp.json()
        return data.get("list", [])
    except Exception as e:
        log_error(f"Error fetching email list: {e}")
        return []


def get_email_content(mail_id: str, sid_token: str) -> Dict[str, Any]:
    """
    Fetch the full content of a specific email.

    Args:
        mail_id: Email ID from the inbox list
        sid_token: Session token

    Returns:
        Email content dictionary
    """
    try:
        resp = requests.get(
            GUERRILLA_BASE,
            params={"f": "fetch_email", "email_id": mail_id, "sid_token": sid_token},
            timeout=10,
        )
        return resp.json()
    except Exception as e:
        return {"error": str(e)}


def wait_for_email(sid_token: str, max_wait: int = 120) -> List[Dict]:
    """
    Poll the inbox until an email arrives or timeout is reached.

    Args:
        sid_token: Session token
        max_wait: Maximum seconds to wait

    Returns:
        List of emails received
    """
    print(f"  {Colors.YELLOW}Waiting for email (max {max_wait}s)...{Colors.RESET}")
    start = time.time()
    while time.time() - start < max_wait:
        messages = get_email_list(sid_token)
        if messages:
            return messages
        time.sleep(5)
        print(f"  {Colors.DIM}Still waiting... ({int(time.time()-start)}s){Colors.RESET}", end="\r")
    print()
    return []


def display_messages(messages: List[Dict]) -> None:
    """Display a list of inbox messages."""
    if not messages:
        print(f"\n  {Colors.YELLOW}No messages yet.{Colors.RESET}")
        return

    print(f"\n  {Colors.BOLD}Inbox ({len(messages)} message(s)):{Colors.RESET}\n")
    for msg in messages:
        print(f"  {Colors.CYAN}ID:{Colors.RESET}      {msg.get('mail_id')}")
        print(f"  {Colors.CYAN}From:{Colors.RESET}    {msg.get('mail_from', 'Unknown')}")
        print(f"  {Colors.CYAN}Subject:{Colors.RESET} {msg.get('mail_subject', '(no subject)')}")
        print(f"  {Colors.CYAN}Time:{Colors.RESET}    {msg.get('mail_date', 'Unknown')}")
        print(f"  {'-'*40}")


def run() -> None:
    """Main entry point for the temporary email module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}       TEMPORARY EMAIL (Guerrilla Mail){Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")
    print(f"\n  {Colors.YELLOW}[!] Temp email for throwaway signups only.{Colors.RESET}")
    print(f"  {Colors.YELLOW}[!] Do NOT use for sensitive communications.{Colors.RESET}\n")

    print(f"  {Colors.CYAN}1.{Colors.RESET} Get new temp email address")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice != "1":
        return

    print(f"\n  {Colors.YELLOW}Generating temp email...{Colors.RESET}")
    result = get_temp_email()

    if not result.get("success"):
        print(f"\n  {Colors.RED}Error: {result.get('error')}{Colors.RESET}")
        print(f"  {Colors.YELLOW}Try manually at: https://www.guerrillamail.com{Colors.RESET}")
        return

    email = result["email"]
    sid = result["sid_token"]

    print(f"\n  {Colors.GREEN}✓ Temp Email Created!{Colors.RESET}")
    print(f"  {Colors.BOLD}{Colors.CYAN}{email}{Colors.RESET}")
    print(f"  {Colors.DIM}Copy this and use it for signups.{Colors.RESET}\n")

    log_info(f"Generated temp email: {email[:10]}***")

    while True:
        print(f"\n  {Colors.CYAN}1.{Colors.RESET} Check inbox")
        print(f"  {Colors.CYAN}2.{Colors.RESET} Read message")
        print(f"  {Colors.CYAN}3.{Colors.RESET} Wait for new email (2 min)")
        print(f"  {Colors.CYAN}0.{Colors.RESET} Exit\n")

        cmd = input(f"  {Colors.BOLD}Command:{Colors.RESET} ").strip()

        if cmd == "0":
            break
        elif cmd == "1":
            messages = get_email_list(sid)
            display_messages(messages)
        elif cmd == "2":
            mail_id = input("  Email ID: ").strip()
            if mail_id:
                content = get_email_content(mail_id, sid)
                body = content.get("mail_body", content.get("mail_body_html", "No content"))
                import re
                clean_body = re.sub(r"<[^>]+>", "", str(body)).strip()
                print(f"\n  {Colors.BOLD}From:{Colors.RESET}    {content.get('mail_from', 'Unknown')}")
                print(f"  {Colors.BOLD}Subject:{Colors.RESET} {content.get('mail_subject', 'N/A')}")
                print(f"\n  {Colors.BOLD}Body:{Colors.RESET}")
                print(f"  {clean_body[:2000]}")
        elif cmd == "3":
            messages = wait_for_email(sid)
            display_messages(messages)
