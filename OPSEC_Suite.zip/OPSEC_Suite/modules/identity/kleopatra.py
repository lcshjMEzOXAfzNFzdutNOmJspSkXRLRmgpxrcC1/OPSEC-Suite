"""
Kleopatra / GPG key management guide.
Explains how to use GPG for email encryption and key signing.
"""

import subprocess
import platform
from typing import List, Dict

from utils.colors import Colors
from utils.logger import log_info


def list_gpg_keys() -> List[Dict[str, str]]:
    """
    List GPG keys available on the system.

    Returns:
        List of key info dictionaries
    """
    keys = []
    try:
        result = subprocess.run(
            ["gpg", "--list-keys", "--with-colons"],
            capture_output=True, text=True, timeout=10
        )
        current_key = {}
        for line in result.stdout.splitlines():
            parts = line.split(":")
            if parts[0] == "pub":
                if current_key:
                    keys.append(current_key)
                current_key = {
                    "type": "public",
                    "key_id": parts[4][-8:] if len(parts) > 4 else "Unknown",
                    "created": parts[5] if len(parts) > 5 else "Unknown",
                    "expires": parts[6] if len(parts) > 6 else "Never",
                }
            elif parts[0] == "uid" and current_key:
                if "uid" not in current_key:
                    current_key["uid"] = parts[9] if len(parts) > 9 else "Unknown"
        if current_key:
            keys.append(current_key)
    except FileNotFoundError:
        pass
    except Exception:
        pass
    return keys


def gpg_installed() -> bool:
    """Check if GPG is installed on the system."""
    try:
        result = subprocess.run(["gpg", "--version"], capture_output=True, timeout=5)
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def display_kleopatra_guide() -> None:
    """Display a guide to using Kleopatra and GPG."""
    system = platform.system()
    installed = gpg_installed()

    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*58}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}      KLEOPATRA / GPG KEY MANAGEMENT GUIDE{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*58}{Colors.RESET}\n")

    gpg_status = f"{Colors.GREEN}INSTALLED{Colors.RESET}" if installed else f"{Colors.RED}NOT FOUND{Colors.RESET}"
    print(f"  GPG: {gpg_status}")

    install_cmds = {
        "Windows": "Download Gpg4win from https://www.gpg4win.org/ (includes Kleopatra GUI)",
        "Darwin": "brew install gpg",
        "Linux": "sudo apt install gnupg kleopatra  (or your distro's equivalent)",
    }
    if not installed:
        print(f"  {Colors.YELLOW}Install: {install_cmds.get(system, 'gpg')}{Colors.RESET}")

    if installed:
        keys = list_gpg_keys()
        print(f"\n  {Colors.BOLD}Your GPG Keys ({len(keys)} found):{Colors.RESET}")
        for k in keys:
            print(f"    {Colors.CYAN}ID:{Colors.RESET} {k.get('key_id')}  UID: {k.get('uid', 'N/A')}")
        if not keys:
            print(f"    {Colors.YELLOW}No keys found. Generate one below.{Colors.RESET}")

    commands = [
        ("Generate new key pair", "gpg --full-generate-key"),
        ("List public keys", "gpg --list-keys"),
        ("List secret keys", "gpg --list-secret-keys"),
        ("Export public key", "gpg --armor --export EMAIL > public.asc"),
        ("Import a key", "gpg --import public.asc"),
        ("Sign a file", "gpg --sign --armor file.txt"),
        ("Verify a signature", "gpg --verify file.txt.asc"),
        ("Encrypt for recipient", "gpg --encrypt --armor -r recipient@email.com file.txt"),
        ("Decrypt a file", "gpg --decrypt file.txt.asc > decrypted.txt"),
        ("Delete a key", "gpg --delete-key EMAIL"),
        ("Send to keyserver", "gpg --keyserver keys.openpgp.org --send-keys KEYID"),
        ("Search keyserver", "gpg --keyserver keys.openpgp.org --search-keys EMAIL"),
        ("Create revocation cert", "gpg --gen-revoke EMAIL > revoke.asc"),
    ]

    print(f"\n  {Colors.BOLD}{Colors.BLUE}[ GPG Command Reference ]{Colors.RESET}")
    for action, cmd in commands:
        print(f"  {Colors.CYAN}→{Colors.RESET} {Colors.BOLD}{action}{Colors.RESET}")
        print(f"    {Colors.DIM}{cmd}{Colors.RESET}")

    print(f"\n  {Colors.BOLD}{Colors.YELLOW}[ Kleopatra GUI (Windows) ]{Colors.RESET}")
    print(f"  Part of Gpg4win — provides a GUI for GPG key management.")
    print(f"  File → New OpenPGP Key Pair to generate.")
    print(f"  Tools → Manage Smartcards for hardware key support.")

    log_info("Displayed Kleopatra/GPG guide")


def run() -> None:
    """Main entry point for the Kleopatra module."""
    display_kleopatra_guide()
