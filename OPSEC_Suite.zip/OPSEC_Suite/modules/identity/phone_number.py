"""
Phone number validation and information module.
Uses the phonenumbers library to identify carriers, countries, and formats.
"""

from typing import Dict, Any

from utils.colors import Colors
from utils.logger import log_info, log_error


def analyze_phone_number(number: str) -> Dict[str, Any]:
    """
    Analyze a phone number to extract country, carrier, line type, and format info.

    Args:
        number: Phone number string (include country code, e.g. '+15552001234')

    Returns:
        Dictionary with phone number analysis results
    """
    try:
        import phonenumbers
        from phonenumbers import geocoder, carrier, timezone, number_type, PhoneNumberType

        parsed = phonenumbers.parse(number, None)
        is_valid = phonenumbers.is_valid_number(parsed)
        is_possible = phonenumbers.is_possible_number(parsed)

        type_map = {
            PhoneNumberType.MOBILE: "Mobile",
            PhoneNumberType.FIXED_LINE: "Fixed Line",
            PhoneNumberType.FIXED_LINE_OR_MOBILE: "Fixed or Mobile",
            PhoneNumberType.TOLL_FREE: "Toll-Free",
            PhoneNumberType.PREMIUM_RATE: "Premium Rate",
            PhoneNumberType.VOIP: "VoIP",
            PhoneNumberType.UNKNOWN: "Unknown",
        }

        num_type = number_type(parsed)
        type_str = type_map.get(num_type, "Unknown")

        return {
            "number": number,
            "valid": is_valid,
            "possible": is_possible,
            "country": geocoder.description_for_number(parsed, "en") or "Unknown",
            "carrier": carrier.name_for_number(parsed, "en") or "Unknown",
            "line_type": type_str,
            "timezones": list(timezone.time_zones_for_number(parsed)),
            "e164_format": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164),
            "international_format": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
            "national_format": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL),
            "country_code": parsed.country_code,
            "national_number": parsed.national_number,
        }

    except ImportError:
        return {"error": "phonenumbers not installed. Run: pip install phonenumbers"}
    except Exception as e:
        return {"error": str(e), "number": number}


def display_phone_info(data: Dict[str, Any]) -> None:
    """
    Display phone number analysis results.

    Args:
        data: Result dictionary from analyze_phone_number()
    """
    if "error" in data:
        print(f"\n  {Colors.RED}Error: {data['error']}{Colors.RESET}")
        return

    valid_color = Colors.GREEN if data.get("valid") else Colors.RED
    print(f"\n  {Colors.BOLD}Phone Number Analysis{Colors.RESET}")
    print(f"  {'─'*40}")
    print(f"  {Colors.CYAN}Number:{Colors.RESET}         {data.get('number')}")
    print(f"  {Colors.CYAN}Valid:{Colors.RESET}          {valid_color}{data.get('valid')}{Colors.RESET}")
    print(f"  {Colors.CYAN}Country:{Colors.RESET}        {data.get('country')}")
    print(f"  {Colors.CYAN}Carrier:{Colors.RESET}        {data.get('carrier')}")
    print(f"  {Colors.CYAN}Line Type:{Colors.RESET}      {data.get('line_type')}")
    print(f"  {Colors.CYAN}Timezones:{Colors.RESET}      {', '.join(data.get('timezones', []))}")
    print(f"  {Colors.CYAN}E.164:{Colors.RESET}          {data.get('e164_format')}")
    print(f"  {Colors.CYAN}International:{Colors.RESET}  {data.get('international_format')}")
    print(f"  {Colors.CYAN}National:{Colors.RESET}       {data.get('national_format')}")
    print(f"  {Colors.CYAN}Country Code:{Colors.RESET}   +{data.get('country_code')}")


def get_temp_number_providers() -> None:
    """Display providers for temporary/burner phone numbers."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Temporary Phone Number Providers ==={Colors.RESET}\n")

    providers = [
        ("Google Voice", "https://voice.google.com", "Free, US numbers, requires Google account", "Low"),
        ("MySudo", "https://anonyome.com/individuals/mysudo/", "Compartmentalized identities, paid", "High"),
        ("Hushed", "https://hushed.com", "Temp numbers, paid", "Medium"),
        ("TextNow", "https://www.textnow.com", "Free US/Canada numbers with ads", "Low"),
        ("JMP.chat", "https://jmp.chat", "XMPP, accepts crypto, privacy-focused", "High"),
        ("SMSPVA", "https://smspva.com", "Receive SMS for verification, cheap", "Medium"),
        ("Receive-smss", "https://receive-smss.com", "Free shared numbers (not private)", "Very Low"),
    ]

    for name, url, desc, privacy in providers:
        p_color = Colors.GREEN if privacy in ("High",) else Colors.YELLOW if privacy == "Medium" else Colors.RED
        print(f"  {Colors.BOLD}{name}{Colors.RESET}")
        print(f"    URL:     {Colors.CYAN}{url}{Colors.RESET}")
        print(f"    Info:    {desc}")
        print(f"    Privacy: {p_color}{privacy}{Colors.RESET}\n")


def run() -> None:
    """Main entry point for the phone number module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         PHONE NUMBER ANALYZER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Analyze phone number")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Temp/burner number providers")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    elif choice == "1":
        number = input(f"\n  Phone number (with +country code, e.g. +15552001234): ").strip()
        if not number:
            print(f"  {Colors.RED}No number provided.{Colors.RESET}")
            return
        print(f"\n  {Colors.YELLOW}Analyzing...{Colors.RESET}")
        data = analyze_phone_number(number)
        display_phone_info(data)
        log_info(f"Analyzed phone number: {number[:6]}***")

    elif choice == "2":
        get_temp_number_providers()
