"""
Reverse security / threat intelligence module.
Look up IP reputation, domains, and malware hashes.
"""

import requests
from typing import Dict, Any

from utils.colors import Colors
from utils.logger import log_info, log_error


def check_ip_reputation(ip: str) -> Dict[str, Any]:
    """
    Check IP address reputation using AbuseIPDB's public API.

    Note: Full results require an AbuseIPDB API key.
    Falls back to ip-api.com for basic info.

    Args:
        ip: IP address to check

    Returns:
        Dictionary with reputation data
    """
    result = {"ip": ip}

    try:
        resp = requests.get(
            f"http://ip-api.com/json/{ip}?fields=status,message,country,regionName,city,isp,org,as,proxy,hosting,mobile,query",
            timeout=8,
        )
        data = resp.json()
        if data.get("status") == "success":
            result["country"] = data.get("country", "Unknown")
            result["isp"] = data.get("isp", "Unknown")
            result["org"] = data.get("org", "Unknown")
            result["asn"] = data.get("as", "Unknown")
            result["is_proxy"] = data.get("proxy", False)
            result["is_hosting"] = data.get("hosting", False)
            result["is_mobile"] = data.get("mobile", False)
    except Exception as e:
        result["error"] = str(e)

    return result


def check_hash_virustotal(file_hash: str, api_key: str = "") -> Dict[str, Any]:
    """
    Check a file hash (MD5/SHA1/SHA256) against VirusTotal.

    Args:
        file_hash: Hash string to look up
        api_key: VirusTotal API key (free tier: 4 lookups/min)

    Returns:
        Dictionary with VirusTotal results
    """
    if not api_key:
        return {
            "error": "VirusTotal API key required",
            "manual_url": f"https://www.virustotal.com/gui/search/{file_hash}",
            "tip": "Set your API key in config.json → api_keys.virustotal",
        }

    try:
        headers = {"x-apikey": api_key}
        resp = requests.get(
            f"https://www.virustotal.com/api/v3/files/{file_hash}",
            headers=headers,
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
            return {
                "hash": file_hash,
                "malicious": stats.get("malicious", 0),
                "suspicious": stats.get("suspicious", 0),
                "undetected": stats.get("undetected", 0),
                "total": sum(stats.values()),
            }
        elif resp.status_code == 404:
            return {"hash": file_hash, "status": "Not found in VirusTotal database"}
        else:
            return {"error": f"API error: {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}


def shodan_host_lookup(ip: str, api_key: str = "") -> Dict[str, Any]:
    """
    Look up a host on Shodan internet scanning data.

    Args:
        ip: IP address to query
        api_key: Shodan API key

    Returns:
        Shodan host data or error
    """
    if not api_key:
        return {
            "error": "Shodan API key required",
            "manual_url": f"https://www.shodan.io/host/{ip}",
            "tip": "Get a free key at https://account.shodan.io/register",
        }

    try:
        resp = requests.get(
            f"https://api.shodan.io/shodan/host/{ip}?key={api_key}",
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            return {
                "ip": ip,
                "org": data.get("org", "Unknown"),
                "country": data.get("country_name", "Unknown"),
                "open_ports": data.get("ports", []),
                "hostnames": data.get("hostnames", []),
                "os": data.get("os"),
                "tags": data.get("tags", []),
            }
        else:
            return {"error": f"Shodan API error: {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}


def run() -> None:
    """Main entry point for the reverse security module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}    THREAT INTELLIGENCE / REVERSE LOOKUP{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} IP reputation check")
    print(f"  {Colors.CYAN}2.{Colors.RESET} File hash lookup (VirusTotal)")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Shodan host lookup")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    elif choice == "1":
        ip = input("  IP address: ").strip()
        if not ip:
            return
        print(f"\n  {Colors.YELLOW}Checking {ip}...{Colors.RESET}")
        data = check_ip_reputation(ip)
        print(f"\n  {Colors.BOLD}IP Reputation Report:{Colors.RESET}")
        for k, v in data.items():
            color = Colors.RED if ("proxy" in k or "hosting" in k) and v else Colors.WHITE
            print(f"  {Colors.CYAN}{k:<20}{Colors.RESET}: {color}{v}{Colors.RESET}")
        log_info(f"Checked IP reputation: {ip}")

    elif choice == "2":
        hash_val = input("  File hash (MD5/SHA1/SHA256): ").strip()
        if not hash_val:
            return
        api_key = input("  VirusTotal API key (leave blank to skip): ").strip()
        print(f"\n  {Colors.YELLOW}Checking hash...{Colors.RESET}")
        data = check_hash_virustotal(hash_val, api_key)
        for k, v in data.items():
            color = Colors.RED if k == "malicious" and isinstance(v, int) and v > 0 else Colors.WHITE
            print(f"  {Colors.CYAN}{k:<20}{Colors.RESET}: {color}{v}{Colors.RESET}")

    elif choice == "3":
        ip = input("  IP address: ").strip()
        api_key = input("  Shodan API key (leave blank for manual link): ").strip()
        if not ip:
            return
        print(f"\n  {Colors.YELLOW}Querying Shodan...{Colors.RESET}")
        data = shodan_host_lookup(ip, api_key)
        for k, v in data.items():
            print(f"  {Colors.CYAN}{k:<20}{Colors.RESET}: {v}")
