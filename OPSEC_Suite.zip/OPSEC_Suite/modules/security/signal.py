"""
Signal messenger information and setup guide.
Explains how to use Signal for secure communications.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_signal_guide() -> None:
    """Display a comprehensive Signal messenger setup and usage guide."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*58}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}         SIGNAL MESSENGER — SECURE COMMS GUIDE{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*58}{Colors.RESET}\n")

    sections = [
        (
            "What is Signal?",
            Colors.CYAN,
            [
                "Signal is a free, open-source encrypted messaging app.",
                "It uses the Signal Protocol — the gold standard in E2E encryption.",
                "Recommended by Edward Snowden, EFF, and security researchers worldwide.",
                "Available for iOS, Android, Windows, Mac, and Linux.",
                "Download: https://signal.org/download/",
            ],
        ),
        (
            "Key Security Features",
            Colors.GREEN,
            [
                "End-to-end encryption for all messages, calls, and video",
                "Zero knowledge — Signal cannot read your messages",
                "Open source — code is publicly auditable",
                "Minimal metadata collected (only last connection date)",
                "Sealed sender — hides who is messaging whom",
                "Safety numbers — verify you're talking to the right person",
                "Disappearing messages — auto-delete after set interval",
                "Note to Self — encrypted private notepad",
                "Screen security — prevent app from appearing in recents",
            ],
        ),
        (
            "Setup for Maximum Privacy",
            Colors.YELLOW,
            [
                "1. Download Signal from official site (signal.org)",
                "2. Settings → Privacy → Enable Screen Security",
                "3. Settings → Privacy → Set Note-to-Self to Disappear: 1 week",
                "4. Enable Registration Lock (Settings → Account → Registration Lock)",
                "5. Verify Safety Numbers with contacts in person or via separate channel",
                "6. Enable Disappearing Messages by default (Settings → Chats → Default Timer)",
                "7. Block Signal from appearing in your OS notifications content",
                "8. Use a dedicated SIM or VoIP number for registration if possible",
                "9. Link number to a Google Voice or JMP.chat number for separation",
            ],
        ),
        (
            "Phone Number Privacy",
            Colors.RED,
            [
                "Signal requires a phone number for registration.",
                "Options to avoid using your real number:",
                "  • Google Voice (US): voice.google.com — free",
                "  • JMP.chat — XMPP-based, accepts crypto",
                "  • Twilio (dev-friendly, small cost)",
                "  • MySudo — compartmentalized identities",
                "  • Burner SIM from a carrier with cash payment",
                "Once registered, you can hide your number from contacts in Signal settings.",
            ],
        ),
        (
            "What Signal Does NOT Protect Against",
            Colors.RED,
            [
                "Screen captures by the person you're talking to",
                "Malware on your or recipient's device",
                "Physical access to an unlocked phone",
                "Who you communicate with (metadata) if your phone is seized",
                "Your phone number is still required (unless you use a disposable)",
                "Backup leaks — disable cloud backups or use encrypted backups",
            ],
        ),
        (
            "Alternatives for High-Security Use",
            Colors.PURPLE,
            [
                "Briar — P2P, works over Tor, no central server, no phone number",
                "Session — no phone number required, decentralized",
                "Wire — can register with email only",
                "Matrix/Element — decentralized, self-hostable",
                "Cwtch — metadata-resistant group chat over Tor",
            ],
        ),
    ]

    for title, color, items in sections:
        print(f"{color}{Colors.BOLD}[ {title} ]{Colors.RESET}")
        for item in items:
            print(f"  {item}")
        print()

    log_info("Displayed Signal guide")


def run() -> None:
    """Main entry point for the Signal information module."""
    display_signal_guide()
