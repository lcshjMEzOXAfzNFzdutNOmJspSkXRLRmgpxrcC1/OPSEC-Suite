"""
Encryption and decryption module.
Provides file and text encryption using AES (Fernet) and RSA.
"""

import base64
import os
from pathlib import Path
from typing import Optional, Tuple

from utils.colors import Colors
from utils.logger import log_info, log_error


def encrypt_text(plaintext: str, password: str) -> str:
    """
    Encrypt a text string using a password-derived Fernet key.

    Args:
        plaintext: Text to encrypt
        password: Encryption password

    Returns:
        Base64-encoded salt+ciphertext string
    """
    try:
        from cryptography.fernet import Fernet
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes

        salt = os.urandom(16)
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=480000)
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        f = Fernet(key)
        ciphertext = f.encrypt(plaintext.encode())
        combined = salt + ciphertext
        return base64.b64encode(combined).decode()
    except ImportError:
        return "Error: cryptography package not installed"
    except Exception as e:
        log_error(f"Encryption error: {e}")
        return f"Error: {e}"


def decrypt_text(ciphertext_b64: str, password: str) -> str:
    """
    Decrypt a text string encrypted with encrypt_text().

    Args:
        ciphertext_b64: Base64-encoded salt+ciphertext from encrypt_text()
        password: Decryption password

    Returns:
        Decrypted plaintext string or error message
    """
    try:
        from cryptography.fernet import Fernet, InvalidToken
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes

        combined = base64.b64decode(ciphertext_b64)
        salt = combined[:16]
        ciphertext = combined[16:]
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=480000)
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        f = Fernet(key)
        return f.decrypt(ciphertext).decode()
    except ImportError:
        return "Error: cryptography package not installed"
    except InvalidToken:
        return "Error: Incorrect password or corrupted data"
    except Exception as e:
        log_error(f"Decryption error: {e}")
        return f"Error: {e}"


def encrypt_file(input_path: str, password: str, output_path: Optional[str] = None) -> str:
    """
    Encrypt a file using a password-derived Fernet key.

    Args:
        input_path: Path to the file to encrypt
        password: Encryption password
        output_path: Output path. Defaults to input_path + '.enc'

    Returns:
        Path to the encrypted file
    """
    try:
        from cryptography.fernet import Fernet
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes

        if output_path is None:
            output_path = input_path + ".enc"

        with open(input_path, "rb") as f:
            data = f.read()

        salt = os.urandom(16)
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=480000)
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        fernet = Fernet(key)
        encrypted = fernet.encrypt(data)

        with open(output_path, "wb") as f:
            f.write(salt + encrypted)

        log_info(f"Encrypted {input_path} -> {output_path}")
        return output_path
    except Exception as e:
        log_error(f"File encryption error: {e}")
        return ""


def decrypt_file(input_path: str, password: str, output_path: Optional[str] = None) -> str:
    """
    Decrypt a file encrypted with encrypt_file().

    Args:
        input_path: Path to the .enc file
        password: Decryption password
        output_path: Where to save the decrypted file

    Returns:
        Path to the decrypted file, or empty string on failure
    """
    try:
        from cryptography.fernet import Fernet, InvalidToken
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
        from cryptography.hazmat.primitives import hashes

        if output_path is None:
            output_path = input_path.replace(".enc", ".dec")

        with open(input_path, "rb") as f:
            raw = f.read()

        salt = raw[:16]
        ciphertext = raw[16:]
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=480000)
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        fernet = Fernet(key)
        decrypted = fernet.decrypt(ciphertext)

        with open(output_path, "wb") as f:
            f.write(decrypted)

        log_info(f"Decrypted {input_path} -> {output_path}")
        return output_path
    except InvalidToken:
        log_error("Incorrect password or corrupted file")
        return ""
    except Exception as e:
        log_error(f"File decryption error: {e}")
        return ""


def generate_rsa_keypair(key_size: int = 2048) -> Tuple[str, str]:
    """
    Generate an RSA key pair.

    Args:
        key_size: Key size in bits (2048 or 4096 recommended)

    Returns:
        Tuple of (private_key_pem, public_key_pem) as strings
    """
    try:
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization

        private_key = rsa.generate_private_key(public_exponent=65537, key_size=key_size)
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode()
        public_pem = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        ).decode()
        return private_pem, public_pem
    except ImportError:
        return "Error: cryptography not installed", ""
    except Exception as e:
        return f"Error: {e}", ""


def run() -> None:
    """Main entry point for the encryption/decryption module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}      ENCRYPTION / DECRYPTION TOOL{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Encrypt text message")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Decrypt text message")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Encrypt file")
    print(f"  {Colors.CYAN}4.{Colors.RESET} Decrypt file")
    print(f"  {Colors.CYAN}5.{Colors.RESET} Generate RSA key pair")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    elif choice == "1":
        import getpass
        text = input("  Text to encrypt: ")
        password = getpass.getpass("  Password: ")
        encrypted = encrypt_text(text, password)
        print(f"\n  {Colors.GREEN}Encrypted:{Colors.RESET}")
        print(f"  {Colors.CYAN}{encrypted}{Colors.RESET}")

    elif choice == "2":
        import getpass
        ciphertext = input("  Encrypted text: ").strip()
        password = getpass.getpass("  Password: ")
        decrypted = decrypt_text(ciphertext, password)
        print(f"\n  {Colors.GREEN}Decrypted:{Colors.RESET}")
        print(f"  {Colors.WHITE}{decrypted}{Colors.RESET}")

    elif choice == "3":
        import getpass
        file_path = input("  File to encrypt: ").strip()
        password = getpass.getpass("  Password: ")
        result = encrypt_file(file_path, password)
        if result:
            print(f"\n  {Colors.GREEN}✓ Encrypted: {result}{Colors.RESET}")
        else:
            print(f"\n  {Colors.RED}Encryption failed.{Colors.RESET}")

    elif choice == "4":
        import getpass
        file_path = input("  File to decrypt (.enc): ").strip()
        password = getpass.getpass("  Password: ")
        result = decrypt_file(file_path, password)
        if result:
            print(f"\n  {Colors.GREEN}✓ Decrypted: {result}{Colors.RESET}")
        else:
            print(f"\n  {Colors.RED}Decryption failed. Wrong password?{Colors.RESET}")

    elif choice == "5":
        size_str = input("  Key size [2048/4096]: ").strip() or "2048"
        try:
            size = int(size_str)
        except ValueError:
            size = 2048
        print(f"\n  {Colors.YELLOW}Generating {size}-bit RSA key pair...{Colors.RESET}")
        private_pem, public_pem = generate_rsa_keypair(key_size=size)
        if "Error" not in private_pem:
            priv_file = "private_key.pem"
            pub_file = "public_key.pem"
            with open(priv_file, "w") as f:
                f.write(private_pem)
            with open(pub_file, "w") as f:
                f.write(public_pem)
            print(f"\n  {Colors.GREEN}✓ Private key: {priv_file}{Colors.RESET}")
            print(f"  {Colors.GREEN}✓ Public key:  {pub_file}{Colors.RESET}")
            print(f"  {Colors.RED}[!] Keep your private key secure and never share it!{Colors.RESET}")
        else:
            print(f"\n  {Colors.RED}{private_pem}{Colors.RESET}")
