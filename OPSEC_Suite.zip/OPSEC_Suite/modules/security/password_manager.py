"""
Local encrypted password manager.
Stores passwords encrypted with Fernet (AES-128-CBC) derived from a master password.
"""

import base64
import json
import os
import secrets
import string
from pathlib import Path
from typing import Dict, List, Optional

from utils.colors import Colors
from utils.logger import log_info, log_error


def derive_key(master_password: str, salt: bytes) -> bytes:
    """
    Derive a Fernet-compatible encryption key from a master password.

    Args:
        master_password: User-provided master password
        salt: Random 16-byte salt

    Returns:
        32-byte base64url-encoded key for Fernet
    """
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=480000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(master_password.encode()))
    return key


class PasswordManager:
    """
    Local encrypted password vault using Fernet symmetric encryption.

    The vault file stores: {salt_hex, passwords: {service: {username, password, notes}}}
    """

    def __init__(self, vault_path: str = "vault.enc") -> None:
        """
        Initialize the password manager.

        Args:
            vault_path: Path to the encrypted vault file
        """
        self.vault_path = Path(vault_path)
        self._fernet = None
        self._data: Dict = {}

    def _get_fernet(self, master_password: str, salt: bytes):
        """Return a Fernet instance derived from the master password and salt."""
        from cryptography.fernet import Fernet
        key = derive_key(master_password, salt)
        return Fernet(key)

    def create_vault(self, master_password: str) -> bool:
        """
        Create a new encrypted vault.

        Args:
            master_password: Master password to encrypt the vault

        Returns:
            True if vault was created successfully
        """
        try:
            salt = os.urandom(16)
            fernet = self._get_fernet(master_password, salt)
            data = {"passwords": {}}
            encrypted = fernet.encrypt(json.dumps(data).encode())

            vault_content = {
                "salt": salt.hex(),
                "data": base64.b64encode(encrypted).decode(),
            }
            with open(self.vault_path, "w") as f:
                json.dump(vault_content, f)

            log_info(f"Created new vault at {self.vault_path}")
            return True
        except Exception as e:
            log_error(f"Failed to create vault: {e}")
            return False

    def unlock(self, master_password: str) -> bool:
        """
        Unlock the vault with the master password.

        Args:
            master_password: Master password to decrypt the vault

        Returns:
            True if vault unlocked successfully
        """
        try:
            from cryptography.fernet import InvalidToken

            with open(self.vault_path, "r") as f:
                vault_content = json.load(f)

            salt = bytes.fromhex(vault_content["salt"])
            fernet = self._get_fernet(master_password, salt)
            encrypted = base64.b64decode(vault_content["data"])
            decrypted = fernet.decrypt(encrypted)
            self._data = json.loads(decrypted)
            self._fernet = fernet
            self._salt = salt
            log_info("Vault unlocked")
            return True
        except (InvalidToken, Exception):
            return False

    def _save(self) -> None:
        """Save the current vault state."""
        if self._fernet is None:
            return
        encrypted = self._fernet.encrypt(json.dumps(self._data).encode())
        vault_content = {
            "salt": self._salt.hex(),
            "data": base64.b64encode(encrypted).decode(),
        }
        with open(self.vault_path, "w") as f:
            json.dump(vault_content, f)

    def add_entry(self, service: str, username: str, password: str, notes: str = "") -> None:
        """
        Add or update a password entry.

        Args:
            service: Service or website name
            username: Account username or email
            password: Password for the account
            notes: Optional notes
        """
        self._data.setdefault("passwords", {})[service] = {
            "username": username,
            "password": password,
            "notes": notes,
        }
        self._save()
        log_info(f"Saved entry for {service}")

    def get_entry(self, service: str) -> Optional[Dict]:
        """
        Retrieve a password entry.

        Args:
            service: Service name to look up

        Returns:
            Entry dict or None if not found
        """
        return self._data.get("passwords", {}).get(service)

    def delete_entry(self, service: str) -> bool:
        """
        Delete a password entry.

        Args:
            service: Service name to delete

        Returns:
            True if deleted, False if not found
        """
        if service in self._data.get("passwords", {}):
            del self._data["passwords"][service]
            self._save()
            log_info(f"Deleted entry for {service}")
            return True
        return False

    def list_services(self) -> List[str]:
        """Return a sorted list of all stored service names."""
        return sorted(self._data.get("passwords", {}).keys())

    def is_locked(self) -> bool:
        """Return True if vault is not yet unlocked."""
        return self._fernet is None


def generate_password(
    length: int = 20,
    use_upper: bool = True,
    use_digits: bool = True,
    use_special: bool = True,
) -> str:
    """
    Generate a cryptographically random password.

    Args:
        length: Password length
        use_upper: Include uppercase letters
        use_digits: Include digits
        use_special: Include special characters

    Returns:
        Generated password string
    """
    chars = string.ascii_lowercase
    required = []

    if use_upper:
        chars += string.ascii_uppercase
        required.append(secrets.choice(string.ascii_uppercase))
    if use_digits:
        chars += string.digits
        required.append(secrets.choice(string.digits))
    if use_special:
        special = "!@#$%^&*()-_=+[]{}|;:,.<>?"
        chars += special
        required.append(secrets.choice(special))

    remaining = [secrets.choice(chars) for _ in range(length - len(required))]
    password_chars = required + remaining
    secrets.SystemRandom().shuffle(password_chars)
    return "".join(password_chars)


def check_password_strength(password: str) -> Dict:
    """
    Evaluate the strength of a password.

    Args:
        password: Password string to evaluate

    Returns:
        Dictionary with score, rating, and recommendations
    """
    score = 0
    recommendations = []

    if len(password) >= 12:
        score += 1
    else:
        recommendations.append("Use at least 12 characters")

    if len(password) >= 16:
        score += 1

    if any(c.isupper() for c in password):
        score += 1
    else:
        recommendations.append("Add uppercase letters")

    if any(c.islower() for c in password):
        score += 1
    else:
        recommendations.append("Add lowercase letters")

    if any(c.isdigit() for c in password):
        score += 1
    else:
        recommendations.append("Add numbers")

    if any(c in "!@#$%^&*()-_=+[]{}|;:,.<>?" for c in password):
        score += 1
    else:
        recommendations.append("Add special characters")

    if len(set(password)) > len(password) * 0.7:
        score += 1
    else:
        recommendations.append("Use more varied characters")

    ratings = {7: "Excellent", 6: "Strong", 5: "Good", 4: "Fair", 3: "Weak", 2: "Very Weak", 1: "Terrible"}
    rating = ratings.get(score, "Terrible")

    return {"score": score, "max": 7, "rating": rating, "recommendations": recommendations}


def run() -> None:
    """Main entry point for the password manager module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}       LOCAL PASSWORD MANAGER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Create new vault")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Open existing vault")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Generate strong password")
    print(f"  {Colors.CYAN}4.{Colors.RESET} Check password strength")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    elif choice == "3":
        length_str = input(f"\n  Password length [20]: ").strip() or "20"
        try:
            length = int(length_str)
        except ValueError:
            length = 20
        pwd = generate_password(length=length)
        print(f"\n  {Colors.GREEN}Generated password:{Colors.RESET}")
        print(f"  {Colors.BOLD}{Colors.CYAN}{pwd}{Colors.RESET}")
        strength = check_password_strength(pwd)
        print(f"\n  Strength: {Colors.GREEN}{strength['rating']}{Colors.RESET} ({strength['score']}/{strength['max']})")
        return

    elif choice == "4":
        pwd = input(f"\n  Enter password to check: ").strip()
        if not pwd:
            return
        result = check_password_strength(pwd)
        color = Colors.GREEN if result["score"] >= 5 else Colors.YELLOW if result["score"] >= 3 else Colors.RED
        print(f"\n  Rating: {color}{result['rating']}{Colors.RESET} ({result['score']}/{result['max']})")
        if result["recommendations"]:
            print(f"\n  {Colors.YELLOW}Improve by:{Colors.RESET}")
            for rec in result["recommendations"]:
                print(f"    {Colors.CYAN}→{Colors.RESET} {rec}")
        return

    vault_path = input(f"\n  Vault file path [vault.enc]: ").strip() or "vault.enc"
    pm = PasswordManager(vault_path=vault_path)

    if choice == "1":
        if Path(vault_path).exists():
            confirm = input(f"  {Colors.YELLOW}Vault exists. Overwrite? [y/N]:{Colors.RESET} ").strip().lower()
            if confirm != "y":
                return
        import getpass
        master = getpass.getpass("  Set master password: ")
        confirm = getpass.getpass("  Confirm master password: ")
        if master != confirm:
            print(f"  {Colors.RED}Passwords do not match.{Colors.RESET}")
            return
        if pm.create_vault(master):
            print(f"  {Colors.GREEN}✓ Vault created at {vault_path}{Colors.RESET}")

    elif choice == "2":
        if not Path(vault_path).exists():
            print(f"  {Colors.RED}Vault file not found: {vault_path}{Colors.RESET}")
            return
        import getpass
        master = getpass.getpass("  Master password: ")
        if not pm.unlock(master):
            print(f"  {Colors.RED}Incorrect master password.{Colors.RESET}")
            return

        print(f"  {Colors.GREEN}✓ Vault unlocked!{Colors.RESET}")

        while True:
            print(f"\n  {Colors.CYAN}a.{Colors.RESET} Add/update entry")
            print(f"  {Colors.CYAN}g.{Colors.RESET} Get entry")
            print(f"  {Colors.CYAN}l.{Colors.RESET} List services")
            print(f"  {Colors.CYAN}d.{Colors.RESET} Delete entry")
            print(f"  {Colors.CYAN}q.{Colors.RESET} Lock & exit\n")
            cmd = input(f"  {Colors.BOLD}Command:{Colors.RESET} ").strip().lower()

            if cmd == "a":
                service = input("  Service name: ").strip()
                username = input("  Username/email: ").strip()
                gen = input("  Generate password? [Y/n]: ").strip().lower()
                if gen != "n":
                    password = generate_password()
                    print(f"  Generated: {Colors.CYAN}{password}{Colors.RESET}")
                else:
                    import getpass
                    password = getpass.getpass("  Password: ")
                notes = input("  Notes (optional): ").strip()
                pm.add_entry(service, username, password, notes)
                print(f"  {Colors.GREEN}✓ Saved{Colors.RESET}")

            elif cmd == "g":
                service = input("  Service name: ").strip()
                entry = pm.get_entry(service)
                if entry:
                    print(f"\n  {Colors.CYAN}Username:{Colors.RESET} {entry['username']}")
                    print(f"  {Colors.CYAN}Password:{Colors.RESET} {Colors.BOLD}{entry['password']}{Colors.RESET}")
                    if entry.get("notes"):
                        print(f"  {Colors.CYAN}Notes:{Colors.RESET} {entry['notes']}")
                else:
                    print(f"  {Colors.RED}Entry not found.{Colors.RESET}")

            elif cmd == "l":
                services = pm.list_services()
                if services:
                    print(f"\n  {Colors.BOLD}Stored services ({len(services)}):{Colors.RESET}")
                    for s in services:
                        print(f"    {Colors.CYAN}→{Colors.RESET} {s}")
                else:
                    print(f"  {Colors.YELLOW}No entries in vault.{Colors.RESET}")

            elif cmd == "d":
                service = input("  Service to delete: ").strip()
                if pm.delete_entry(service):
                    print(f"  {Colors.GREEN}✓ Deleted{Colors.RESET}")
                else:
                    print(f"  {Colors.RED}Entry not found.{Colors.RESET}")

            elif cmd == "q":
                break
