"""
General security information and tools module.
Covers security best practices and system hardening tips.
"""

import platform
import subprocess
import sys
from typing import Dict, List, Tuple

from utils.colors import Colors
from utils.logger import log_info, log_warning


def get_system_info() -> Dict[str, str]:
    """
    Collect basic system information.

    Returns:
        Dictionary of system attributes
    """
    return {
        "OS": platform.system(),
        "OS Version": platform.version()[:60],
        "Architecture": platform.machine(),
        "Processor": platform.processor()[:60] or "Unknown",
        "Python Version": sys.version.split()[0],
        "Hostname": platform.node(),
    }


def check_open_ports_local() -> List[int]:
    """
    Check for locally listening TCP ports using platform-specific commands.

    Returns:
        List of listening port numbers
    """
    import socket
    ports = []
    system = platform.system()
    try:
        if system == "Windows":
            result = subprocess.run(
                ["netstat", "-ano"], capture_output=True, text=True, timeout=10
            )
        else:
            result = subprocess.run(
                ["ss", "-tlnp"], capture_output=True, text=True, timeout=10
            )
            if result.returncode != 0:
                result = subprocess.run(
                    ["netstat", "-tlnp"], capture_output=True, text=True, timeout=10
                )

        for line in result.stdout.splitlines():
            parts = line.split()
            if not parts:
                continue
            for part in parts:
                if ":" in part:
                    port_str = part.split(":")[-1]
                    try:
                        port = int(port_str)
                        if 1 <= port <= 65535 and port not in ports:
                            ports.append(port)
                    except ValueError:
                        pass
    except Exception as e:
        log_warning(f"Could not check open ports: {e}")

    return sorted(ports[:30])


def display_security_hardening() -> None:
    """Display a security hardening guide for common platforms."""
    system = platform.system()
    print(f"\n{Colors.BOLD}{Colors.PURPLE}=== Security Hardening Guide ({system}) ==={Colors.RESET}\n")

    common_tips = [
        ("Keep software updated", "Enable automatic security updates"),
        ("Use a firewall", "Block inbound connections by default"),
        ("Encrypt your disk", "BitLocker (Windows) / FileVault (Mac) / LUKS (Linux)"),
        ("Use strong passwords", "12+ chars, no dictionary words, unique per service"),
        ("Enable 2FA everywhere", "Prefer TOTP apps over SMS"),
        ("Limit admin access", "Use standard user account for daily tasks"),
        ("Disable unnecessary services", "Reduce attack surface"),
        ("Enable screen lock", "Set to lock after 5 minutes"),
        ("Use a password manager", "Bitwarden, KeePass, 1Password"),
        ("Backup your data", "3-2-1 rule: 3 copies, 2 media types, 1 offsite"),
    ]

    linux_tips = [
        ("Enable UFW firewall", "sudo ufw enable && sudo ufw default deny incoming"),
        ("Disable root SSH login", "PermitRootLogin no in /etc/ssh/sshd_config"),
        ("Use SSH keys", "ssh-keygen -t ed25519 -C 'your@email.com'"),
        ("Enable automatic updates", "unattended-upgrades (Debian/Ubuntu)"),
        ("Check for rootkits", "sudo rkhunter --check"),
        ("ClamAV antivirus", "sudo apt install clamav && sudo clamscan -r /home"),
        ("AppArmor/SELinux", "Enable mandatory access control"),
        ("Audit with Lynis", "sudo lynis audit system"),
    ]

    windows_tips = [
        ("Enable Windows Defender", "Real-time protection must be ON"),
        ("Enable BitLocker", "Control Panel → BitLocker Drive Encryption"),
        ("Disable remote desktop", "Settings → Remote Desktop → Disable"),
        ("Enable SmartScreen", "Protects against malicious downloads"),
        ("Use Microsoft Account 2FA", "account.microsoft.com → Security"),
        ("Enable Secure Boot", "BIOS → Security → Secure Boot"),
        ("Disable UPnP on router", "Prevents port auto-opening exploits"),
    ]

    print(f"{Colors.BOLD}{Colors.BLUE}[ Universal Security ]{Colors.RESET}")
    for tip, detail in common_tips:
        print(f"  {Colors.GREEN}•{Colors.RESET} {Colors.BOLD}{tip}{Colors.RESET}: {detail}")

    if system == "Linux":
        print(f"\n{Colors.BOLD}{Colors.BLUE}[ Linux-Specific ]{Colors.RESET}")
        for tip, cmd in linux_tips:
            print(f"  {Colors.CYAN}•{Colors.RESET} {Colors.BOLD}{tip}{Colors.RESET}")
            print(f"    {Colors.DIM}{cmd}{Colors.RESET}")
    elif system == "Windows":
        print(f"\n{Colors.BOLD}{Colors.BLUE}[ Windows-Specific ]{Colors.RESET}")
        for tip, detail in windows_tips:
            print(f"  {Colors.CYAN}•{Colors.RESET} {Colors.BOLD}{tip}{Colors.RESET}: {detail}")
    elif system == "Darwin":
        print(f"\n{Colors.BOLD}{Colors.BLUE}[ macOS-Specific ]{Colors.RESET}")
        mac_tips = [
            ("Enable FileVault", "System Preferences → Security → FileVault"),
            ("Enable Firewall", "System Preferences → Security → Firewall"),
            ("Enable Gatekeeper", "Only allow apps from App Store/Identified Developers"),
            ("Use Activity Monitor", "Check for suspicious processes"),
            ("Lock screen hot corner", "Set a hot corner to trigger screen lock immediately"),
        ]
        for tip, detail in mac_tips:
            print(f"  {Colors.CYAN}•{Colors.RESET} {Colors.BOLD}{tip}{Colors.RESET}: {detail}")

    log_info("Displayed security hardening guide")


def run() -> None:
    """Main entry point for the security module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}        SECURITY INFORMATION CENTER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")

    info = get_system_info()
    print(f"\n  {Colors.BOLD}System:{Colors.RESET}")
    for k, v in info.items():
        print(f"    {Colors.CYAN}{k:<20}{Colors.RESET}: {v}")

    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Security hardening guide")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Show listening ports")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "1":
        display_security_hardening()
    elif choice == "2":
        ports = check_open_ports_local()
        print(f"\n  {Colors.BOLD}Detected listening ports:{Colors.RESET}")
        for p in ports:
            print(f"    {Colors.CYAN}{p}{Colors.RESET}")
        print(f"\n  {Colors.YELLOW}Use this tool's port scanner for remote scans.{Colors.RESET}")
