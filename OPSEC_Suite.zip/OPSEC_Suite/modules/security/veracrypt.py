"""
VeraCrypt information and usage guide.
Explains disk encryption with VeraCrypt for operational security.
"""

import subprocess
import platform
from typing import List

from utils.colors import Colors
from utils.logger import log_info


def check_veracrypt_installed() -> bool:
    """
    Check whether VeraCrypt CLI is available on the system.

    Returns:
        True if veracrypt command is available
    """
    try:
        result = subprocess.run(
            ["veracrypt", "--version"],
            capture_output=True, text=True, timeout=5
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def get_veracrypt_volumes() -> List[str]:
    """
    List currently mounted VeraCrypt volumes.

    Returns:
        List of mounted volume paths
    """
    try:
        result = subprocess.run(
            ["veracrypt", "--list"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().splitlines()
        return []
    except Exception:
        return []


def display_veracrypt_guide() -> None:
    """Display a comprehensive VeraCrypt setup and usage guide."""
    installed = check_veracrypt_installed()

    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}        VERACRYPT — DISK ENCRYPTION GUIDE{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}\n")

    if installed:
        print(f"  VeraCrypt: {Colors.GREEN}INSTALLED{Colors.RESET}")
        volumes = get_veracrypt_volumes()
        if volumes:
            print(f"  Mounted volumes:")
            for v in volumes:
                print(f"    {Colors.CYAN}{v}{Colors.RESET}")
        else:
            print(f"  Mounted volumes: {Colors.YELLOW}None{Colors.RESET}")
    else:
        print(f"  VeraCrypt: {Colors.RED}NOT INSTALLED{Colors.RESET}")
        print(f"  Download: {Colors.CYAN}https://www.veracrypt.fr/en/Downloads.html{Colors.RESET}")

    print()

    sections = [
        (
            "What is VeraCrypt?",
            Colors.BLUE,
            [
                "VeraCrypt is free, open-source disk encryption software.",
                "Successor to TrueCrypt (discontinued in 2014).",
                "Creates encrypted virtual disks or encrypts entire partitions/drives.",
                "Supports AES, Serpent, Twofish (and combinations).",
                "Supports hidden volumes for plausible deniability.",
                "Available for Windows, macOS, and Linux.",
            ],
        ),
        (
            "Creating an Encrypted Container",
            Colors.GREEN,
            [
                "1. Open VeraCrypt → Create Volume → Create encrypted file container",
                "2. Choose volume location and filename",
                "3. Select encryption: AES-256 + SHA-512 (recommended)",
                "4. Set container size",
                "5. Set a strong password (20+ characters)",
                "6. Move mouse randomly to increase entropy",
                "7. Format the container",
                "8. Mount the volume to use it as a regular drive",
            ],
        ),
        (
            "Full System Encryption (Windows)",
            Colors.CYAN,
            [
                "1. VeraCrypt → System → Encrypt System Partition",
                "2. Choose encryption algorithm",
                "3. Set pre-boot password",
                "4. Create a rescue disk (REQUIRED — saves you if bootloader corrupted)",
                "5. Wipe mode: 3-pass for sensitive data",
                "6. Pre-test: system reboots to verify everything works",
                "7. Encryption proceeds in background",
                "",
                "CLI equivalent (Linux LUKS):",
                "  cryptsetup luksFormat /dev/sdX",
                "  cryptsetup open /dev/sdX my_encrypted",
                "  mkfs.ext4 /dev/mapper/my_encrypted",
            ],
        ),
        (
            "Hidden Volumes (Plausible Deniability)",
            Colors.YELLOW,
            [
                "A hidden volume lives inside a regular VeraCrypt volume.",
                "There are TWO passwords:",
                "  Password A → unlocks outer (decoy) volume",
                "  Password B → unlocks inner (hidden, real) volume",
                "",
                "If coerced to reveal your password, give Password A.",
                "The decoy volume should contain believable files.",
                "The hidden volume stores your actual sensitive data.",
                "VeraCrypt cannot prove a hidden volume exists.",
            ],
        ),
        (
            "Best Practices",
            Colors.RED,
            [
                "Always use a strong, unique password for each volume",
                "Never store the recovery disk alongside the encrypted drive",
                "Make backups of your encrypted containers (regular backups)",
                "Enable PIM (Personal Iterations Multiplier) for extra security",
                "Dismount volumes when not in use",
                "Use keyfiles in addition to passwords for critical data",
                "Test recovery procedures before relying on them",
            ],
        ),
    ]

    for title, color, items in sections:
        print(f"{color}{Colors.BOLD}[ {title} ]{Colors.RESET}")
        for item in items:
            print(f"  {item}")
        print()

    log_info("Displayed VeraCrypt guide")


def run() -> None:
    """Main entry point for the VeraCrypt module."""
    display_veracrypt_guide()
