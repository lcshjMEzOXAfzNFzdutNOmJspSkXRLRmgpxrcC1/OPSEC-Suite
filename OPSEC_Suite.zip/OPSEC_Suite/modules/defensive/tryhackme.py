"""
TryHackMe learning resources module.
Provides links and information about security training platforms.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_learning_resources() -> None:
    """Display curated security learning resources and platforms."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}      CYBERSECURITY LEARNING RESOURCES{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*60}{Colors.RESET}\n")

    platforms = [
        {
            "name": "TryHackMe",
            "url": "https://tryhackme.com",
            "desc": "Beginner-friendly guided labs in a browser. Free tier available.",
            "focus": "Beginner to Intermediate CTF, pentesting, OSINT, security fundamentals",
            "cost": "Free / $10/mo premium",
        },
        {
            "name": "HackTheBox",
            "url": "https://hackthebox.com",
            "desc": "Realistic machines and labs for intermediate+ security practitioners.",
            "focus": "Advanced pentesting, CTF, Active Directory attacks",
            "cost": "Free / $14/mo VIP",
        },
        {
            "name": "PortSwigger Web Security Academy",
            "url": "https://portswigger.net/web-security",
            "desc": "Free, world-class web security training from Burp Suite creators.",
            "focus": "Web vulnerabilities: XSS, SQLi, SSRF, OAuth, JWT attacks",
            "cost": "Free",
        },
        {
            "name": "PentesterLab",
            "url": "https://pentesterlab.com",
            "desc": "Practical web pentesting exercises with in-depth write-ups.",
            "focus": "Web app pentesting, source code review",
            "cost": "Free / $20/mo PRO",
        },
        {
            "name": "Cybrary",
            "url": "https://cybrary.it",
            "desc": "Structured cybersecurity courses and career paths.",
            "focus": "Certifications prep: CISSP, CEH, CompTIA, Pentest+",
            "cost": "Free / $59/mo premium",
        },
        {
            "name": "VulnHub",
            "url": "https://www.vulnhub.com",
            "desc": "Free downloadable vulnerable VMs to practice on locally.",
            "focus": "Local lab practice, wide variety of difficulty levels",
            "cost": "Free",
        },
        {
            "name": "OWASP",
            "url": "https://owasp.org",
            "desc": "Open-source web security standards and learning materials.",
            "focus": "Web app security, Top 10 vulnerabilities, tools",
            "cost": "Free",
        },
        {
            "name": "PicoCTF",
            "url": "https://picoctf.org",
            "desc": "CTF competition from Carnegie Mellon University for students.",
            "focus": "CTF: reverse engineering, binary exploitation, forensics",
            "cost": "Free",
        },
    ]

    for p in platforms:
        print(f"  {Colors.BOLD}{Colors.CYAN}{p['name']}{Colors.RESET}")
        print(f"  URL:   {p['url']}")
        print(f"  About: {p['desc']}")
        print(f"  Focus: {Colors.YELLOW}{p['focus']}{Colors.RESET}")
        print(f"  Cost:  {Colors.GREEN}{p['cost']}{Colors.RESET}\n")

    certs = [
        ("CompTIA Security+", "Entry-level security certification, vendor-neutral"),
        ("CompTIA PenTest+", "Penetration testing certification"),
        ("CEH (EC-Council)", "Certified Ethical Hacker"),
        ("OSCP (Offensive Security)", "Practical pentesting cert, gold standard"),
        ("CISSP (ISC2)", "Management/architecture security cert"),
        ("eJPT (eLearnSecurity)", "Junior pentesting cert, affordable and practical"),
    ]

    print(f"\n{Colors.BOLD}{Colors.BLUE}[ Certifications Roadmap ]{Colors.RESET}")
    for name, desc in certs:
        print(f"  {Colors.CYAN}→{Colors.RESET} {Colors.BOLD}{name}{Colors.RESET}: {desc}")

    log_info("Displayed learning resources")


def run() -> None:
    """Main entry point for the TryHackMe/learning resources module."""
    display_learning_resources()
