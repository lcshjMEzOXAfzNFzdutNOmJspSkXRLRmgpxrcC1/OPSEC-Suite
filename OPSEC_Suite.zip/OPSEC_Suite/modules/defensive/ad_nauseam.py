"""
Ad Nauseam and TrackMeNot information module.
Explains ad-clicking obfuscation tools for privacy through noise.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_ad_nauseam_guide() -> None:
    """Display an educational guide to AdNauseam and similar noise-generation tools."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}   AD NAUSEAM & OBFUSCATION PRIVACY TOOLS{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}\n")

    sections = [
        (
            "What is AdNauseam?",
            Colors.BLUE,
            [
                "AdNauseam is a Firefox/Chrome extension that:",
                "  • Blocks all ads (like uBlock Origin)",
                "  • Secretly clicks every blocked ad in the background",
                "  • Poisons your advertising profile with random interests",
                "  • Causes advertisers to pay money while you receive nothing",
                "",
                "Install: https://adnauseam.io",
                "Note: Google banned it from Chrome Web Store — use Firefox or",
                "install manually from the AdNauseam website.",
            ],
        ),
        (
            "How Obfuscation Works",
            Colors.CYAN,
            [
                "Traditional ad blockers: block ads → no data collected",
                "AdNauseam: block ads + generate fake clicks → corrupt data",
                "",
                "When your profile says you're interested in:",
                "  guns, diabetes, depression, firearms, beauty, crypto,",
                "  luxury cars, baby products, and adult content — ALL AT ONCE",
                "  → the profile is useless for targeted advertising.",
                "",
                "This is privacy through obfuscation, not through hiding.",
            ],
        ),
        (
            "TrackMeNot",
            Colors.GREEN,
            [
                "Generates random search queries to search engines.",
                "Mixes your real searches with thousands of decoy searches.",
                "Available for Firefox and Chrome.",
                "Install: https://trackmenot.io",
                "",
                "Effect: Your search profile becomes a random collection of",
                "everything — making it impossible to build an accurate profile.",
            ],
        ),
        (
            "Other Obfuscation Tools",
            Colors.YELLOW,
            [
                "Noiszy (Chrome):",
                "  Visits random websites to poison your browsing history.",
                "  Install: https://noiszy.com",
                "",
                "Cache-money (conceptual):",
                "  Loads pages in background to poison analytics data.",
                "",
                "Fake Email Generators:",
                "  Use temp email (this tool) for signups → pollutes databases.",
                "",
                "RandomUA:",
                "  Randomizes your User-Agent string on every request.",
            ],
        ),
        (
            "Limitations of Obfuscation",
            Colors.RED,
            [
                "Obfuscation ≠ anonymity — you are still identified.",
                "Your real requests are still logged alongside fake ones.",
                "May increase bandwidth usage significantly.",
                "Some sites detect and block automated/unusual behavior.",
                "Does not protect against ISP-level surveillance.",
                "Does not prevent browser fingerprinting.",
                "",
                "Best used alongside VPN + strong tracker blocking, not instead of.",
            ],
        ),
        (
            "The Obfuscation Strategy",
            Colors.PURPLE,
            [
                "Helen Nissenbaum's framework: 'Privacy in an Age of Big Data'",
                "When hiding is impossible, pollution is the next best thing.",
                "Make data collection expensive, inaccurate, and unreliable.",
                "Collective action: if everyone uses AdNauseam,",
                "  behavioral ad targeting becomes economically unviable.",
            ],
        ),
    ]

    for title, color, items in sections:
        print(f"{color}{Colors.BOLD}[ {title} ]{Colors.RESET}")
        for item in items:
            print(f"  {item}")
        print()

    log_info("Displayed AdNauseam guide")


def run() -> None:
    """Main entry point for the AdNauseam module."""
    display_ad_nauseam_guide()
