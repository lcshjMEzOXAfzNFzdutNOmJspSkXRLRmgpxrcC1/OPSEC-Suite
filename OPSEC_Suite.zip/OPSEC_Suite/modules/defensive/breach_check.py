"""
Data breach checking module.
Checks email addresses against the HaveIBeenPwned database.
"""

import hashlib
import time
from typing import Dict, Any, List

import requests

from utils.colors import Colors
from utils.config_manager import ConfigManager
from utils.logger import log_info, log_error


def check_hibp_email(email: str, api_key: str = "") -> Dict[str, Any]:
    """
    Check if an email has been in known data breaches using HaveIBeenPwned API.

    Requires a HIBP API key for the /breachedaccount endpoint.
    Falls back to the public /breach endpoint for general info.

    Args:
        email: Email address to check
        api_key: HaveIBeenPwned API key (get one at https://haveibeenpwned.com/API/Key)

    Returns:
        Dictionary with breach results or error info
    """
    headers = {"User-Agent": "OPSEC-Suite-BreachChecker"}
    if api_key:
        headers["hibp-api-key"] = api_key

    url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}?truncateResponse=false"

    try:
        resp = requests.get(url, headers=headers, timeout=10)

        if resp.status_code == 200:
            breaches = resp.json()
            return {
                "email": email,
                "found": True,
                "breach_count": len(breaches),
                "breaches": [
                    {
                        "name": b.get("Name"),
                        "domain": b.get("Domain"),
                        "breach_date": b.get("BreachDate"),
                        "description": b.get("Description", "")[:200],
                        "data_classes": b.get("DataClasses", []),
                        "is_verified": b.get("IsVerified", False),
                        "is_sensitive": b.get("IsSensitive", False),
                    }
                    for b in breaches
                ],
            }
        elif resp.status_code == 404:
            return {"email": email, "found": False, "breach_count": 0, "breaches": []}
        elif resp.status_code == 401:
            return {
                "email": email,
                "error": "API key required",
                "manual_url": f"https://haveibeenpwned.com/account/{email}",
                "tip": "Get a free API key at https://haveibeenpwned.com/API/Key",
            }
        elif resp.status_code == 429:
            return {"email": email, "error": "Rate limited. Wait 1 second and try again."}
        else:
            return {"email": email, "error": f"HTTP {resp.status_code}"}

    except requests.RequestException as e:
        return {"email": email, "error": str(e)}


def check_password_pwned(password: str) -> int:
    """
    Check if a password has appeared in known data breaches using k-Anonymity.

    Uses the HIBP Pwned Passwords API — the password is NEVER sent in full.
    Only the first 5 characters of the SHA1 hash are sent.

    Args:
        password: Password to check

    Returns:
        Number of times the password was found (0 = not found)
    """
    sha1 = hashlib.sha1(password.encode("utf-8")).hexdigest().upper()
    prefix = sha1[:5]
    suffix = sha1[5:]

    try:
        resp = requests.get(
            f"https://api.pwnedpasswords.com/range/{prefix}",
            headers={"User-Agent": "OPSEC-Suite-PasswordCheck"},
            timeout=8,
        )
        if resp.status_code == 200:
            for line in resp.text.splitlines():
                hash_suffix, count = line.split(":")
                if hash_suffix == suffix:
                    return int(count)
            return 0
        else:
            return -1
    except Exception as e:
        log_error(f"Password check error: {e}")
        return -1


def check_pastes(email: str, api_key: str = "") -> Dict[str, Any]:
    """
    Check if an email appears in known paste sites using HIBP API.

    Args:
        email: Email address to check
        api_key: HIBP API key

    Returns:
        Paste data or error info
    """
    if not api_key:
        return {
            "error": "API key required for paste lookup",
            "tip": "https://haveibeenpwned.com/API/Key",
        }

    headers = {"User-Agent": "OPSEC-Suite", "hibp-api-key": api_key}
    try:
        resp = requests.get(
            f"https://haveibeenpwned.com/api/v3/pasteaccount/{email}",
            headers=headers, timeout=10
        )
        if resp.status_code == 200:
            return {"email": email, "pastes": resp.json()}
        elif resp.status_code == 404:
            return {"email": email, "pastes": []}
        else:
            return {"error": f"HTTP {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}


def display_breach_results(data: Dict[str, Any]) -> None:
    """
    Pretty-print breach check results.

    Args:
        data: Results from check_hibp_email()
    """
    if "error" in data:
        print(f"\n  {Colors.YELLOW}Note: {data.get('error')}{Colors.RESET}")
        if "manual_url" in data:
            print(f"  Check manually: {Colors.CYAN}{data['manual_url']}{Colors.RESET}")
        if "tip" in data:
            print(f"  Tip: {data['tip']}")
        return

    email = data.get("email", "Unknown")
    found = data.get("found", False)
    count = data.get("breach_count", 0)

    if not found:
        print(f"\n  {Colors.GREEN}✓ {email} — NOT found in any known breach!{Colors.RESET}")
        print(f"  {Colors.DIM}Note: Absence of result doesn't guarantee safety.{Colors.RESET}")
        return

    print(f"\n  {Colors.RED}⚠ {email} — Found in {count} breach(es)!{Colors.RESET}\n")

    for breach in data.get("breaches", []):
        sensitive_tag = f" {Colors.RED}[SENSITIVE]{Colors.RESET}" if breach.get("is_sensitive") else ""
        print(f"  {Colors.BOLD}{Colors.YELLOW}[{breach['name']}]{Colors.RESET}{sensitive_tag}")
        print(f"  Domain:     {breach.get('domain', 'N/A')}")
        print(f"  Date:       {breach.get('breach_date', 'Unknown')}")
        data_classes = ", ".join(breach.get("data_classes", [])[:8])
        print(f"  Exposed:    {Colors.RED}{data_classes}{Colors.RESET}")
        print()

    print(f"  {Colors.BOLD}Recommended actions:{Colors.RESET}")
    print(f"  {Colors.CYAN}1.{Colors.RESET} Change your password for any affected site immediately")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Use a unique password for every site (use a password manager)")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Enable 2FA on all affected accounts")
    print(f"  {Colors.CYAN}4.{Colors.RESET} Check if the same password was used elsewhere")


def run() -> None:
    """Main entry point for the breach check module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}      DATA BREACH CHECKER (HaveIBeenPwned){Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")

    cfg = ConfigManager("config.json")
    api_key = cfg.get("api_keys.hibp", "")

    if not api_key:
        print(f"\n  {Colors.YELLOW}[!] No HIBP API key in config.json.{Colors.RESET}")
        print(f"  Full breach details require a key from: {Colors.CYAN}https://haveibeenpwned.com/API/Key{Colors.RESET}")
        print(f"  The password check (pwned passwords) does NOT require a key.\n")

    print(f"  {Colors.CYAN}1.{Colors.RESET} Check email for breaches")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Check if password was pwned (private k-Anonymity method)")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Check email in paste sites")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    elif choice == "1":
        email = input("  Email address: ").strip()
        if not email:
            return
        key = api_key or input("  API key (optional — press Enter to skip): ").strip()
        print(f"\n  {Colors.YELLOW}Checking breach database...{Colors.RESET}")
        results = check_hibp_email(email, api_key=key)
        display_breach_results(results)
        log_info(f"Checked email for breaches: {email[:5]}***")

    elif choice == "2":
        import getpass
        password = getpass.getpass("  Password to check (not sent in plain text): ")
        if not password:
            return
        print(f"\n  {Colors.YELLOW}Checking against pwned passwords database...{Colors.RESET}")
        print(f"  {Colors.DIM}(Only the first 5 chars of your password's SHA1 hash are sent){Colors.RESET}")
        count = check_password_pwned(password)
        if count == -1:
            print(f"\n  {Colors.YELLOW}Could not connect to API.{Colors.RESET}")
        elif count == 0:
            print(f"\n  {Colors.GREEN}✓ Password not found in any known breach! (Still use a strong, unique password){Colors.RESET}")
        else:
            print(f"\n  {Colors.RED}⚠ Password found {count:,} times in breach data!{Colors.RESET}")
            print(f"  {Colors.RED}Stop using this password immediately.{Colors.RESET}")
        log_info(f"Checked password against HIBP pwned passwords")

    elif choice == "3":
        email = input("  Email address: ").strip()
        key = api_key or input("  API key (required for paste lookup): ").strip()
        if not key:
            print(f"  {Colors.RED}API key required for paste lookup.{Colors.RESET}")
            return
        result = check_pastes(email, api_key=key)
        pastes = result.get("pastes", [])
        if pastes:
            print(f"\n  {Colors.RED}Found in {len(pastes)} paste(s):{Colors.RESET}")
            for p in pastes:
                print(f"  Source: {p.get('Source')}  Date: {p.get('Date')}  Emails: {p.get('EmailCount')}")
        elif "error" in result:
            print(f"\n  {Colors.YELLOW}{result['error']}{Colors.RESET}")
        else:
            print(f"\n  {Colors.GREEN}✓ Not found in any known pastes.{Colors.RESET}")
