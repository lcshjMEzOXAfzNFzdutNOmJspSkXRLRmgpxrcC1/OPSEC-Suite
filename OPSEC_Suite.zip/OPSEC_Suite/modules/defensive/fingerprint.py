"""
Browser fingerprint information module.
Explains what browser fingerprinting is and how to mitigate it.
"""

import platform
import sys
from typing import Dict, Any

from utils.colors import Colors
from utils.logger import log_info


def get_system_fingerprint() -> Dict[str, Any]:
    """
    Collect basic system fingerprint information (same as browser would see).

    Returns:
        Dictionary of fingerprint-relevant system attributes
    """
    return {
        "OS": platform.system(),
        "OS Release": platform.release(),
        "Machine": platform.machine(),
        "Processor": platform.processor()[:50] or "Unknown",
        "Python Version": sys.version.split()[0],
        "Hostname": platform.node(),
    }


def display_fingerprinting_guide() -> None:
    """Display an educational guide to browser fingerprinting and countermeasures."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}          BROWSER FINGERPRINTING GUIDE{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}\n")

    sections = [
        (
            "What is Browser Fingerprinting?",
            Colors.BLUE,
            [
                "Browser fingerprinting collects passive signals from your browser",
                "to create a unique identifier — even without cookies.",
                "",
                "Unlike cookies, fingerprints cannot be deleted.",
                "A fingerprint is typically 99.9%+ accurate at identifying you.",
            ],
        ),
        (
            "Data Points Collected",
            Colors.RED,
            [
                "User-Agent string (browser, OS, version)",
                "Screen resolution and color depth",
                "Timezone and language settings",
                "Installed fonts (200+ fonts can be detected)",
                "Browser plugins and extensions",
                "Canvas fingerprint (GPU rendering differences)",
                "WebGL fingerprint (graphics card signature)",
                "AudioContext fingerprint (audio processing differences)",
                "Battery status API (charge level + charging state)",
                "Network information (connection type, speed)",
                "CPU core count and memory",
                "WebRTC — reveals local/public IP even behind VPN",
                "TCP/IP stack fingerprint (OS identification)",
                "Keystroke dynamics (typing speed and rhythm)",
                "Mouse movement patterns",
            ],
        ),
        (
            "Test Your Fingerprint",
            Colors.CYAN,
            [
                "Panopticlick (EFF):   https://coveryourtracks.eff.org",
                "BrowserLeaks:         https://browserleaks.com",
                "AmIUnique:            https://amiunique.org",
                "Fingerprint.com:      https://fingerprint.com/demo/",
                "IPLeak.net:           https://ipleak.net",
            ],
        ),
        (
            "Countermeasures",
            Colors.GREEN,
            [
                "1. Use Tor Browser — standardizes fingerprint across all users",
                "2. Use Firefox with resistFingerprinting = true (about:config)",
                "3. Use Brave — built-in fingerprint randomization",
                "4. Disable JavaScript (very effective but breaks many sites)",
                "5. Use browser extensions:",
                "   • Canvas Blocker — randomizes canvas fingerprint",
                "   • JShelter — protects against JS-based fingerprinting",
                "   • uBlock Origin — blocks tracker scripts",
                "6. Disable WebRTC (prevents IP leaks):",
                "   Firefox: media.peerconnection.enabled = false",
                "   Chrome: WebRTC Network Limiter extension",
                "7. Use VPN + disable WebRTC",
                "8. Don't install unusual fonts or browser plugins",
                "9. Keep default window size (don't maximize in Tor)",
                "10. Use a VM with a standard OS configuration",
            ],
        ),
        (
            "The Fingerprinting Paradox",
            Colors.YELLOW,
            [
                "Blocking fingerprinting can itself make you more unique!",
                "If 99.9% of users don't block canvas, blocking it flags you.",
                "",
                "Best approach: Use Tor Browser or Brave — they blend you into",
                "a crowd of users with the same fingerprint rather than",
                "trying to hide individual data points.",
                "",
                "Privacy through uniformity, not through absence.",
            ],
        ),
    ]

    for title, color, items in sections:
        print(f"{color}{Colors.BOLD}[ {title} ]{Colors.RESET}")
        for item in items:
            print(f"  {item}")
        print()

    log_info("Displayed fingerprinting guide")


def run() -> None:
    """Main entry point for the fingerprint module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}     BROWSER FINGERPRINT GUIDE{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")

    info = get_system_fingerprint()
    print(f"\n  {Colors.BOLD}Your system fingerprint attributes:{Colors.RESET}")
    for k, v in info.items():
        print(f"  {Colors.CYAN}{k:<20}{Colors.RESET}: {v}")

    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Fingerprinting guide and countermeasures")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        display_fingerprinting_guide()
