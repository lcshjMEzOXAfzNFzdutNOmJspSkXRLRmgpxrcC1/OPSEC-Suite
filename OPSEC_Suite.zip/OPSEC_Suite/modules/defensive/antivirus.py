"""
Antivirus detection and status module.
Detects running antivirus software and checks Windows Defender status.
"""

import platform
import subprocess
import os
from typing import Dict, List, Any

from utils.colors import Colors
from utils.logger import log_info, log_warning


def detect_antivirus_windows() -> List[Dict[str, str]]:
    """
    Detect installed antivirus products on Windows via WMI.

    Returns:
        List of detected antivirus products with name and status
    """
    products = []
    try:
        result = subprocess.run(
            ["powershell", "-Command",
             "Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntiVirusProduct | "
             "Select-Object displayName, productState | ConvertTo-Json"],
            capture_output=True, text=True, timeout=15
        )
        if result.returncode == 0 and result.stdout.strip():
            import json
            data = json.loads(result.stdout)
            if isinstance(data, dict):
                data = [data]
            for item in data:
                state = item.get("productState", 0)
                enabled = bool(state & 0x1000)
                updated = bool(state & 0x0010)
                products.append({
                    "name": item.get("displayName", "Unknown"),
                    "enabled": "Yes" if enabled else "No",
                    "updated": "Yes" if updated else "No",
                })
    except Exception as e:
        log_warning(f"WMI AV detection error: {e}")
    return products


def check_windows_defender() -> Dict[str, Any]:
    """
    Check the status of Windows Defender (real-time protection, definitions).

    Returns:
        Dictionary with Defender status fields
    """
    try:
        result = subprocess.run(
            ["powershell", "-Command",
             "Get-MpComputerStatus | Select-Object RealTimeProtectionEnabled, "
             "AntispywareEnabled, AntivirusEnabled, "
             "QuickScanAge, FullScanAge, "
             "AntispywareSignatureLastUpdated, AntivirusSignatureLastUpdated | ConvertTo-Json"],
            capture_output=True, text=True, timeout=15
        )
        if result.returncode == 0 and result.stdout.strip():
            import json
            return json.loads(result.stdout)
        return {"error": "Could not read Windows Defender status"}
    except Exception as e:
        return {"error": str(e)}


def detect_antivirus_linux() -> List[str]:
    """
    Detect antivirus/security tools running on Linux.

    Returns:
        List of detected security tool names
    """
    tools = {
        "clamav": "ClamAV Antivirus",
        "clamd": "ClamAV Daemon",
        "rkhunter": "Rootkit Hunter",
        "chkrootkit": "Chkrootkit",
        "aide": "AIDE (intrusion detection)",
        "ossec": "OSSEC HIDS",
        "wazuh": "Wazuh Agent",
        "freshclam": "ClamAV Auto-updater",
        "apparmor": "AppArmor (MAC)",
        "selinux": "SELinux (MAC)",
    }

    found = []
    for binary, name in tools.items():
        try:
            result = subprocess.run(
                ["which", binary], capture_output=True, timeout=3
            )
            if result.returncode == 0:
                found.append(f"{name} ({binary})")
        except Exception:
            pass
    return found


def detect_antivirus_mac() -> List[str]:
    """
    Detect antivirus/security tools on macOS.

    Returns:
        List of detected tool names
    """
    tools = {
        "malwarebytes": "Malwarebytes",
        "clamav": "ClamAV",
        "bitdefender": "Bitdefender",
        "sentinel": "SentinelOne",
    }

    found = []
    app_dirs = ["/Applications", os.path.expanduser("~/Applications")]
    for app_dir in app_dirs:
        try:
            for app in os.listdir(app_dir):
                for key, name in tools.items():
                    if key.lower() in app.lower():
                        found.append(f"{name} (app)")
        except Exception:
            pass

    for binary in tools:
        try:
            result = subprocess.run(["which", binary], capture_output=True, timeout=3)
            if result.returncode == 0:
                found.append(tools[binary])
        except Exception:
            pass

    return list(set(found))


def run_clamscan(path: str) -> Dict[str, Any]:
    """
    Run a ClamAV scan on a file or directory.

    Args:
        path: File or directory path to scan

    Returns:
        Scan results dictionary
    """
    try:
        result = subprocess.run(
            ["clamscan", "-r", "--bell", path],
            capture_output=True, text=True, timeout=120
        )
        output = result.stdout + result.stderr
        infected = sum(1 for line in output.splitlines() if "FOUND" in line)
        return {
            "path": path,
            "exit_code": result.returncode,
            "infected": infected,
            "output": output[-2000:],
            "clean": result.returncode == 0,
        }
    except FileNotFoundError:
        return {
            "error": "ClamAV not installed",
            "install": "sudo apt install clamav && sudo freshclam",
        }
    except subprocess.TimeoutExpired:
        return {"error": "Scan timed out"}
    except Exception as e:
        return {"error": str(e)}


def run() -> None:
    """Main entry point for the antivirus module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}        ANTIVIRUS & SECURITY STATUS{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*52}{Colors.RESET}")

    system = platform.system()
    print(f"\n  Platform: {Colors.CYAN}{system}{Colors.RESET}\n")

    print(f"  {Colors.CYAN}1.{Colors.RESET} Detect installed antivirus software")
    if system == "Windows":
        print(f"  {Colors.CYAN}2.{Colors.RESET} Check Windows Defender status")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Run ClamAV scan (if installed)")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    elif choice == "1":
        print(f"\n  {Colors.YELLOW}Detecting antivirus software...{Colors.RESET}")
        if system == "Windows":
            products = detect_antivirus_windows()
            if products:
                print(f"\n  {Colors.GREEN}Detected AV products:{Colors.RESET}")
                for p in products:
                    enabled_color = Colors.GREEN if p["enabled"] == "Yes" else Colors.RED
                    print(f"  {Colors.CYAN}→{Colors.RESET} {p['name']}")
                    print(f"    Enabled: {enabled_color}{p['enabled']}{Colors.RESET}  Updated: {p['updated']}")
            else:
                print(f"\n  {Colors.RED}No antivirus products detected!{Colors.RESET}")
        elif system == "Linux":
            tools = detect_antivirus_linux()
            if tools:
                print(f"\n  {Colors.GREEN}Detected security tools:{Colors.RESET}")
                for t in tools:
                    print(f"  {Colors.CYAN}→{Colors.RESET} {t}")
            else:
                print(f"\n  {Colors.YELLOW}No common AV/security tools found.{Colors.RESET}")
                print(f"  Install ClamAV: sudo apt install clamav")
        elif system == "Darwin":
            tools = detect_antivirus_mac()
            if tools:
                print(f"\n  {Colors.GREEN}Detected security tools:{Colors.RESET}")
                for t in tools:
                    print(f"  {Colors.CYAN}→{Colors.RESET} {t}")
            else:
                print(f"\n  {Colors.YELLOW}No antivirus tools detected.{Colors.RESET}")
        log_info("Antivirus detection performed")

    elif choice == "2" and system == "Windows":
        print(f"\n  {Colors.YELLOW}Checking Windows Defender...{Colors.RESET}")
        status = check_windows_defender()
        if "error" not in status:
            for k, v in status.items():
                color = Colors.GREEN if v else Colors.RED
                print(f"  {Colors.CYAN}{k:<40}{Colors.RESET}: {color}{v}{Colors.RESET}")
        else:
            print(f"  {Colors.RED}Error: {status['error']}{Colors.RESET}")

    elif choice == "3":
        path = input("  Path to scan [.]: ").strip() or "."
        print(f"\n  {Colors.YELLOW}Running ClamAV scan on {path}...{Colors.RESET}")
        result = run_clamscan(path)
        if "error" in result:
            print(f"\n  {Colors.RED}Error: {result['error']}{Colors.RESET}")
            if "install" in result:
                print(f"  Install: {Colors.CYAN}{result['install']}{Colors.RESET}")
        else:
            color = Colors.GREEN if result["clean"] else Colors.RED
            status = "CLEAN" if result["clean"] else f"{result['infected']} INFECTED"
            print(f"\n  Result: {color}{status}{Colors.RESET}")
            print(f"\n  {result['output']}")
