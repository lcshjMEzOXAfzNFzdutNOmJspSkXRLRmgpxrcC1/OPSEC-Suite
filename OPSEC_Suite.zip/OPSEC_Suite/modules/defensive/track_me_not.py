"""
TrackMeNot and anti-tracking techniques module.
Explains tracking mechanisms and countermeasures.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_tracking_methods() -> None:
    """Display an overview of web tracking methods and defenses."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}       HOW YOU'RE TRACKED & HOW TO FIGHT BACK{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}\n")

    tracking = [
        (
            "Cookies",
            Colors.RED,
            "Small files stored by websites to identify your browser sessions.",
            ["Block 3rd-party cookies in browser settings",
             "Use Firefox with Enhanced Tracking Protection",
             "Install uBlock Origin",
             "Clear cookies regularly or on shutdown"],
        ),
        (
            "Pixel Tracking",
            Colors.RED,
            "1x1 invisible images that load to confirm email opens or page views.",
            ["Disable remote image loading in email clients",
             "Use ProtonMail which blocks tracking pixels by default",
             "Thunderbird: View → Message Body As → Plain Text"],
        ),
        (
            "Browser Fingerprinting",
            Colors.RED,
            "Identifying your browser via canvas, fonts, WebGL, audio etc.",
            ["Use Tor Browser or Brave",
             "Enable resistFingerprinting in Firefox about:config",
             "Use Canvas Blocker extension"],
        ),
        (
            "CNAME Cloaking",
            Colors.YELLOW,
            "Trackers disguised as first-party resources via DNS CNAME records.",
            ["uBlock Origin blocks many of these",
             "Firefox with Enhanced Tracking Protection catches some",
             "Use NextDNS with strict filtering enabled"],
        ),
        (
            "Supercookies / Evercookies",
            Colors.YELLOW,
            "Trackers that regenerate using localStorage, IndexedDB, ETags etc.",
            ["Regularly clear all browser storage",
             "Use Firefox with containers (Multi-Account Containers)",
             "Tor Browser clears all storage on close"],
        ),
        (
            "Link Decoration / UTM Tracking",
            Colors.YELLOW,
            "URLs with tracking parameters appended (fbclid=, utm_source= etc.)",
            ["ClearURLs extension removes tracking parameters",
             "Firefox strips some tracking params automatically",
             "uBlock Origin URL-stripping mode"],
        ),
        (
            "IP Address Logging",
            Colors.RED,
            "Your IP logged on every request, revealing location and ISP.",
            ["Use a VPN to mask your real IP",
             "Use Tor for maximum IP anonymity",
             "Be aware: VPNs trust your traffic to the VPN provider"],
        ),
        (
            "Behavioral Analytics",
            Colors.ORANGE if hasattr(Colors, 'ORANGE') else Colors.YELLOW,
            "Mouse movements, click patterns, and page interaction tracked for identity.",
            ["Use keyboard shortcuts instead of mouse where possible",
             "AdNauseam generates fake click data",
             "No complete defense — best with combination of above tools"],
        ),
    ]

    for name, color, desc, defenses in tracking:
        print(f"{color}{Colors.BOLD}[ {name} ]{Colors.RESET}")
        print(f"  {Colors.DIM}{desc}{Colors.RESET}")
        print(f"  {Colors.GREEN}Defenses:{Colors.RESET}")
        for d in defenses:
            print(f"    {Colors.CYAN}→{Colors.RESET} {d}")
        print()

    log_info("Displayed tracking methods guide")


def display_essential_extensions() -> None:
    """Display recommended browser privacy extensions."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Essential Privacy Browser Extensions ==={Colors.RESET}\n")

    extensions = [
        ("uBlock Origin", "Ad and tracker blocker — most important extension", "Firefox & Chrome", "HIGH"),
        ("Privacy Badger", "Learns and blocks invisible trackers", "Firefox & Chrome", "HIGH"),
        ("ClearURLs", "Removes tracking parameters from URLs", "Firefox & Chrome", "HIGH"),
        ("LocalCDN", "Serves common libraries locally (prevents CDN tracking)", "Firefox", "MEDIUM"),
        ("Canvas Blocker", "Prevents canvas fingerprinting", "Firefox", "HIGH"),
        ("Cookie AutoDelete", "Auto-deletes cookies from closed tabs", "Firefox & Chrome", "MEDIUM"),
        ("Decentraleyes", "Serves CDN files locally, blocks CDN requests", "Firefox & Chrome", "MEDIUM"),
        ("Firefox Multi-Account Containers", "Isolates sites in separate containers", "Firefox", "HIGH"),
        ("Temporary Containers", "Auto-creates disposable containers", "Firefox", "HIGH"),
        ("NoScript", "Blocks JS by default — maximum protection, low usability", "Firefox", "ADVANCED"),
    ]

    for name, desc, browser, priority in extensions:
        p_color = Colors.GREEN if priority == "HIGH" else Colors.YELLOW if priority == "MEDIUM" else Colors.RED
        print(f"  {Colors.BOLD}{Colors.CYAN}{name}{Colors.RESET}  [{p_color}{priority}{Colors.RESET}]")
        print(f"    {desc}")
        print(f"    Browser: {Colors.DIM}{browser}{Colors.RESET}\n")


def run() -> None:
    """Main entry point for the TrackMeNot module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}     ANTI-TRACKING GUIDE{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} How you're tracked and defenses")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Essential privacy extensions")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        display_tracking_methods()
    elif choice == "2":
        display_essential_extensions()
