"""
Privacy tips and best practices module.
Provides actionable privacy recommendations.
"""

from utils.colors import Colors
from utils.logger import log_info


PRIVACY_TIPS = {
    "Browser Privacy": [
        "Use Firefox with uBlock Origin and Privacy Badger extensions",
        "Enable DNS over HTTPS: Settings → Privacy & Security → Enable DNS over HTTPS",
        "Set 'Delete cookies and site data when Firefox is closed'",
        "Use Firefox Multi-Account Containers to isolate activity",
        "Disable WebRTC: set media.peerconnection.enabled=false in about:config",
        "Use Tor Browser for high-sensitivity browsing",
        "Never use Chrome for private matters — it's a surveillance tool",
    ],
    "Search Engine Privacy": [
        "Use DuckDuckGo, Startpage, or Brave Search",
        "Never search sensitive topics on Google while logged in",
        "Startpage delivers Google results without tracking",
        "Whoogle can be self-hosted for Google results with privacy",
        "SearXNG is an open-source meta search engine you can self-host",
    ],
    "Email Privacy": [
        "Use ProtonMail or Tutanota for end-to-end encrypted email",
        "Use SimpleLogin or AnonAddy for email aliasing",
        "Never open email attachments from unknown senders",
        "Use a separate email for signups/newsletters",
        "PGP-encrypt sensitive email content",
        "Be aware: email metadata (sender, recipient, time) is rarely encrypted",
    ],
    "Phone Privacy": [
        "Disable location permissions for apps that don't need it",
        "Use Signal instead of SMS",
        "Disable ad ID on Android (Settings → Privacy → Ads)",
        "Use a VPN on mobile data",
        "Consider GrapheneOS for maximum Android privacy",
        "Review app permissions regularly",
        "Disable Siri/Google Assistant unless actively using it",
    ],
    "Social Media Privacy": [
        "Use pseudonyms on social platforms",
        "Review and restrict privacy settings on all platforms",
        "Avoid posting real location, workplace, or daily routine",
        "Use a separate email for social accounts",
        "Disable facial recognition on Facebook/Instagram",
        "Regularly review and revoke third-party app access",
        "Scrub old posts with tools like Redact.dev",
    ],
    "Data Minimization": [
        "Give fake DOB, phone number, and address to services that don't need them",
        "Use virtual credit cards (privacy.com) for online purchases",
        "Request data deletion from data brokers (Spokeo, Whitepages, etc.)",
        "Opt out of people search sites",
        "Use USPS informed delivery to monitor your mail",
    ],
}


def display_privacy_tips() -> None:
    """Display all privacy tips organized by category."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*55}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}           PRIVACY BEST PRACTICES{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*55}{Colors.RESET}\n")

    for category, tips in PRIVACY_TIPS.items():
        print(f"{Colors.BOLD}{Colors.BLUE}[ {category} ]{Colors.RESET}")
        for tip in tips:
            print(f"  {Colors.GREEN}•{Colors.RESET} {tip}")
        print()

    log_info("Displayed privacy tips")


def display_privacy_score_guide() -> None:
    """Display a guide to understanding your privacy threat model."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Privacy Threat Modeling ==={Colors.RESET}\n")

    levels = [
        ("Level 1 — Basic", Colors.GREEN, [
            "Use a password manager",
            "Enable 2FA on important accounts",
            "Use Firefox + uBlock Origin",
            "Use Signal for messaging",
        ]),
        ("Level 2 — Moderate", Colors.YELLOW, [
            "VPN on all connections",
            "Encrypted email (ProtonMail)",
            "DNS over HTTPS",
            "Email aliases for sign-ups",
            "Review app permissions",
        ]),
        ("Level 3 — Advanced", Colors.RED, [
            "Tor Browser for browsing",
            "Separate devices for sensitive work",
            "Air-gapped machine for secrets",
            "Tails OS on USB",
            "PGP for all sensitive email",
            "Remove yourself from data brokers",
        ]),
        ("Level 4 — Operational", Colors.PURPLE, [
            "Dedicated hardware per identity",
            "Cash-only purchases",
            "Burner phones + SIMs",
            "No pattern of life predictability",
            "Counter-surveillance awareness",
        ]),
    ]

    for name, color, items in levels:
        print(f"{color}{Colors.BOLD}[ {name} ]{Colors.RESET}")
        for item in items:
            print(f"  {Colors.CYAN}→{Colors.RESET} {item}")
        print()


def run() -> None:
    """Main entry point for the privacy module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         PRIVACY CENTER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Privacy best practices")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Threat model guide")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        display_privacy_tips()
    elif choice == "2":
        display_privacy_score_guide()
