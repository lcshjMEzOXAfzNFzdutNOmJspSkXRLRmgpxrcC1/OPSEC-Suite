"""
Dark web resources and educational information module.
Provides information about Tor, onion services, and safe dark web browsing practices.
"""

import subprocess
import sys
from typing import List, Dict

from utils.colors import Colors
from utils.logger import log_info, log_warning


def check_tor_running() -> bool:
    """
    Check whether a Tor SOCKS proxy is running on localhost:9050.

    Returns:
        True if Tor proxy is reachable, False otherwise
    """
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        result = s.connect_ex(("127.0.0.1", 9050))
        s.close()
        return result == 0
    except Exception:
        return False


def get_tor_ip() -> str:
    """
    Retrieve your exit IP via the Tor network using check.torproject.org.

    Returns:
        IP address string or error message
    """
    try:
        import requests
        proxies = {"http": "socks5h://127.0.0.1:9050", "https": "socks5h://127.0.0.1:9050"}
        resp = requests.get("https://check.torproject.org/api/ip", proxies=proxies, timeout=15)
        data = resp.json()
        return data.get("IP", "Unknown")
    except Exception as e:
        return f"Error: {e}"


def display_darkweb_resources() -> None:
    """
    Display curated educational dark web resources and onion addresses.
    All resources listed here are legitimate educational or news sites.
    """
    resources: List[Dict[str, str]] = [
        {"name": "DuckDuckGo (Tor)", "url": "https://3g2upl4pq6kufc4m.onion", "desc": "Privacy search engine"},
        {"name": "The Tor Project", "url": "https://2gzyxa5ihm7nsggfxnu52rck2vv4rvmdlkiu3zzui5du4xyclen53wid.onion", "desc": "Official Tor Project site"},
        {"name": "ProPublica", "url": "https://p53lf57qovyuvwsc6xnrppyply3vtqm7l6pcobkmyqsiofyeznfu5uqd.onion", "desc": "Investigative journalism"},
        {"name": "SecureDrop", "url": "http://sdolvtfhatvsysc6l34d65ymdwxcujausv7k5jk4cy5ttzhjoi6fzvyd.onion", "desc": "Whistleblower submission platform"},
        {"name": "BBC News", "url": "https://www.bbcnewsd73hkzno2ini43t4gblxvycyac5aw4gnv7t2rccijh7745uqd.onion", "desc": "News service via Tor"},
        {"name": "Facebook", "url": "https://facebookwkhpilnemxj7ascrwwwi72ytt480tg5ovow4rqv6qllnfbvwid.onion", "desc": "Facebook's official onion address"},
    ]

    print(f"\n{Colors.BOLD}{Colors.PURPLE}=== Dark Web Educational Resources ==={Colors.RESET}")
    print(f"{Colors.YELLOW}[!] These are legitimate public-facing onion sites for education/news.{Colors.RESET}\n")

    for i, r in enumerate(resources, 1):
        print(f"  {Colors.CYAN}{i}.{Colors.RESET} {Colors.BOLD}{r['name']}{Colors.RESET}")
        print(f"     URL : {Colors.DIM}{r['url']}{Colors.RESET}")
        print(f"     Info: {r['desc']}\n")

    log_info("Displayed dark web educational resources")


def display_tor_setup_guide() -> None:
    """
    Display a guide for setting up and using Tor Browser safely.
    """
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Tor Browser Setup Guide ==={Colors.RESET}\n")

    steps = [
        ("Download Tor Browser", "https://www.torproject.org/download/", "Always verify the GPG signature"),
        ("Verify the download", "gpg --verify tor-browser-*.tar.xz.asc", "Use Tor Project's signing key"),
        ("Use Security Level: Safest", "Settings → Privacy & Security → Safest", "Disables JavaScript by default"),
        ("Never maximize the window", "Keep default size", "Prevents screen resolution fingerprinting"),
        ("Don't log in to personal accounts", "Use separate identities", "Avoids deanonymization"),
        ("Use HTTPS-only mode", "Built into Tor Browser", "Prevents exit node sniffing"),
        ("Clear cookies per session", "Automatic in Tor Browser", "Prevents tracking across sessions"),
    ]

    for i, (step, detail, tip) in enumerate(steps, 1):
        print(f"  {Colors.GREEN}{i}.{Colors.RESET} {Colors.BOLD}{step}{Colors.RESET}")
        print(f"     Command/Setting: {Colors.CYAN}{detail}{Colors.RESET}")
        print(f"     Tip: {Colors.YELLOW}{tip}{Colors.RESET}\n")

    log_info("Displayed Tor setup guide")


def run() -> None:
    """Main entry point for the dark web information module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         DARK WEB INFORMATION CENTER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")

    tor_status = check_tor_running()
    if tor_status:
        print(f"\n  Tor Proxy: {Colors.GREEN}RUNNING{Colors.RESET} (port 9050)")
        tor_ip = get_tor_ip()
        print(f"  Tor Exit IP: {Colors.CYAN}{tor_ip}{Colors.RESET}")
    else:
        print(f"\n  Tor Proxy: {Colors.RED}NOT RUNNING{Colors.RESET}")
        print(f"  {Colors.YELLOW}Install Tor: https://www.torproject.org{Colors.RESET}")

    print(f"\n  {Colors.BOLD}Options:{Colors.RESET}")
    print(f"  {Colors.CYAN}1.{Colors.RESET} View educational .onion resources")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Tor Browser setup guide")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        display_darkweb_resources()
    elif choice == "2":
        display_tor_setup_guide()
