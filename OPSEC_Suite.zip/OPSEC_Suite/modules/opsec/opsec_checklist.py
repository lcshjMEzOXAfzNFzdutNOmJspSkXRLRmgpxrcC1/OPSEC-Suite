"""
OPSEC checklist module.
Provides an interactive security self-assessment checklist.
"""

from typing import Dict, List, Tuple

from utils.colors import Colors
from utils.logger import log_info


CHECKLIST: List[Dict] = [
    {
        "category": "Device Security",
        "items": [
            "Full disk encryption enabled (BitLocker/FileVault/LUKS)",
            "Strong login password (12+ chars, no dictionary words)",
            "Screen auto-lock set to 5 minutes or less",
            "BIOS/UEFI password set",
            "Secure Boot enabled",
            "Firmware kept up to date",
            "No unknown USB devices ever plugged in",
        ],
    },
    {
        "category": "Network Security",
        "items": [
            "Using VPN on all connections",
            "DNS over HTTPS (DoH) or DNS over TLS enabled",
            "Home router firmware updated",
            "Home WiFi uses WPA3 or WPA2-AES",
            "Public WiFi never used without VPN",
            "MAC address randomization enabled",
            "IPv6 disabled if not needed (prevents leaks)",
        ],
    },
    {
        "category": "Browser & Online",
        "items": [
            "Firefox or Brave used as primary browser",
            "uBlock Origin installed",
            "Privacy Badger or similar tracker blocker installed",
            "HTTPS-only mode enabled",
            "Cookies cleared regularly",
            "No browser auto-fill for passwords/addresses",
            "Separate browser profiles for separate identities",
        ],
    },
    {
        "category": "Passwords & Accounts",
        "items": [
            "Unique password for every account",
            "Password manager in use (Bitwarden, KeePass, etc.)",
            "2FA/MFA enabled on all critical accounts",
            "TOTP-based 2FA preferred over SMS",
            "Email account uses strong password + 2FA",
            "Security questions use random answers (stored in password manager)",
            "Checked HaveIBeenPwned for email breaches",
        ],
    },
    {
        "category": "Communications",
        "items": [
            "Signal used for sensitive communications",
            "End-to-end encrypted email (ProtonMail/Tutanota)",
            "No sensitive info shared via SMS",
            "No sensitive info shared via standard email",
            "Disappearing messages enabled where possible",
            "Voice calls over encrypted VoIP when needed",
        ],
    },
    {
        "category": "Physical Security",
        "items": [
            "Webcam covered when not in use",
            "Mic physically disconnected or covered",
            "Work done away from security cameras when sensitive",
            "Screen not visible to others in public (privacy filter)",
            "Devices never left unattended in public",
            "Sensitive documents shredded",
        ],
    },
    {
        "category": "Accounts & Identity",
        "items": [
            "Minimal personal info on social media",
            "Separate email addresses for different purposes",
            "Real name not used for sensitive services",
            "Consistent cover identity maintained if needed",
            "Old unused accounts deleted",
            "Location sharing disabled on apps that don't need it",
        ],
    },
]


def run_interactive_checklist() -> Tuple[int, int]:
    """
    Run an interactive OPSEC checklist, asking user to confirm each item.

    Returns:
        Tuple of (checked_count, total_count)
    """
    checked = 0
    total = 0
    results: Dict[str, List[Tuple[str, bool]]] = {}

    print(f"\n{Colors.BOLD}{Colors.CYAN}Answer y/n for each item. Press Enter to skip.{Colors.RESET}\n")

    for section in CHECKLIST:
        cat = section["category"]
        results[cat] = []
        print(f"\n{Colors.BOLD}{Colors.PURPLE}[ {cat} ]{Colors.RESET}")

        for item in section["items"]:
            total += 1
            answer = input(f"  {Colors.CYAN}?{Colors.RESET} {item} [{Colors.GREEN}y{Colors.RESET}/{Colors.RED}n{Colors.RESET}]: ").strip().lower()
            done = answer == "y"
            if done:
                checked += 1
            results[cat].append((item, done))

    print(f"\n{Colors.BOLD}{Colors.BLUE}{'='*55}{Colors.RESET}")
    print(f"{Colors.BOLD}OPSEC SCORE: {checked}/{total} ({int(checked/total*100)}%){Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}{'='*55}{Colors.RESET}\n")

    pct = int(checked / total * 100) if total > 0 else 0
    if pct >= 90:
        print(f"  {Colors.GREEN}Excellent OPSEC! Keep it up.{Colors.RESET}")
    elif pct >= 70:
        print(f"  {Colors.YELLOW}Good, but room for improvement. Focus on unchecked items.{Colors.RESET}")
    elif pct >= 50:
        print(f"  {Colors.YELLOW}Moderate OPSEC. Address the gaps systematically.{Colors.RESET}")
    else:
        print(f"  {Colors.RED}Poor OPSEC. Significant vulnerabilities exist.{Colors.RESET}")

    print(f"\n{Colors.BOLD}Items to address:{Colors.RESET}")
    for cat, items in results.items():
        missing = [item for item, done in items if not done]
        if missing:
            print(f"\n  {Colors.PURPLE}[{cat}]{Colors.RESET}")
            for m in missing:
                print(f"    {Colors.RED}✗{Colors.RESET} {m}")

    log_info(f"OPSEC checklist completed: {checked}/{total}")
    return checked, total


def show_quick_checklist() -> None:
    """Display the full checklist without interaction."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}=== OPSEC Quick Reference Checklist ==={Colors.RESET}\n")
    for section in CHECKLIST:
        print(f"{Colors.BOLD}{Colors.BLUE}[ {section['category']} ]{Colors.RESET}")
        for item in section["items"]:
            print(f"  {Colors.CYAN}□{Colors.RESET} {item}")
        print()


def run() -> None:
    """Main entry point for the OPSEC checklist module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}           OPSEC SELF-ASSESSMENT{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Interactive assessment (scored)")
    print(f"  {Colors.CYAN}2.{Colors.RESET} View quick reference list")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        run_interactive_checklist()
    elif choice == "2":
        show_quick_checklist()
