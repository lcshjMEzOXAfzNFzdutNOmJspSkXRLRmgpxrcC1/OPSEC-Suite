"""
Persona creation module.
Generates realistic fake identities for operational security purposes.
"""

import random
import string
import hashlib
from typing import Dict, List

from utils.colors import Colors
from utils.logger import log_info

try:
    from faker import Faker
    FAKER_AVAILABLE = True
except ImportError:
    FAKER_AVAILABLE = False

FIRST_NAMES_M = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Thomas", "Charles"]
FIRST_NAMES_F = ["Mary", "Patricia", "Jennifer", "Linda", "Barbara", "Elizabeth", "Susan", "Jessica", "Sarah", "Karen"]
LAST_NAMES = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"]
DOMAINS = ["gmail.com", "yahoo.com", "outlook.com", "protonmail.com", "tutanota.com", "mail.com"]


def generate_username(first: str, last: str) -> List[str]:
    """
    Generate multiple username variants from a name.

    Args:
        first: First name
        last: Last name

    Returns:
        List of username suggestions
    """
    rand_num = random.randint(10, 9999)
    variants = [
        f"{first.lower()}{last.lower()}",
        f"{first.lower()}.{last.lower()}",
        f"{first.lower()}_{last.lower()}",
        f"{first.lower()}{last.lower()}{rand_num}",
        f"{first[0].lower()}{last.lower()}",
        f"{first[0].lower()}{last.lower()}{rand_num}",
        f"{last.lower()}{first[0].lower()}",
        f"{first.lower()}{rand_num}",
    ]
    return variants


def generate_strong_password(length: int = 20) -> str:
    """
    Generate a cryptographically random strong password.

    Args:
        length: Password length (default 20)

    Returns:
        Random password string
    """
    chars = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
    while True:
        pwd = "".join(random.SystemRandom().choice(chars) for _ in range(length))
        has_upper = any(c.isupper() for c in pwd)
        has_lower = any(c.islower() for c in pwd)
        has_digit = any(c.isdigit() for c in pwd)
        has_special = any(c in "!@#$%^&*()-_=+" for c in pwd)
        if has_upper and has_lower and has_digit and has_special:
            return pwd


def generate_persona(gender: str = "random", locale: str = "en_US") -> Dict:
    """
    Generate a complete fake identity persona.

    Args:
        gender: 'male', 'female', or 'random'
        locale: Faker locale string (e.g. 'en_US', 'de_DE')

    Returns:
        Dictionary containing persona details
    """
    if FAKER_AVAILABLE:
        fake = Faker(locale)
        Faker.seed(random.randint(0, 999999))

        if gender == "random":
            gender = random.choice(["male", "female"])

        if gender == "male":
            first = fake.first_name_male()
        else:
            first = fake.first_name_female()

        last = fake.last_name()
        dob = fake.date_of_birth(minimum_age=22, maximum_age=55)
        address = fake.address().replace("\n", ", ")
        phone = fake.phone_number()
        occupation = fake.job()
        company = fake.company()
        city = fake.city()
        country = fake.country()
        zip_code = fake.postcode()
    else:
        if gender == "random":
            gender = random.choice(["male", "female"])
        first = random.choice(FIRST_NAMES_M if gender == "male" else FIRST_NAMES_F)
        last = random.choice(LAST_NAMES)
        year = random.randint(1970, 2000)
        month = random.randint(1, 12)
        day = random.randint(1, 28)
        dob = f"{year}-{month:02d}-{day:02d}"
        address = f"{random.randint(1, 9999)} {random.choice(['Main', 'Oak', 'Pine', 'Elm'])} St"
        phone = f"+1-{random.randint(200,999)}-{random.randint(100,999)}-{random.randint(1000,9999)}"
        occupation = random.choice(["Software Engineer", "Teacher", "Accountant", "Nurse", "Sales Manager"])
        company = random.choice(["Tech Solutions", "Global Services", "Bright Futures", "Clear Vision"])
        city = random.choice(["Springfield", "Riverside", "Lakewood", "Franklin"])
        country = "United States"
        zip_code = f"{random.randint(10000, 99999)}"

    email_domain = random.choice(DOMAINS)
    usernames = generate_username(first, last)
    chosen_username = random.choice(usernames)
    email = f"{chosen_username}@{email_domain}"
    password = generate_strong_password()

    persona = {
        "full_name": f"{first} {last}",
        "first_name": first,
        "last_name": last,
        "gender": gender.capitalize(),
        "date_of_birth": str(dob),
        "address": address,
        "city": city,
        "country": country,
        "zip_code": zip_code,
        "phone": phone,
        "email": email,
        "username": chosen_username,
        "username_variants": usernames,
        "occupation": occupation,
        "company": company,
        "password": password,
        "fingerprint_hash": hashlib.sha256(f"{first}{last}{str(dob)}".encode()).hexdigest()[:16],
    }

    return persona


def display_persona(persona: Dict) -> None:
    """
    Pretty-print a generated persona.

    Args:
        persona: Persona dictionary from generate_persona()
    """
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*55}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}          GENERATED PERSONA{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*55}{Colors.RESET}\n")

    fields = [
        ("Full Name", "full_name"),
        ("Gender", "gender"),
        ("Date of Birth", "date_of_birth"),
        ("Address", "address"),
        ("City", "city"),
        ("Country", "country"),
        ("ZIP", "zip_code"),
        ("Phone", "phone"),
        ("Email", "email"),
        ("Username", "username"),
        ("Occupation", "occupation"),
        ("Company", "company"),
        ("Password", "password"),
        ("ID Hash", "fingerprint_hash"),
    ]

    for label, key in fields:
        value = persona.get(key, "N/A")
        print(f"  {Colors.CYAN}{label:<16}{Colors.RESET}: {Colors.WHITE}{value}{Colors.RESET}")

    print(f"\n  {Colors.YELLOW}Username variants:{Colors.RESET}")
    for uname in persona.get("username_variants", [])[:5]:
        print(f"    {Colors.DIM}{uname}{Colors.RESET}")

    print(f"\n  {Colors.RED}[!] FOR OPSEC PURPOSES ONLY — Do not use for fraud or deception.{Colors.RESET}\n")


def run() -> None:
    """Main entry point for the persona creation module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}          PERSONA GENERATOR{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")

    print(f"\n  Gender: [{Colors.CYAN}1{Colors.RESET}] Male  [{Colors.CYAN}2{Colors.RESET}] Female  [{Colors.CYAN}3{Colors.RESET}] Random")
    choice = input(f"\n  {Colors.BOLD}Choice [3]:{Colors.RESET} ").strip() or "3"

    gender_map = {"1": "male", "2": "female", "3": "random"}
    gender = gender_map.get(choice, "random")

    print(f"\n  {Colors.YELLOW}Generating persona...{Colors.RESET}")
    persona = generate_persona(gender=gender)
    display_persona(persona)
    log_info(f"Generated persona: {persona['full_name']}")

    again = input(f"  Generate another? [{Colors.CYAN}y{Colors.RESET}/n]: ").strip().lower()
    if again == "y":
        run()
