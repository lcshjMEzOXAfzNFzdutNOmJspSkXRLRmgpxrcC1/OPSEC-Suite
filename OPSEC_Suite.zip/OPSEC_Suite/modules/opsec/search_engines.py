"""
Privacy-focused search engines guide module.
Compares search engines and provides configuration tips.
"""

from utils.colors import Colors
from utils.logger import log_info


SEARCH_ENGINES = [
    {
        "name": "DuckDuckGo",
        "url": "https://duckduckgo.com",
        "privacy": 4,
        "features": ["No tracking", "Tor onion service", "Bang shortcuts", "Anonymous ad model"],
        "cons": ["US-based", "Microsoft Bing result filtering agreement"],
        "recommended": True,
    },
    {
        "name": "Startpage",
        "url": "https://www.startpage.com",
        "privacy": 5,
        "features": ["Google results without tracking", "Anonymous view", "EU-based", "No IP logging"],
        "cons": ["Dependent on Google", "Slow at times"],
        "recommended": True,
    },
    {
        "name": "Brave Search",
        "url": "https://search.brave.com",
        "privacy": 4,
        "features": ["Independent index", "No Google/Bing dependency", "Goggles feature", "US-based but privacy-focused"],
        "cons": ["Newer, smaller index", "US-based"],
        "recommended": True,
    },
    {
        "name": "SearXNG",
        "url": "https://searx.be",
        "privacy": 5,
        "features": ["Open source", "Self-hostable", "Aggregates multiple engines", "No tracking"],
        "cons": ["Requires self-hosting for best privacy", "Instance quality varies"],
        "recommended": True,
    },
    {
        "name": "Whoogle",
        "url": "https://benbusby.com/whoogle-search/",
        "privacy": 5,
        "features": ["Google results with no tracking", "Self-hostable", "No ads", "Open source"],
        "cons": ["Requires self-hosting", "Google CAPTCHA issues"],
        "recommended": True,
    },
    {
        "name": "Google",
        "url": "https://google.com",
        "privacy": 1,
        "features": ["Best search quality", "Wide coverage"],
        "cons": ["Massive surveillance", "Data sold to advertisers", "Linked to Google account", "IP logged"],
        "recommended": False,
    },
    {
        "name": "Bing",
        "url": "https://bing.com",
        "privacy": 1,
        "features": ["Microsoft ecosystem integration"],
        "cons": ["Microsoft tracking", "Personalized results", "Data shared with advertisers"],
        "recommended": False,
    },
]

SEARX_INSTANCES = [
    "https://searx.be",
    "https://search.disroot.org",
    "https://searx.tiekoetter.com",
    "https://searx.bar",
    "https://searx.prvcy.eu",
]


def display_search_engines() -> None:
    """Display a comparison of privacy-focused search engines."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*58}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         PRIVACY SEARCH ENGINE COMPARISON{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*58}{Colors.RESET}\n")

    for engine in SEARCH_ENGINES:
        rec = f"{Colors.GREEN}✓ Recommended{Colors.RESET}" if engine["recommended"] else f"{Colors.RED}✗ Avoid{Colors.RESET}"
        stars = Colors.GREEN + ("★" * engine["privacy"]) + ("☆" * (5 - engine["privacy"])) + Colors.RESET
        print(f"  {Colors.BOLD}{Colors.CYAN}{engine['name']}{Colors.RESET} — {engine['url']}")
        print(f"  Privacy: {stars}  {rec}")
        print(f"  {Colors.GREEN}+{Colors.RESET} " + (f"\n  {Colors.GREEN}+{Colors.RESET} ".join(engine["features"])))
        if engine["cons"]:
            print(f"  {Colors.RED}-{Colors.RESET} " + (f"\n  {Colors.RED}-{Colors.RESET} ".join(engine["cons"])))
        print()

    log_info("Displayed search engine comparison")


def display_searx_instances() -> None:
    """Display a list of public SearXNG instances."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Public SearXNG Instances ==={Colors.RESET}\n")
    print(f"  {Colors.YELLOW}For best privacy, self-host your own instance.{Colors.RESET}")
    print(f"  {Colors.DIM}Full list: https://searx.space{Colors.RESET}\n")

    for inst in SEARX_INSTANCES:
        print(f"  {Colors.CYAN}→{Colors.RESET} {inst}")

    print(f"\n  {Colors.BOLD}Self-host with Docker:{Colors.RESET}")
    print(f"  {Colors.DIM}docker run -d -p 8888:8080 searxng/searxng{Colors.RESET}")


def run() -> None:
    """Main entry point for the search engines module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}       SEARCH ENGINE PRIVACY GUIDE{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Compare search engines")
    print(f"  {Colors.CYAN}2.{Colors.RESET} SearXNG public instances")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        display_search_engines()
    elif choice == "2":
        display_searx_instances()
