"""
Firefox privacy hardening configuration generator.
Generates a user.js file with security and privacy settings.
"""

import os
from pathlib import Path
from typing import Dict, List, Tuple

from utils.colors import Colors
from utils.logger import log_info, log_warning


FIREFOX_PRIVACY_SETTINGS: List[Tuple[str, str, str]] = [
    # [pref_name, value, description]
    ("privacy.firstparty.isolate", "true", "Enable First Party Isolation"),
    ("privacy.resistFingerprinting", "true", "Resist browser fingerprinting"),
    ("privacy.trackingprotection.enabled", "true", "Enable Enhanced Tracking Protection"),
    ("privacy.trackingprotection.socialtracking.enabled", "true", "Block social media trackers"),
    ("geo.enabled", "false", "Disable geolocation"),
    ("media.navigator.enabled", "false", "Disable WebRTC device enumeration"),
    ("media.peerconnection.enabled", "false", "Disable WebRTC (prevents IP leak)"),
    ("media.peerconnection.ice.default_address_only", "true", "WebRTC IP leak protection"),
    ("network.dns.disablePrefetch", "true", "Disable DNS prefetch"),
    ("network.http.sendRefererHeader", "0", "Do not send HTTP referrer"),
    ("network.http.referer.spoofSource", "true", "Spoof referrer header"),
    ("browser.send_pings", "false", "Disable hyperlink auditing"),
    ("browser.urlbar.speculativeConnect.enabled", "false", "Disable speculative connections"),
    ("network.prefetch-next", "false", "Disable link prefetching"),
    ("network.http.speculative-parallel-limit", "0", "Disable speculative connections"),
    ("browser.safebrowsing.malware.enabled", "false", "Disable Google Safe Browsing"),
    ("browser.safebrowsing.phishing.enabled", "false", "Disable Google phishing check"),
    ("browser.safebrowsing.downloads.enabled", "false", "Disable Safe Browsing downloads check"),
    ("browser.safebrowsing.downloads.remote.enabled", "false", "Disable remote Safe Browsing"),
    ("dom.battery.enabled", "false", "Disable battery status API"),
    ("dom.event.clipboardevents.enabled", "false", "Disable clipboard events"),
    ("dom.vibrator.enabled", "false", "Disable vibration API"),
    ("dom.vr.enabled", "false", "Disable VR API"),
    ("camera.control.face_detection.enabled", "false", "Disable camera face detection"),
    ("device.sensors.enabled", "false", "Disable device sensor APIs"),
    ("extensions.pocket.enabled", "false", "Disable Pocket integration"),
    ("toolkit.telemetry.enabled", "false", "Disable telemetry"),
    ("datareporting.healthreport.uploadEnabled", "false", "Disable health report upload"),
    ("datareporting.policy.dataSubmissionEnabled", "false", "Disable data submission"),
    ("browser.tabs.crashReporting.sendReport", "false", "Disable crash reporting"),
    ("network.http.sendSecureXSiteReferrer", "false", "Disable cross-site referrer"),
    ("network.IDN_show_punycode", "true", "Show punycode (prevent homograph attacks)"),
    ("javascript.options.asmjs", "false", "Disable asm.js"),
    ("gfx.font_rendering.opentype_svg.enabled", "false", "Disable SVG in OpenType (fingerprint)"),
    ("webgl.disabled", "true", "Disable WebGL (fingerprinting surface)"),
    ("dom.webaudio.enabled", "false", "Disable Web Audio API (fingerprinting)"),
    ("browser.formfill.enable", "false", "Disable form fill"),
    ("signon.rememberSignons", "false", "Disable built-in password manager"),
    ("browser.autofill.enabled", "false", "Disable browser autofill"),
    ("network.cookie.cookieBehavior", "1", "Block third-party cookies"),
    ("network.cookie.lifetimePolicy", "2", "Accept cookies for session only"),
    ("privacy.sanitize.sanitizeOnShutdown", "true", "Clear data on shutdown"),
    ("privacy.clearOnShutdown.cookies", "true", "Clear cookies on shutdown"),
    ("privacy.clearOnShutdown.cache", "true", "Clear cache on shutdown"),
    ("privacy.clearOnShutdown.history", "false", "Keep history on shutdown (set true for paranoid)"),
    ("security.OCSP.require", "true", "Require OCSP stapling (revocation check)"),
    ("security.tls.version.min", "3", "Minimum TLS 1.2"),
    ("security.ssl3.rsa_des_ede3_sha", "false", "Disable 3DES (weak cipher)"),
    ("network.http.http3.enabled", "false", "Disable QUIC/HTTP3 for privacy"),
]


def generate_user_js(output_path: str = "user.js", profile: str = "balanced") -> str:
    """
    Generate a Firefox user.js privacy hardening file.

    Args:
        output_path: Where to write the user.js file
        profile: 'balanced' keeps some features; 'strict' disables more; 'paranoid' for maximum privacy

    Returns:
        Full content of the generated user.js file
    """
    strict_only = {
        "media.peerconnection.enabled",
        "dom.webaudio.enabled",
        "webgl.disabled",
        "network.http.http3.enabled",
        "privacy.clearOnShutdown.history",
    }

    paranoid_only = {
        "javascript.options.asmjs",
        "gfx.font_rendering.opentype_svg.enabled",
        "dom.event.clipboardevents.enabled",
        "network.http.sendRefererHeader",
    }

    lines = [
        "// Firefox Privacy Hardening — Generated by OPSEC Suite",
        f"// Profile: {profile.upper()}",
        "// Apply by placing this file in your Firefox profile directory.",
        "// Find profile dir: about:support → Profile Directory",
        "",
    ]

    for pref, value, desc in FIREFOX_PRIVACY_SETTINGS:
        if profile == "balanced" and pref in strict_only:
            continue
        if profile in ("balanced", "strict") and pref in paranoid_only:
            continue

        if value == "true":
            line = f'user_pref("{pref}", true); // {desc}'
        elif value == "false":
            line = f'user_pref("{pref}", false); // {desc}'
        elif value.isdigit():
            line = f'user_pref("{pref}", {value}); // {desc}'
        else:
            line = f'user_pref("{pref}", "{value}"); // {desc}'

        lines.append(line)

    content = "\n".join(lines) + "\n"

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)
        log_info(f"Generated user.js at {output_path} ({profile} profile)")
    except OSError as e:
        log_warning(f"Could not write user.js: {e}")

    return content


def find_firefox_profiles() -> List[str]:
    """
    Locate Firefox profile directories on the current system.

    Returns:
        List of profile directory paths found
    """
    import platform
    system = platform.system()
    paths = []

    if system == "Windows":
        base = Path(os.environ.get("APPDATA", "")) / "Mozilla" / "Firefox" / "Profiles"
    elif system == "Darwin":
        base = Path.home() / "Library" / "Application Support" / "Firefox" / "Profiles"
    else:
        base = Path.home() / ".mozilla" / "firefox"

    if base.exists():
        paths = [str(p) for p in base.iterdir() if p.is_dir()]

    return paths


def run() -> None:
    """Main entry point for the privacy browser configuration module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*55}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}     FIREFOX PRIVACY CONFIGURATION GENERATOR{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*55}{Colors.RESET}")

    print(f"\n  Choose hardening profile:")
    print(f"  {Colors.CYAN}1.{Colors.RESET} Balanced  — privacy + usability (recommended)")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Strict    — more privacy, some sites may break")
    print(f"  {Colors.CYAN}3.{Colors.RESET} Paranoid  — maximum privacy, many sites will break")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice [1]:{Colors.RESET} ").strip() or "1"
    profiles = {"1": "balanced", "2": "strict", "3": "paranoid"}
    profile = profiles.get(choice, "balanced")

    if choice == "0":
        return

    output = input(f"\n  Save user.js to [user.js]: ").strip() or "user.js"

    print(f"\n  {Colors.YELLOW}Generating {profile} Firefox profile...{Colors.RESET}")
    content = generate_user_js(output_path=output, profile=profile)

    print(f"\n  {Colors.GREEN}✓ Generated {output} ({len(content.splitlines())} settings){Colors.RESET}")
    print(f"\n  {Colors.BOLD}How to apply:{Colors.RESET}")
    print(f"  1. Open Firefox, go to {Colors.CYAN}about:support{Colors.RESET}")
    print(f"  2. Click {Colors.CYAN}Open Profile Folder{Colors.RESET}")
    print(f"  3. Copy {Colors.CYAN}{output}{Colors.RESET} into that folder")
    print(f"  4. Restart Firefox\n")

    profiles_found = find_firefox_profiles()
    if profiles_found:
        print(f"  {Colors.YELLOW}Detected Firefox profiles on this system:{Colors.RESET}")
        for p in profiles_found:
            print(f"    {Colors.DIM}{p}{Colors.RESET}")
