"""
OPSEC education module.
Explains what OPSEC is and how it applies to digital security.
"""

from utils.colors import Colors
from utils.logger import log_info


def display_what_is_opsec() -> None:
    """Display an educational overview of OPSEC principles."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}        WHAT IS OPSEC? (Operational Security){Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}\n")

    sections = [
        (
            "Definition",
            Colors.BLUE,
            [
                "OPSEC is a process that identifies critical information to determine",
                "if friendly actions can be observed by adversaries, determines if",
                "information obtained by adversaries could be interpreted to be useful",
                "to them, and then executes selected measures that eliminate or reduce",
                "adversary exploitation of friendly critical information.",
                "",
                "In digital context: protecting your sensitive data, habits, and",
                "activities from being observed, correlated, and used against you.",
            ],
        ),
        (
            "The 5 Steps of OPSEC",
            Colors.CYAN,
            [
                "1. Identify Critical Information",
                "   What data, if exposed, would harm you?",
                "   Examples: real name, location, financial details, associations",
                "",
                "2. Analyze Threats",
                "   Who are your adversaries? Corporations? Hackers? Governments?",
                "   What are their capabilities and intent?",
                "",
                "3. Analyze Vulnerabilities",
                "   Where do your information gaps exist?",
                "   Social media? Metadata? Network traffic? Devices?",
                "",
                "4. Assess Risk",
                "   Match threats to vulnerabilities.",
                "   What is the likelihood of exploitation?",
                "",
                "5. Apply Countermeasures",
                "   VPNs, encryption, pseudonyms, air-gapping, behavior change.",
            ],
        ),
        (
            "Common OPSEC Mistakes",
            Colors.RED,
            [
                "• Using real name for sensitive accounts",
                "• Reusing usernames or passwords across platforms",
                "• Logging into personal accounts over Tor/VPN (breaks anonymity)",
                "• Posting location data on social media",
                "• Using consistent writing style across pseudonymous accounts",
                "• Metadata in documents/photos revealing identity",
                "• Running operational tasks on personal devices",
                "• Talking about sensitive activities to others",
                "• Paying with traceable cards for sensitive services",
                "• Using phone number linked to real identity for 2FA",
            ],
        ),
        (
            "The Principle of Compartmentalization",
            Colors.YELLOW,
            [
                "Keep different parts of your life in separate 'compartments':",
                "• Separate devices for separate identities",
                "• Separate email accounts for different purposes",
                "• Never mix work/personal accounts on the same session",
                "• Different browsers for different identities",
                "• Different VPN exit nodes for different activities",
            ],
        ),
        (
            "Digital Exhaust",
            Colors.PURPLE,
            [
                "Every digital action leaves a trail. Examples:",
                "• IP addresses logged by every website you visit",
                "• Browser fingerprint (screen size, fonts, plugins, timezone)",
                "• Typing speed and patterns (keystroke dynamics)",
                "• Login timestamps and location patterns",
                "• Email metadata (when sent, from what IP)",
                "• Cell tower triangulation from your phone",
                "• Smart TV and IoT device data collection",
                "• Surveillance cameras with facial recognition",
            ],
        ),
    ]

    for title, color, lines in sections:
        print(f"{color}{Colors.BOLD}[ {title} ]{Colors.RESET}")
        for line in lines:
            if line:
                print(f"  {line}")
            else:
                print()
        print()

    log_info("Displayed OPSEC education content")


def display_threat_model_worksheet() -> None:
    """Interactive threat model builder."""
    print(f"\n{Colors.BOLD}{Colors.BLUE}=== Personal Threat Model Worksheet ==={Colors.RESET}\n")

    print(f"  {Colors.YELLOW}Answer these questions to define your threat model:{Colors.RESET}\n")

    questions = [
        ("What do you want to protect?", "data, files, communications, identity, location"),
        ("From whom?", "corporations, hackers, government, employers, stalkers, general public"),
        ("How likely is it to be threatened?", "rate 1-5: exposure level"),
        ("How bad would the consequences be?", "rate 1-5: impact level"),
        ("How much effort can you sustain?", "daily inconvenience tolerance"),
    ]

    answers = {}
    for q, hint in questions:
        print(f"  {Colors.CYAN}?{Colors.RESET} {Colors.BOLD}{q}{Colors.RESET}")
        print(f"    {Colors.DIM}(e.g. {hint}){Colors.RESET}")
        answer = input(f"    Your answer: ").strip()
        answers[q] = answer
        print()

    print(f"\n{Colors.BOLD}{Colors.GREEN}=== Your Threat Model Summary ==={Colors.RESET}")
    for q, a in answers.items():
        print(f"  {Colors.CYAN}Q:{Colors.RESET} {q}")
        print(f"  {Colors.GREEN}A:{Colors.RESET} {a}\n")

    print(f"  {Colors.YELLOW}Recommended resources:{Colors.RESET}")
    print(f"  • EFF Surveillance Self-Defense: https://ssd.eff.org")
    print(f"  • Privacy Guides: https://privacyguides.org")
    print(f"  • Security in a Box: https://securityinabox.org")


def run() -> None:
    """Main entry point for the OPSEC education module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         OPSEC EDUCATION CENTER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} What is OPSEC?")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Personal threat model worksheet")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()
    if choice == "1":
        display_what_is_opsec()
    elif choice == "2":
        display_threat_model_worksheet()
