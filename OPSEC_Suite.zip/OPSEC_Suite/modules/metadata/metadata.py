"""
Metadata analysis overview module.
Explains different types of file metadata and their privacy risks.
"""

from utils.colors import Colors
from utils.logger import log_info


METADATA_TYPES = {
    "Image Files (JPEG, PNG, TIFF)": {
        "data": [
            "GPS coordinates (exact location where photo was taken)",
            "Device make and model (iPhone 15 Pro, Samsung Galaxy S24)",
            "Lens and camera settings (aperture, shutter speed, ISO)",
            "Date and time photo was taken",
            "Software used to edit the image",
            "Owner name if configured in camera",
            "Thumbnail of original (even if image was cropped)",
        ],
        "risk": "HIGH",
        "tools": ["ExifTool", "GIMP (remove on export)", "mat2", "This tool"],
    },
    "PDF Documents": {
        "data": [
            "Author name (from OS user account)",
            "Company/organization name",
            "Creation and modification dates",
            "Software used (Microsoft Word 365, LibreOffice)",
            "GPS location if created on mobile",
            "Revision history",
            "Hidden text and comments",
        ],
        "risk": "HIGH",
        "tools": ["mat2", "pdf-redact-tools", "ExifTool", "LibreOffice (sanitize on save)"],
    },
    "Microsoft Office Documents": {
        "data": [
            "Author name and initials",
            "Company name",
            "Last saved by (username)",
            "Revision count and total editing time",
            "Document template path (may reveal internal paths)",
            "Printer name last used",
            "Tracked changes and comments",
        ],
        "risk": "HIGH",
        "tools": ["mat2", "Document Inspector (File → Info → Inspect Document)", "LibreOffice"],
    },
    "Audio/Video Files": {
        "data": [
            "Recording device information",
            "GPS location",
            "Date and time",
            "Software encoder used",
            "Artist/album metadata",
        ],
        "risk": "MEDIUM",
        "tools": ["FFmpeg", "mat2", "ExifTool"],
    },
    "Network Traffic": {
        "data": [
            "IP addresses (source and destination)",
            "Timestamps of connections",
            "Domain names queried",
            "Packet sizes (traffic analysis)",
            "Protocol fingerprinting",
        ],
        "risk": "CRITICAL",
        "tools": ["VPN", "Tor", "DNS over HTTPS", "I2P"],
    },
}


def display_metadata_overview() -> None:
    """Display an overview of file metadata types and privacy risks."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}         METADATA PRIVACY OVERVIEW{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*60}{Colors.RESET}\n")

    risk_colors = {"CRITICAL": Colors.RED, "HIGH": Colors.YELLOW, "MEDIUM": Colors.CYAN, "LOW": Colors.GREEN}

    for file_type, info in METADATA_TYPES.items():
        risk = info["risk"]
        color = risk_colors.get(risk, Colors.WHITE)
        print(f"{Colors.BOLD}{Colors.BLUE}[ {file_type} ]{Colors.RESET}  Risk: {color}{risk}{Colors.RESET}")
        print(f"  {Colors.YELLOW}Data exposed:{Colors.RESET}")
        for item in info["data"]:
            print(f"    {Colors.RED}•{Colors.RESET} {item}")
        print(f"  {Colors.GREEN}Removal tools:{Colors.RESET} {', '.join(info['tools'])}")
        print()

    print(f"{Colors.BOLD}Key rule:{Colors.RESET} {Colors.YELLOW}Strip all metadata before sharing any file publicly.{Colors.RESET}")
    log_info("Displayed metadata overview")


def run() -> None:
    """Main entry point for the metadata module."""
    display_metadata_overview()
