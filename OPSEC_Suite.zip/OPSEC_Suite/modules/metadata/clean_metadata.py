"""
Batch metadata cleaning module.
Removes metadata from multiple files at once.
"""

import os
from pathlib import Path
from typing import List, Optional, Tuple

from utils.colors import Colors
from utils.logger import log_info, log_error, log_warning

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False


def clean_image_metadata(file_path: str, output_dir: Optional[str] = None) -> bool:
    """
    Strip metadata from a single image file.

    Args:
        file_path: Path to the image
        output_dir: Directory to write cleaned file. Defaults to same directory.

    Returns:
        True on success, False on failure
    """
    try:
        from PIL import Image

        p = Path(file_path)
        if output_dir:
            out_path = Path(output_dir) / (p.stem + "_clean" + p.suffix)
        else:
            out_path = p.parent / (p.stem + "_clean" + p.suffix)

        img = Image.open(file_path)
        data = list(img.getdata())
        clean = Image.new(img.mode, img.size)
        clean.putdata(data)
        clean.save(str(out_path))
        log_info(f"Cleaned: {file_path} -> {out_path}")
        return True
    except Exception as e:
        log_error(f"Error cleaning {file_path}: {e}")
        return False


from typing import Optional


def clean_pdf_metadata(file_path: str, output_path: Optional[str] = None) -> bool:
    """
    Attempt to clean metadata from a PDF using available tools.

    Args:
        file_path: Path to the PDF
        output_path: Where to save the cleaned PDF

    Returns:
        True if mat2 is available and successful, False otherwise
    """
    try:
        import subprocess
        cmd = ["mat2", "--inplace", file_path]
        if output_path:
            cmd = ["mat2", file_path, "--output", output_path]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            log_info(f"mat2 cleaned: {file_path}")
            return True
        else:
            log_warning(f"mat2 failed: {result.stderr.strip()}")
            return False
    except FileNotFoundError:
        log_warning("mat2 not installed. Install with: pip install mat2")
        return False
    except Exception as e:
        log_error(f"PDF cleaning error: {e}")
        return False


def scan_directory_for_metadata(directory: str) -> List[Tuple[str, str]]:
    """
    Scan a directory and return files that may contain metadata.

    Args:
        directory: Path to scan

    Returns:
        List of (file_path, file_type) tuples
    """
    image_exts = {".jpg", ".jpeg", ".png", ".tiff", ".tif", ".bmp", ".gif", ".webp"}
    doc_exts = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt"}
    media_exts = {".mp3", ".mp4", ".avi", ".mov", ".flac", ".wav"}

    found = []
    base = Path(directory)
    if not base.exists():
        return found

    for f in base.rglob("*"):
        if f.is_file():
            ext = f.suffix.lower()
            if ext in image_exts:
                found.append((str(f), "image"))
            elif ext in doc_exts:
                found.append((str(f), "document"))
            elif ext in media_exts:
                found.append((str(f), "media"))

    return found


def batch_clean_images(directory: str, output_dir: Optional[str] = None) -> Tuple[int, int]:
    """
    Clean metadata from all images in a directory.

    Args:
        directory: Source directory
        output_dir: Output directory for cleaned files

    Returns:
        Tuple of (success_count, total_count)
    """
    files = [(f, t) for f, t in scan_directory_for_metadata(directory) if t == "image"]
    success = 0
    total = len(files)

    if total == 0:
        print(f"  {Colors.YELLOW}No image files found in {directory}{Colors.RESET}")
        return 0, 0

    if output_dir:
        Path(output_dir).mkdir(parents=True, exist_ok=True)

    iterator = tqdm(files, desc="Cleaning metadata") if TQDM_AVAILABLE else files

    for file_path, _ in iterator:
        if clean_image_metadata(file_path, output_dir):
            success += 1

    return success, total


def run() -> None:
    """Main entry point for the batch metadata cleaning module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}       BATCH METADATA CLEANER{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} Scan directory for metadata-bearing files")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Batch clean images in directory")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    directory = input(f"\n  Directory path: ").strip()
    if not directory:
        print(f"  {Colors.RED}No directory specified.{Colors.RESET}")
        return

    if not Path(directory).exists():
        print(f"  {Colors.RED}Directory not found: {directory}{Colors.RESET}")
        return

    if choice == "1":
        print(f"\n  {Colors.YELLOW}Scanning {directory}...{Colors.RESET}")
        files = scan_directory_for_metadata(directory)
        print(f"\n  Found {Colors.BOLD}{len(files)}{Colors.RESET} files with potential metadata:\n")
        for fpath, ftype in files[:50]:
            color = Colors.YELLOW if ftype == "image" else Colors.CYAN
            print(f"  {color}{ftype:<10}{Colors.RESET} {fpath}")
        if len(files) > 50:
            print(f"  ... and {len(files) - 50} more")
        log_info(f"Scanned {directory}: {len(files)} files found")

    elif choice == "2":
        out_dir = input(f"  Output directory (leave blank for _clean suffix): ").strip() or None
        print(f"\n  {Colors.YELLOW}Cleaning images...{Colors.RESET}")
        success, total = batch_clean_images(directory, out_dir)
        print(f"\n  {Colors.GREEN}✓ Cleaned {success}/{total} images{Colors.RESET}")
        log_info(f"Batch cleaned {success}/{total} images in {directory}")
