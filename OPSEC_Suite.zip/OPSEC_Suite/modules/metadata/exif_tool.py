"""
EXIF data extraction and removal tool.
Uses Pillow and exifread to read/strip image metadata.
"""

import os
from pathlib import Path
from typing import Any, Dict, Optional

from utils.colors import Colors
from utils.logger import log_info, log_error, log_warning


def extract_exif_pillow(image_path: str) -> Dict[str, Any]:
    """
    Extract EXIF metadata from an image using Pillow.

    Args:
        image_path: Path to the image file

    Returns:
        Dictionary of EXIF tag: value pairs
    """
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS, GPSTAGS

        result = {}
        img = Image.open(image_path)
        exif_data = img._getexif()

        if exif_data is None:
            return {"info": "No EXIF data found"}

        for tag_id, value in exif_data.items():
            tag = TAGS.get(tag_id, str(tag_id))
            if tag == "GPSInfo" and isinstance(value, dict):
                gps = {}
                for gps_tag_id, gps_val in value.items():
                    gps_tag = GPSTAGS.get(gps_tag_id, str(gps_tag_id))
                    gps[gps_tag] = str(gps_val)
                result["GPS"] = gps
            else:
                result[tag] = str(value) if not isinstance(value, bytes) else value.hex()

        return result
    except ImportError:
        return {"error": "Pillow not installed. Run: pip install pillow"}
    except Exception as e:
        return {"error": str(e)}


def extract_exif_exifread(image_path: str) -> Dict[str, str]:
    """
    Extract EXIF data using the exifread library.

    Args:
        image_path: Path to the image file

    Returns:
        Dictionary of tag names to value strings
    """
    try:
        import exifread
        with open(image_path, "rb") as f:
            tags = exifread.process_file(f, details=False)
        return {str(k): str(v) for k, v in tags.items()}
    except ImportError:
        return {"error": "exifread not installed. Run: pip install exifread"}
    except Exception as e:
        return {"error": str(e)}


def remove_exif(image_path: str, output_path: Optional[str] = None) -> str:
    """
    Strip all EXIF metadata from an image and save the clean version.

    Args:
        image_path: Path to the source image
        output_path: Where to save the cleaned image. If None, adds '_clean' suffix.

    Returns:
        Path to the cleaned image file
    """
    try:
        from PIL import Image
        import io

        if output_path is None:
            p = Path(image_path)
            output_path = str(p.parent / (p.stem + "_clean" + p.suffix))

        img = Image.open(image_path)
        data = list(img.getdata())
        clean_img = Image.new(img.mode, img.size)
        clean_img.putdata(data)
        clean_img.save(output_path, format=img.format or "JPEG")

        log_info(f"Removed EXIF from {image_path} -> {output_path}")
        return output_path
    except ImportError:
        log_error("Pillow not installed")
        return ""
    except Exception as e:
        log_error(f"Error removing EXIF: {e}")
        return ""


def display_exif(data: Dict[str, Any]) -> None:
    """
    Pretty-print extracted EXIF data, highlighting GPS info.

    Args:
        data: EXIF dictionary to display
    """
    if "error" in data:
        print(f"\n  {Colors.RED}Error: {data['error']}{Colors.RESET}")
        return

    if "info" in data:
        print(f"\n  {Colors.YELLOW}{data['info']}{Colors.RESET}")
        return

    gps_keys = {"GPS", "GPSLatitude", "GPSLongitude", "GPSAltitude", "GPS GPSLatitude", "GPS GPSLongitude"}
    print(f"\n  {Colors.BOLD}{'Tag':<35} {'Value'}{Colors.RESET}")
    print(f"  {'-'*60}")

    for tag, value in sorted(data.items()):
        is_gps = any(k.lower() in tag.lower() for k in ["gps", "location"])
        color = Colors.RED if is_gps else Colors.WHITE
        val_str = str(value)
        if len(val_str) > 60:
            val_str = val_str[:57] + "..."
        print(f"  {Colors.CYAN}{tag:<35}{Colors.RESET} {color}{val_str}{Colors.RESET}")


def run() -> None:
    """Main entry point for the EXIF tool module."""
    print(f"\n{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}          EXIF METADATA TOOL{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.PURPLE}{'='*50}{Colors.RESET}")
    print(f"\n  {Colors.CYAN}1.{Colors.RESET} View EXIF data from image")
    print(f"  {Colors.CYAN}2.{Colors.RESET} Remove EXIF data from image")
    print(f"  {Colors.CYAN}0.{Colors.RESET} Back\n")

    choice = input(f"  {Colors.BOLD}Choice:{Colors.RESET} ").strip()

    if choice == "0":
        return

    path = input(f"\n  Image path: ").strip()
    if not path:
        print(f"  {Colors.RED}No path provided.{Colors.RESET}")
        return

    if not Path(path).exists():
        print(f"  {Colors.RED}File not found: {path}{Colors.RESET}")
        return

    if choice == "1":
        print(f"\n  {Colors.YELLOW}Extracting EXIF data...{Colors.RESET}")
        data = extract_exif_pillow(path)
        if "error" in data:
            data = extract_exif_exifread(path)
        display_exif(data)
        log_info(f"Extracted EXIF from {path}: {len(data)} tags found")

    elif choice == "2":
        output = input(f"  Save clean image to (leave blank for auto): ").strip() or None
        result = remove_exif(path, output)
        if result:
            print(f"\n  {Colors.GREEN}✓ Clean image saved to: {result}{Colors.RESET}")
        else:
            print(f"\n  {Colors.RED}Failed to remove EXIF data.{Colors.RESET}")
