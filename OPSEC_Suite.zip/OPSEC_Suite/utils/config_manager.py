"""
Configuration manager for the OPSEC Suite.
Handles loading, saving, and dot-notation access to JSON config files.
"""

import json
from pathlib import Path
from typing import Any, Optional


class ConfigManager:
    """
    Manage a JSON configuration file with dot-notation key access.

    Supports nested keys via dot notation (e.g. "api_keys.hibp").
    """

    DEFAULT_CONFIG = {
        "version": "1.0.0",
        "theme": "dark",
        "log_level": "INFO",
        "save_reports": True,
        "api_keys": {
            "ipinfo": "",
            "hibp": "",
            "virustotal": "",
        },
    }

    def __init__(self, config_path: str = "config.json") -> None:
        """
        Initialize the ConfigManager.

        Args:
            config_path: Path to the JSON configuration file
        """
        self.config_path = Path(config_path)
        self._data: dict = {}
        self.load()

    def load(self) -> dict:
        """
        Load configuration from the JSON file.
        Creates a default config if the file does not exist.

        Returns:
            The loaded configuration dictionary
        """
        if not self.config_path.exists():
            self._data = self.DEFAULT_CONFIG.copy()
            self.save()
        else:
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    self._data = json.load(f)
            except (json.JSONDecodeError, OSError) as e:
                print(f"[WARNING] Could not load config: {e}. Using defaults.")
                self._data = self.DEFAULT_CONFIG.copy()
        return self._data

    def save(self) -> None:
        """Save the current configuration to the JSON file."""
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=4)
        except OSError as e:
            print(f"[ERROR] Could not save config: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        """
        Retrieve a value using dot-notation key.

        Args:
            key: Dot-separated key path (e.g. "api_keys.hibp")
            default: Value to return if the key is not found

        Returns:
            The configuration value or the default
        """
        parts = key.split(".")
        current = self._data
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return default
        return current

    def set(self, key: str, value: Any) -> None:
        """
        Set a value using dot-notation key. Creates nested dicts as needed.

        Args:
            key: Dot-separated key path (e.g. "api_keys.hibp")
            value: Value to store
        """
        parts = key.split(".")
        current = self._data
        for part in parts[:-1]:
            if part not in current or not isinstance(current[part], dict):
                current[part] = {}
            current = current[part]
        current[parts[-1]] = value
        self.save()

    def create_default(self) -> None:
        """Reset configuration to defaults and save."""
        self._data = self.DEFAULT_CONFIG.copy()
        self.save()

    def all(self) -> dict:
        """Return the full configuration dictionary."""
        return self._data
