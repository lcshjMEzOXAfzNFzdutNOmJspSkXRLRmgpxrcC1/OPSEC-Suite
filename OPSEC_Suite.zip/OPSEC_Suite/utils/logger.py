"""
Logging utilities for the OPSEC Suite.
Supports rotating file logs and colored console output.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional

from .colors import Colors, strip_colors

_logger: Optional[logging.Logger] = None


def setup_logger(name: str = "opsec", log_file: str = "opsec.log") -> logging.Logger:
    """
    Configure and return a logger with rotating file handler and console handler.

    Args:
        name: Logger name (used to namespace log records)
        log_file: Path to the log file (rotates at 10MB, keeps 5 backups)

    Returns:
        Configured Logger instance
    """
    global _logger

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    if logger.handlers:
        _logger = logger
        return logger

    log_path = Path(log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    file_formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = RotatingFileHandler(
        filename=log_file,
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(file_formatter)

    class StripColorsFilter(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:
            record.msg = strip_colors(str(record.msg))
            return True

    file_handler.addFilter(StripColorsFilter())

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)

    class ColoredFormatter(logging.Formatter):
        LEVEL_COLORS = {
            "DEBUG": Colors.DIM,
            "INFO": Colors.CYAN,
            "WARNING": Colors.YELLOW,
            "ERROR": Colors.RED,
            "CRITICAL": Colors.BOLD + Colors.RED,
        }

        def format(self, record: logging.LogRecord) -> str:
            color = self.LEVEL_COLORS.get(record.levelname, "")
            reset = Colors.RESET
            record.levelname = f"{color}{record.levelname}{reset}"
            return super().format(record)

    console_formatter = ColoredFormatter(
        fmt="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )
    console_handler.setFormatter(console_formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    _logger = logger
    return logger


def _get_logger() -> logging.Logger:
    """Return the global logger, initializing it if needed."""
    global _logger
    if _logger is None:
        _logger = setup_logger()
    return _logger


def log_info(msg: str) -> None:
    """
    Log an informational message.

    Args:
        msg: Message to log
    """
    _get_logger().info(msg)


def log_error(msg: str) -> None:
    """
    Log an error message.

    Args:
        msg: Message to log
    """
    _get_logger().error(msg)


def log_warning(msg: str) -> None:
    """
    Log a warning message.

    Args:
        msg: Message to log
    """
    _get_logger().warning(msg)
