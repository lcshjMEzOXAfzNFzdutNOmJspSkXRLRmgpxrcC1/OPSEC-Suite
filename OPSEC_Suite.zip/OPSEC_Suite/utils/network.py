"""
Network utility functions for the OPSEC Suite.
Provides IP lookup, DNS resolution, WHOIS, and port scanning.
"""

import socket
import concurrent.futures
from typing import Any, Dict, List, Optional

import requests


def get_public_ip() -> str:
    """
    Retrieve the machine's public IP address using multiple fallback services.

    Returns:
        Public IP address string, or 'Unknown' on failure
    """
    services = [
        "https://api.ipify.org",
        "https://ifconfig.me/ip",
        "https://icanhazip.com",
        "https://ipecho.net/plain",
        "https://api4.my-ip.io/ip",
    ]
    for url in services:
        try:
            resp = requests.get(url, timeout=5)
            if resp.status_code == 200:
                ip = resp.text.strip()
                if ip:
                    return ip
        except requests.RequestException:
            continue
    return "Unknown"


def get_ip_info(ip: str = "") -> Dict[str, Any]:
    """
    Retrieve geolocation and ISP info for an IP address using ip-api.com.

    Args:
        ip: IP address to look up. Defaults to the caller's own public IP.

    Returns:
        Dictionary with keys: ip, country, regionName, city, zip, lat, lon,
        timezone, isp, org, as, query, status
    """
    target = ip if ip else ""
    url = f"http://ip-api.com/json/{target}"
    try:
        resp = requests.get(url, timeout=8)
        data = resp.json()
        if data.get("status") == "success":
            return data
        else:
            return {"status": "fail", "message": data.get("message", "Unknown error"), "query": target}
    except requests.RequestException as e:
        return {"status": "fail", "message": str(e), "query": target}


def dns_lookup(domain: str, record_type: str = "A") -> List[str]:
    """
    Perform a DNS lookup for the given domain and record type.

    Args:
        domain: Domain name to query (e.g. 'example.com')
        record_type: DNS record type ('A', 'AAAA', 'MX', 'NS', 'TXT', etc.)

    Returns:
        List of resolved DNS record strings, or an error list
    """
    try:
        import dns.resolver
        answers = dns.resolver.resolve(domain, record_type)
        return [str(r) for r in answers]
    except ImportError:
        pass
    except Exception:
        pass

    try:
        if record_type == "A":
            results = socket.getaddrinfo(domain, None, socket.AF_INET)
            return list({r[4][0] for r in results})
        elif record_type == "AAAA":
            results = socket.getaddrinfo(domain, None, socket.AF_INET6)
            return list({r[4][0] for r in results})
        else:
            return [f"Record type '{record_type}' requires dnspython for full support"]
    except socket.gaierror as e:
        return [f"DNS lookup failed: {e}"]


def whois_lookup(domain: str) -> Dict[str, Any]:
    """
    Perform a WHOIS lookup for the given domain.

    Args:
        domain: Domain name to query (e.g. 'example.com')

    Returns:
        Dictionary of WHOIS fields, or error info
    """
    try:
        import whois
        w = whois.whois(domain)
        result = {}
        for key, val in w.items():
            if val is not None:
                result[key] = str(val) if not isinstance(val, list) else [str(v) for v in val]
        return result
    except ImportError:
        pass
    except Exception as e:
        return {"error": str(e)}

    try:
        resp = requests.get(
            f"https://rdap.org/domain/{domain}",
            timeout=8,
            headers={"Accept": "application/json"},
        )
        if resp.status_code == 200:
            data = resp.json()
            return {
                "ldhName": data.get("ldhName", ""),
                "status": data.get("status", []),
                "handle": data.get("handle", ""),
                "events": [
                    {"action": e.get("eventAction"), "date": e.get("eventDate")}
                    for e in data.get("events", [])
                ],
            }
    except Exception as e:
        return {"error": f"RDAP fallback failed: {e}"}

    return {"error": "WHOIS lookup unavailable"}


def port_scan(target: str, ports: List[int], timeout: float = 1.0) -> Dict[int, str]:
    """
    Perform a simple TCP port scan against a target host.

    Args:
        target: Hostname or IP address to scan
        ports: List of port numbers to scan
        timeout: Connection timeout per port in seconds

    Returns:
        Dictionary mapping port number to 'open' or 'closed'
    """
    results: Dict[int, str] = {}

    def check_port(port: int) -> tuple:
        try:
            with socket.create_connection((target, port), timeout=timeout):
                return port, "open"
        except (socket.timeout, ConnectionRefusedError, OSError):
            return port, "closed"

    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        futures = {executor.submit(check_port, p): p for p in ports}
        for future in concurrent.futures.as_completed(futures):
            port, status = future.result()
            results[port] = status

    return dict(sorted(results.items()))
