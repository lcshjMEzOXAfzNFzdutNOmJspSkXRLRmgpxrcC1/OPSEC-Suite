"""
ANSI color code utilities for the OPSEC Suite.
Provides terminal color support detection and colored output.
"""

import os
import re
import sys


class Colors:
    """ANSI escape code color constants."""

    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    PURPLE = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    UNDERLINE = "\033[4m"
    RESET = "\033[0m"

    @classmethod
    def colorize(cls, text: str, color: str) -> str:
        """
        Wrap text with a color code and reset.

        Args:
            text: Text to colorize
            color: ANSI color code

        Returns:
            Colorized string if terminal supports it, plain text otherwise
        """
        if supports_color():
            return f"{color}{text}{cls.RESET}"
        return text

    @classmethod
    def red(cls, text: str) -> str:
        """Return red-colored text."""
        return cls.colorize(text, cls.RED)

    @classmethod
    def green(cls, text: str) -> str:
        """Return green-colored text."""
        return cls.colorize(text, cls.GREEN)

    @classmethod
    def yellow(cls, text: str) -> str:
        """Return yellow-colored text."""
        return cls.colorize(text, cls.YELLOW)

    @classmethod
    def blue(cls, text: str) -> str:
        """Return blue-colored text."""
        return cls.colorize(text, cls.BLUE)

    @classmethod
    def purple(cls, text: str) -> str:
        """Return purple-colored text."""
        return cls.colorize(text, cls.PURPLE)

    @classmethod
    def cyan(cls, text: str) -> str:
        """Return cyan-colored text."""
        return cls.colorize(text, cls.CYAN)

    @classmethod
    def white(cls, text: str) -> str:
        """Return white-colored text."""
        return cls.colorize(text, cls.WHITE)

    @classmethod
    def bold(cls, text: str) -> str:
        """Return bold text."""
        return cls.colorize(text, cls.BOLD)


def supports_color() -> bool:
    """
    Detect whether the current terminal supports ANSI color codes.

    Checks the TERM environment variable, platform, and whether stdout is a TTY.

    Returns:
        True if colors are supported, False otherwise
    """
    if sys.platform == "win32":
        try:
            import colorama
            colorama.init(autoreset=True)
            return True
        except ImportError:
            return False

    if not hasattr(sys.stdout, "isatty"):
        return False

    if not sys.stdout.isatty():
        return os.environ.get("FORCE_COLOR", "0") == "1"

    term = os.environ.get("TERM", "")
    no_color = os.environ.get("NO_COLOR", "")

    if no_color:
        return False

    if term in ("dumb", ""):
        return False

    return True


def strip_colors(text: str) -> str:
    """
    Remove ANSI escape codes from a string (useful for writing clean log files).

    Args:
        text: String potentially containing ANSI escape codes

    Returns:
        Plain text with all ANSI codes removed
    """
    ansi_escape = re.compile(r"\033\[[0-9;]*m")
    return ansi_escape.sub("", text)
